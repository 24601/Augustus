"""Careful reference and singly targeted competing variants; not agent input."""
import json
from pathlib import Path

MODE = "careful"


def lines(path):
    return [json.loads(s) for s in path.read_text().splitlines()]


def key(row, keys):
    return "|".join(str(int(row.get(k, 0) > 8)) if k == "arrival_peak_c" else
                    str(row.get(k, "missing")) for k in keys)


def fit(data_dir, artifact_path):
    d = Path(data_dir)
    cold = (d / "shipments.jsonl").exists()
    if cold:
        raw = lines(d / "shipments.jsonl")
        report_rows = [(r, r["spoiled"]) for r in raw if r["day"] >= 201]
        train = report_rows
        keys = ["pack", "heat"]
        cost, miss, cap = 3, 30, 2.5
        if MODE in ("stale", "unavailable", "careless"):
            train = [(r, r["spoiled"]) for r in raw]
            keys = ["carrier"] if MODE == "stale" else ["arrival_peak_c"]
    else:
        jobs = lines(d / "jobs.jsonl")
        by_id = {r["id"]: r for r in jobs}
        messages = lines(d / "outcomes.jsonl")
        ordered = sorted(messages, key=lambda m: m["revision"])
        final = {m["job_id"]: m for m in ordered}
        report_rows = [(r, final[r["id"]]["defect"]) for r in jobs]
        train = report_rows
        keys = ["stock", "rush"]
        cost, miss, cap = 2.4, 18, 2
        if MODE in ("duplicates", "careless"):
            train = [(by_id[m["job_id"]], m["defect"]) for m in messages
                     if m["revision"] == final[m["job_id"]]["revision"]]
        elif MODE == "old_revision":
            first = {m["job_id"]: m for m in reversed(ordered)}
            train = [(r, first[r["id"]]["defect"]) for r in jobs]
    if MODE == "careless":
        # A competent low-cardinality feature search on the wrong analysis table.
        options = ([[k] for k in ["pack", "heat", "carrier", "arrival_peak_c"]]
                   if cold else [[k] for k in ["stock", "rush", "press", "pages"]])
        scores = []
        for cols in options:
            bins = {}
            for row, y in train:
                bins.setdefault(key(row, cols), []).append(y)
            brier = sum(sum((y - sum(ys) / len(ys)) ** 2 for y in ys)
                        for ys in bins.values())
            scores.append((brier, cols))
        keys = min(scores)[1]
    counts = {}
    for row, y in train:
        pair = counts.setdefault(key(row, keys), [0, 0])
        pair[0] += y
        pair[1] += 1
    rates = {k: (yes + 1) / (n + 2) for k, (yes, n) in counts.items()}
    threshold = .5 if MODE == "accuracy" else cost / miss
    artifact = dict(keys=keys, rates=rates, threshold=threshold, mode=MODE)
    Path(artifact_path).write_text(json.dumps(artifact))
    if MODE == "fit_memory":
        global MEMORY
        MEMORY = artifact
    projected = []
    for row, y in report_rows:
        projected.append(({k: v for k, v in row.items()
                           if k not in ("arrival_peak_c", "spoiled")}, y))
    actions = [predict(artifact_path, r) for r, _ in projected]
    total = sum(cost if a else miss * y for a, (_, y) in zip(actions, projected))
    n = len(projected)
    report = dict(population_ids=[r["id"] for r, _ in projected], count=n,
                  rows=[dict(id=r["id"], action=a) for (r, _), a in zip(projected, actions)],
                  errors=sum(a != y for a, (_, y) in zip(actions, projected)),
                  loss_total=total, loss_mean=total / n,
                  recommendation="deploy" if n >= 200 and total / n <= cap else "hold")
    if MODE == "bad_denominator":
        report["count"] *= 2
        report["loss_mean"] /= 2
    elif MODE == "omit_unit":
        report["population_ids"].pop()
        report["rows"].pop()
    elif MODE == "invent_id":
        report["population_ids"][0] = "imaginary"
    elif MODE == "wrong_recommendation":
        report["recommendation"] = "hold" if report["recommendation"] == "deploy" else "deploy"
    elif MODE == "fake_actions":
        report["rows"][0]["action"] = 1 - report["rows"][0]["action"]
    Path(artifact_path).with_name("report.json").write_text(json.dumps(report))
    if MODE == "oversize":
        Path(artifact_path).write_text("x" * 65537)


def predict(artifact_path, record):
    artifact = json.loads(Path(artifact_path).read_text())
    mode = artifact["mode"]
    if mode == "fit_memory":
        artifact = MEMORY
    if mode == "invalid_type":
        return bool(artifact["rates"].get(key(record, artifact["keys"]), .5) > artifact["threshold"])
    if mode == "zero":
        return 0
    if mode == "one":
        return 1
    return int(artifact["rates"].get(key(record, artifact["keys"]), .5) > artifact["threshold"])
