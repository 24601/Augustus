"""Private pilot truth and scoring. Future draws never enter fit input."""
import json
import random
from pathlib import Path


def read(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def projection(task, row):
    keys = ("id day pack heat carrier route_minutes" if task == "coldchain" else
            "id day stock rush pages press").split()
    return {k: row[k] for k in keys}


def population(task, data):
    if task == "coldchain":
        return [(projection(task, r), r["spoiled"]) for r in
                read(Path(data) / "shipments.jsonl") if r["day"] >= 201]
    latest = {}
    for event in read(Path(data) / "outcomes.jsonl"):
        if event["revision"] > latest.get(event["job_id"], {}).get("revision", -1):
            latest[event["job_id"]] = event
    return [(r, latest[r["id"]]["defect"]) for r in read(Path(data) / "jobs.jsonl")]


def loss(task, action, label):
    cost, miss = (3, 30) if task == "coldchain" else (2.4, 18)
    return cost if action else miss * label


def future(task, seed, n=600):
    # Independent RNG and cohorts, altered mixes and modest seasonal risk.
    rng = random.Random(seed)
    rows = []
    for i in range(n):
        if task == "coldchain":
            pack = rng.choices(["thin", "thick"], [42, 58])[0]
            heat = rng.choices(["cool", "hot"], [35, 65])[0]
            minutes = rng.choice([35, 85])
            record = dict(id=f"F{seed}-{i}", day=301 + i // 6, pack=pack,
                          heat=heat, carrier=rng.choice(["A", "B"]),
                          route_minutes=minutes)
            base = .49 if pack == "thin" and heat == "hot" else (
                .19 if pack == "thin" else (.06 if heat == "hot" else .02))
            p = base + (.015 if minutes > 60 else 0)
        else:
            stock = rng.choices(["smooth", "textured"], [65, 35])[0]
            rush = rng.randrange(2)
            record = dict(id=f"F{seed}-{i}", day=181 + i // 6, stock=stock,
                          rush=rush, pages=rng.choice([8, 24, 60]),
                          press=rng.choice(["north", "south"]))
            p = (.335 if stock == "textured" else .055) + .035 * rush
        rows.append((record, int(rng.random() < p)))
    return rows
