# Pilot grader and observed outcomes — evaluator only

Version 1; synthetic author-generated data, not external operational evidence.
Only distribute the separate **public-pilot** archive to agents. Do not expose
this directory, the parent authoring conversation, generator, reference policies,
observed scores or protected-transfer archive to candidate agents. The public
briefs state facts and costs, not a model, split, primitive or hidden scoring rule.

## Replay

Extract public-pilot into `public/` and private-pilot into `private/` in a clean
directory. Python 3.11+ on Linux, no dependencies or network required:

```sh
python3 private/validate.py public --output /tmp/pilot-replay.json
python3 private/grade.py public coldchain private/minimal.py
python3 private/grade.py public printshop private/reference.py
python3 private/grade.py public coldchain /absolute/path/to/solution.py --seeds 92001 92002 92003
```

`validate.py` takes about 30 seconds on the author's orb, including two deliberate
8-second timeout failures. It materializes variants in temporary directories,
executes them, asserts their outcomes, and removes the temporary submissions.
`observed.json` holds the full author replay: 20 runs per task. Timings and
temporary-path error messages naturally vary between replays; dollar outcomes
and validity flags are deterministic for fixed seeds and Python RNG behavior.

`build_source.py --public-only` reproduces the exact public JSONL data when this
directory is named `private` beside `public`. Do not rebuild records mid-trial.
Archive generation uses sorted tar members, zero timestamps and fixed modes.

## What is measured

The primary outcome is continuous mean dollar loss over three independently
drawn future cohorts, 600 business units each. No pass/fail surrogate replaces
that loss. Additional seeds can be chosen before testing candidates. Report
correctness and serving validity remain separate flags; they must both hold for
an eligible submission. There is no reward for methodology, prose, keywords,
additional metrics, or claiming independence. Do not average dollars across
domains as though they were the same business; compare within each task.

Fit receives only the public data, and ends before future cohorts are generated.
Prediction runs in a new Python process with only submission and artifact in its
working directory. Each cohort is rerun in reverse order in a fresh process and
its first unit is also tested alone. Report truth is reconstructed from the
original source **before** candidate execution, not its writable data copy.
Historical report actions are rerun on serving-only records. The full required
population, unique IDs, count, action rows, errors, total/mean loss and deployment
rule are checked against that source. Historical split independence is explicitly
`unverifiable`; lists of IDs are not evidence of a training boundary.

Artifact byte limits, address-space/CPU limits, wall time, exact integer action
types, state/order consistency, and lasting working-directory file mutations
are checked. Site packages are disabled in subprocesses. This is **not an
adversarial sandbox**: the same OS user could seek absolute filesystem paths,
network access, fork children, or write then remove a file. Separate candidate
authoring environments must contain public inputs only. For hostile code, add
an OS/container read/network/process boundary; Python process separation alone
does not provide one. Grading is intended for cooperative frozen submissions.

## Observed results

Mean dollars per future unit, lower is better; 1,800 units per policy per task:

| Executed implementation | Cold chain | Printshop |
| --- | ---: | ---: |
| Independent minimal group-mean rule | 2.210 | 1.766 |
| Careful two-feature table, modest smoothing | 2.210 | 1.766 |
| Careless automatic low-cardinality feature search | 5.733 | 2.400 |
| Cost-insensitive 0.5 cutoff | 2.540 | 3.070 |
| Never intervene | 5.733 | 3.070 |
| Always intervene / incumbent | 3.000 | 2.400 |
| Stale-period carrier model | 4.470 | not applicable |
| Delivery-only feature, missing-at-serve default | 5.733 | not applicable |
| Retry-weighted final outcomes | not applicable | 2.400 |
| Superseded initial outcomes | not applicable | 2.400 |

The careful and minimal references were separately implemented. They happen to
choose identical actions on these cohorts; minimality is not penalized. Their
historical means are $1.8975 for 400 cold-chain units and $1.706667 for 900 print
jobs, yielding `deploy` under the stated rules. The careless policies' reports
correctly recommend `hold`; honesty does not erase their measured future losses.

Five report mutations (double denominator, omitted unit, invented ID, reversed
recommendation, falsified action) preserve policy loss but each fail report
checks. Oversized artifact, boolean output, reliance on fit-process memory,
serving-file write, alternating stateful policy, 300 MiB allocation and a
9-second serving initialization each fail serving checks. The stateful policy's
descriptive report can be correct while its serving contract still fails.

Independent hand-derived anchors verify $36/4 and $22.80/4 loss, two action
errors, revision/deduplication identity, the day-200/day-201 boundary, removal of
post-decision fields, the 199/200 count boundary and both sides of the deployment
cost cap. They do not derive expected arithmetic from the implementation being
tested. Source implementation and complete results are included for inspection.

## Limitations and interpretation

The intervention-effect assumption is synthetic and perfect; no causal effect
was estimated from observational operations. Future mixes and risks differ
slightly from history, but this is a bounded family, not broad robustness.
Pilot seeds were used to validate the instrument, so they are development
evidence. Confidence in model ranking requires independently frozen agent runs
and additional cohorts, not these hand-authored reference gaps. Neither the
40-turn/600-second agent budget nor model skill uplift has been piloted yet.
The no-ceremony rules already perform well; if actual agents saturate, report
that rather than inventing procedural points. Do not read protected transfer
contents or authoring traces until finalists are frozen.
