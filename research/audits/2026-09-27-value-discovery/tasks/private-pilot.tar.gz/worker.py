"""Process adapter; no candidate's fit state survives the prediction boundary."""
import importlib.util
import json
from pathlib import Path
import resource
import sys

sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2,) * 2)
resource.setrlimit(resource.RLIMIT_CPU, (30 if sys.argv[1] == "fit" else 8,) * 2)
spec = importlib.util.spec_from_file_location("submission", "solution.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
if sys.argv[1] == "fit":
    module.fit(str(Path("data").resolve()), str(Path("artifact.json").resolve()))
else:
    records = json.loads(sys.stdin.read())
    actions = []
    for row in records:
        value = module.predict(str(Path("artifact.json").resolve()), row)
        if type(value) is not int or value not in (0, 1):
            raise ValueError("predict must return integer 0 or 1")
        actions.append(value)
    print(json.dumps(actions))
