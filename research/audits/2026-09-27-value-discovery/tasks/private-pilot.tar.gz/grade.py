"""python grade.py PUBLIC_ROOT TASK SOLUTION.py [--seeds 82001 82002 82003]"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

from world import future, loss, population

HERE = Path(__file__).resolve().parent


def snapshot(work):
    return {str(p.relative_to(work)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in Path(work).rglob("*") if p.is_file()}


def run(work, mode, records=None):
    before = snapshot(work) if mode == "predict" else None
    started = time.monotonic()
    result = subprocess.run([sys.executable, "-I", "-S", str(HERE / "worker.py"), mode],
                            cwd=work, input=json.dumps(records), text=True,
                            capture_output=True, timeout=30 if mode == "fit" else 8)
    if result.returncode:
        raise ValueError(f"{mode} process failed: {result.stderr[-1200:]}")
    if mode == "predict" and snapshot(work) != before:
        raise ValueError("prediction mutated serving-directory files")
    return (None if mode == "fit" else json.loads(result.stdout)), time.monotonic() - started


def check_report(task, report, rows, actions):
    ids = [r["id"] for r, _ in rows]
    actual = {r["id"]: a for (r, _), a in zip(rows, actions)}
    errors = sum(a != y for (_, y), a in zip(rows, actions))
    total = sum(loss(task, a, y) for (_, y), a in zip(rows, actions))
    count = len(rows)
    failures = []
    listed = report.get("population_ids", [])
    if (not isinstance(listed, list) or any(type(i) is not str for i in listed)
            or sorted(listed) != sorted(ids)):
        failures.append("population_ids")
    declared = report.get("rows", [])
    try:
        if (len(declared) != count or
                any(type(r["action"]) is not int for r in declared) or
                sorted(r["id"] for r in declared) != sorted(ids) or
                {r["id"]: r["action"] for r in declared} != actual):
            failures.append("rows")
    except (KeyError, TypeError, AttributeError):
        failures.append("rows")
    for key, expected in dict(count=count, errors=errors, loss_total=total,
                              loss_mean=total / count).items():
        value = report.get(key)
        if (type(value) not in (int, float) or not math.isfinite(value) or
                not math.isclose(value, expected, rel_tol=1e-9, abs_tol=1e-9)):
            failures.append(key)
    cap = 2.5 if task == "coldchain" else 2
    recommendation = "deploy" if count >= 200 and total / count <= cap else "hold"
    if report.get("recommendation") != recommendation:
        failures.append("recommendation")
    return dict(valid=not failures, failures=failures, recomputed_count=count,
                recomputed_errors=errors, recomputed_loss_total=total,
                recomputed_loss_mean=total / count, expected_recommendation=recommendation,
                split_independence="unverifiable: descriptive fitted-history report")


def grade(public, task, solution, seeds=(82001, 82002, 82003)):
    result = dict(task=task, serving_valid=False)
    try:
        # Truth is read before candidate execution, never from its writable copy.
        rows = population(task, Path(public) / task / "data")
        with tempfile.TemporaryDirectory(prefix="value-fit-") as fitdir, \
                tempfile.TemporaryDirectory(prefix="value-serve-") as servedir:
            fitdir, servedir = Path(fitdir), Path(servedir)
            shutil.copy(solution, fitdir / "solution.py")
            shutil.copytree(Path(public) / task / "data", fitdir / "data")
            _, seconds = run(fitdir, "fit")
            result["fit_seconds"] = seconds
            artifact = fitdir / "artifact.json"
            if not artifact.is_file() or artifact.stat().st_size > 65536:
                raise ValueError("artifact missing or larger than 65536 bytes")
            result["artifact_bytes"] = artifact.stat().st_size
            try:
                report = json.loads((fitdir / "report.json").read_text())
                if not isinstance(report, dict):
                    report = {}
            except (OSError, ValueError):
                report = {}
            shutil.copy(artifact, servedir / "artifact.json")
            shutil.copy(solution, servedir / "solution.py")
            # Remove even accidental access via fit cwd before prediction.
            shutil.rmtree(fitdir / "data")
            actions = []
            for start in range(0, len(rows), 600):
                part, _ = run(servedir, "predict", [r for r, _ in rows[start:start + 600]])
                actions.extend(part)
            result["report"] = check_report(task, report, rows, actions)
            cohort_results = []
            total, count = 0, 0
            for seed in seeds:
                cohort = future(task, seed)
                records = [r for r, _ in cohort]
                actions, seconds = run(servedir, "predict", records)
                if len(actions) != len(records):
                    raise ValueError("wrong number of predictions")
                # Restart with reversed order, then a singleton cold start.
                reversed_actions, _ = run(servedir, "predict", list(reversed(records)))
                singleton, _ = run(servedir, "predict", records[:1])
                if reversed_actions[::-1] != actions or singleton != actions[:1]:
                    raise ValueError("process/order-dependent predictions")
                dollars = sum(loss(task, a, y) for (_, y), a in zip(cohort, actions))
                n = len(cohort)
                cohort_results.append(dict(seed=seed, count=n, loss_mean=dollars / n,
                                           interventions=sum(actions),
                                           errors=sum(a != y for (_, y), a in zip(cohort, actions)),
                                           serving_seconds=seconds))
                total += dollars
                count += n
            result.update(serving_valid=True, cohorts=cohort_results,
                          future_count=count, future_loss_mean=total / count,
                          improvement_over_incumbent=(3 if task == "coldchain" else 2.4) - total / count)
    except Exception as exc:
        result["failure"] = f"{type(exc).__name__}: {exc}"
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("public")
    parser.add_argument("task", choices=["coldchain", "printshop"])
    parser.add_argument("solution")
    parser.add_argument("--seeds", nargs="+", type=int, default=[82001, 82002, 82003])
    args = parser.parse_args()
    print(json.dumps(grade(args.public, args.task, args.solution, args.seeds), indent=2))
