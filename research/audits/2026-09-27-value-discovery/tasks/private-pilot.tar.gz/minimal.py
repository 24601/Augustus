"""Independent small reference: group means, cost threshold, no prose ceremony."""
import json
from pathlib import Path


def fit(data_dir, artifact_path):
    d = Path(data_dir)
    if (d / "shipments.jsonl").exists():
        records = [json.loads(s) for s in (d / "shipments.jsonl").read_text().splitlines()]
        records = [r for r in records if r["day"] >= 201]
        samples = [(r, r["spoiled"]) for r in records]
        key, cost, miss, cap = "pack", 3, 30, 2.5
    else:
        records = [json.loads(s) for s in (d / "jobs.jsonl").read_text().splitlines()]
        messages = [json.loads(s) for s in (d / "outcomes.jsonl").read_text().splitlines()]
        final = {}
        for m in sorted(messages, key=lambda m: m["revision"]):
            final[m["job_id"]] = m["defect"]
        samples = [(r, final[r["id"]]) for r in records]
        key, cost, miss, cap = "stock", 2.4, 18, 2
    groups = {}
    for r, y in samples:
        values = groups.setdefault(r[key], [])
        values.append(y)
    policy = {k: int(miss * sum(ys) / len(ys) > cost) for k, ys in groups.items()}
    Path(artifact_path).write_text(json.dumps([key, policy]))
    actions = [policy[r[key]] for r, _ in samples]
    losses = [cost if a else miss * y for a, (_, y) in zip(actions, samples)]
    total, n = sum(losses), len(samples)
    report = dict(population_ids=[r["id"] for r, _ in samples], count=n,
                  rows=[dict(id=r["id"], action=a) for (r, _), a in zip(samples, actions)],
                  errors=sum(a != y for a, (_, y) in zip(actions, samples)),
                  loss_total=total, loss_mean=total / n,
                  recommendation="deploy" if n >= 200 and total / n <= cap else "hold")
    Path(artifact_path).with_name("report.json").write_text(json.dumps(report))


def predict(artifact_path, record):
    key, policy = json.loads(Path(artifact_path).read_text())
    return policy[record[key]]
