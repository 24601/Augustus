"""Author synthetic pilot records and deterministic, separately frozen archives."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import random
import shutil
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
if ROOT.name == "private":
    ROOT = ROOT.parent


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in rows))


def pilots():
    rng = random.Random(571031)
    cold = []
    for i in range(1200):
        day = i // 4 + 1
        pack = rng.choice(["thin", "thick"])
        heat = rng.choice(["cool", "hot"])
        carrier = rng.choice(["A", "B"])
        minutes = rng.choice([35, 85])
        p = ({"A": .015, "B": .42}[carrier] if day < 201 else
             {("thin", "hot"): .48, ("thin", "cool"): .18,
              ("thick", "hot"): .055, ("thick", "cool"): .025}[pack, heat]
             + (.02 if minutes > 60 else 0))
        spoiled = int(rng.random() < p)
        cold.append(dict(id=f"C{i:04}", day=day, pack=pack, heat=heat,
                         carrier=carrier, route_minutes=minutes,
                         arrival_peak_c=round(rng.uniform(11, 17) if spoiled else
                                              rng.uniform(2, 7), 1), spoiled=spoiled))
    write_jsonl(ROOT / "public/coldchain/data/shipments.jsonl", cold)
    jobs, events = [], []
    for i in range(900):
        stock = rng.choices(["smooth", "textured"], [3, 1])[0]
        rush = rng.randrange(2)
        job = dict(id=f"P{i:04}", day=1 + i // 5, stock=stock, rush=rush,
                   pages=rng.choice([8, 24, 60]), press=rng.choice(["north", "south"]))
        jobs.append(job)
        defect = int(rng.random() < (.32 if stock == "textured" else .06) + .04 * rush)
        # A preliminary operator finding can be reversed on final reconciliation.
        initial = 1 - defect if rng.random() < .19 else defect
        events.append(dict(event_id=f"E{i}-0", job_id=job["id"], revision=1,
                           defect=initial, note="operator"))
        for k in range(rng.randint(6, 10) if defect else rng.randint(1, 2)):
            events.append(dict(event_id=f"E{i}-{k+1}", job_id=job["id"], revision=2,
                               defect=defect, note="billing export" if k else "final QA"))
    rng.shuffle(events)
    write_jsonl(ROOT / "public/printshop/data/jobs.jsonl", jobs)
    write_jsonl(ROOT / "public/printshop/data/outcomes.jsonl", events)


def archive(source, output):
    if not source.is_dir() or not any(source.iterdir()):
        raise ValueError(f"cannot freeze missing or empty source: {source}")
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w") as tar:
        for p in sorted(source.rglob("*")):
            if not p.is_file() or "__pycache__" in p.parts:
                continue
            data = p.read_bytes()
            info = tarfile.TarInfo(str(p.relative_to(source)))
            info.size, info.mtime, info.mode = len(data), 0, 0o644
            tar.addfile(info, io.BytesIO(data))
    output.write_bytes(gzip.compress(raw.getvalue(), mtime=0))
    return hashlib.sha256(output.read_bytes()).hexdigest()


if __name__ == "__main__":
    pilots()
    if "--public-only" in sys.argv:
        raise SystemExit(0)
    if Path(__file__).resolve() != ROOT / "private/build_source.py":
        shutil.copyfile(__file__, ROOT / "private/build_source.py")
    out = ROOT / "archives"
    out.mkdir(exist_ok=True)
    hashes = {}
    for folder, name in [("public", "public-pilot"), ("private", "private-pilot"),
                         ("transfer", "protected-transfer")]:
        hashes[name + ".tar.gz"] = archive(ROOT / folder, out / (name + ".tar.gz"))
    (out / "SHA256SUMS").write_text("".join(f"{v}  {k}\n" for k, v in hashes.items()))
    print(json.dumps(hashes, indent=2))
