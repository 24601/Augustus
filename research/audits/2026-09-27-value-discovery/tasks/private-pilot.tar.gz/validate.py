"""Replay anchors and reference/mutant outcomes; writes complete JSON evidence."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import tempfile

from grade import check_report, grade
from world import loss, population

HERE = Path(__file__).resolve().parent


def anchors():
    # Hand derivation: 30+3+0+3=36; 18+2.4+0+2.4=22.8; two errors.
    records = [({"id": str(i)}, y) for i, y in enumerate([1, 0, 0, 1])]
    actions = [0, 1, 0, 1]
    for task, total in [("coldchain", 36), ("printshop", 22.8)]:
        assert abs(sum(loss(task, a, y) for (_, y), a in zip(records, actions)) - total) < 1e-10
        report = dict(population_ids=["0", "1", "2", "3"], count=4,
                      rows=[dict(id=str(i), action=a) for i, a in enumerate(actions)],
                      errors=2, loss_total=total, loss_mean=total / 4, recommendation="hold")
        assert check_report(task, report, records, actions)["valid"]
        for field in ["count", "errors", "loss_mean", "loss_total"]:
            wrong = deepcopy(report)
            wrong[field] += 1
            assert field in check_report(task, wrong, records, actions)["failures"]
        wrong = deepcopy(report)
        wrong["population_ids"][-1] = "2"
        assert not check_report(task, wrong, records, actions)["valid"]
        for n, expected in [(199, "hold"), (200, "deploy")]:
            safe = [({"id": str(i)}, 0) for i in range(n)]
            result = check_report(task, {}, safe, [0] * n)
            assert result["expected_recommendation"] == expected
        # 250 interventions among 300 safe units gives exactly the disclosed cap.
        safe = [({"id": str(i)}, 0) for i in range(300)]
        at_cap = check_report(task, {}, safe, [1] * 250 + [0] * 50)
        over_cap = check_report(task, {}, safe, [1] * 251 + [0] * 49)
        assert at_cap["expected_recommendation"] == "deploy"
        assert over_cap["expected_recommendation"] == "hold"
    # Independently written fixture: shuffled stale label and repeated final message.
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d / "jobs.jsonl").write_text('{"id":"a"}\n{"id":"b"}\n')
        (d / "outcomes.jsonl").write_text('\n'.join(json.dumps(e) for e in [
            dict(job_id="a", revision=2, defect=0), dict(job_id="a", revision=1, defect=1),
            dict(job_id="b", revision=2, defect=1), dict(job_id="b", revision=2, defect=1)]))
        assert population("printshop", d) == [({"id": "a"}, 0), ({"id": "b"}, 1)]
        base = dict(pack="thin", heat="cool", carrier="A", route_minutes=35,
                    arrival_peak_c=4, spoiled=0)
        (d / "shipments.jsonl").write_text('\n'.join(json.dumps(dict(base, id=str(day), day=day))
                                                     for day in [200, 201]))
        selected = population("coldchain", d)
        assert len(selected) == 1 and selected[0][0]["id"] == "201"
        assert "arrival_peak_c" not in selected[0][0] and "spoiled" not in selected[0][0]


def validate(public):
    anchors()
    results = {}
    template = (HERE / "reference.py").read_text()
    modes = ["careful", "careless", "accuracy", "zero", "one", "bad_denominator",
             "omit_unit", "invent_id", "wrong_recommendation", "fake_actions",
             "oversize", "invalid_type", "fit_memory"]
    # Small executable serving failures, not rubric keywords.
    extras = {
        "side_effect": '\n_original = predict\ndef predict(path, row):\n    Path("stamp").write_text("changed")\n    return _original(path, row)\n',
        "stateful": '\n_counter = 0\ndef predict(path, row):\n    global _counter\n    _counter += 1\n    return _counter % 2\n',
        "memory": '\nif not Path("data").exists():\n    _large = bytearray(300 * 1024**2)\n',
        "timeout": '\nif not Path("data").exists():\n    import time\n    time.sleep(9)\n',
    }
    with tempfile.TemporaryDirectory() as tmp:
        candidate = Path(tmp) / "solution.py"
        for task in ["coldchain", "printshop"]:
            results[task] = {"minimal": grade(public, task, HERE / "minimal.py")}
            relevant = ["stale", "unavailable"] if task == "coldchain" else ["duplicates", "old_revision"]
            for mode in modes + relevant:
                candidate.write_text(template.replace('MODE = "careful"', f'MODE = "{mode}"'))
                results[task][mode] = grade(public, task, candidate)
            for mode, suffix in extras.items():
                candidate.write_text(template + suffix)
                results[task][mode] = grade(public, task, candidate)
            variants = results[task]
            for good in ["minimal", "careful", "careless", "accuracy", "zero", "one"] + relevant:
                assert variants[good]["serving_valid"], (task, good, variants[good])
                assert variants[good]["report"]["valid"], (task, good, variants[good])
            for bad in ["bad_denominator", "omit_unit", "invent_id", "wrong_recommendation", "fake_actions"]:
                assert not variants[bad]["report"]["valid"], (task, bad)
            for bad in ["oversize", "invalid_type", "fit_memory"] + list(extras):
                assert not variants[bad]["serving_valid"], (task, bad)
            for bad in ["careless", "accuracy", "zero", "one"] + relevant:
                assert variants[bad]["future_loss_mean"] > variants["minimal"]["future_loss_mean"], (task, bad)
    return dict(anchors="passed", results=results)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("public")
    parser.add_argument("--output", default="observed.json")
    args = parser.parse_args()
    result = validate(args.public)
    Path(args.output).write_text(json.dumps(result, indent=2) + "\n")
    print("anchors passed; 20 reference/competitor/mutant runs per task replayed")
    for task, variants in result["results"].items():
        for name, outcome in variants.items():
            print(task, name, round(outcome.get("future_loss_mean", -1), 6),
                  outcome["serving_valid"], outcome.get("report", {}).get("valid"))
