# Orchard cold-chain dispatch

Decide whether to add a disposable cooling sleeve at departure, reducing loss
for a meal-kit shipper. Action 1 always costs $3 and prevents the spoilage loss;
action 0 costs $30 if `spoiled=1`, otherwise $0. Future dispatches start on day
301. The incumbent adds sleeves to every shipment. Report dollar cap: $2.50.

`data/shipments.jsonl` has one completed shipment per line, chronological days
1–300. `id` is the shipment identity; `day` is dispatch day (integer).
`pack` is thin/thick insulation purchased at departure, `heat` is the departure
forecast band cool/hot, `carrier` is A/B, and `route_minutes` is the planned
route duration. `arrival_peak_c` is the maximum logger temperature, uploaded
after delivery. `spoiled` is the final binary laboratory disposition, also
after delivery. Outcomes describe shipments without the optional sleeve.

On day 201 both carriers replaced their refrigeration equipment and adopted a
common service specification. Packing and route planning remained in house.
There have been no further equipment changes announced. Historical report
population: all dispatches from day 201 onward in the supplied file.

Serving record contains exactly `id`, `day`, `pack`, `heat`, `carrier`, and
`route_minutes`, with the types and categories above. Follow ../CONTRACT.md.
