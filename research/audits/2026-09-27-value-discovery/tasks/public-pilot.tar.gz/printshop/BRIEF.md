# Printshop extra proof routing

Decide whether each print job gets an extra digital preflight before press.
Action 1 costs $2.40 and prevents the reprint; action 0 costs $18 if `defect=1`,
otherwise $0. The defect field describes what would happen without preflight.
The incumbent preflights every job. Future work begins on day 181. Historical
report dollar cap: $2.00. Report population: every job in `jobs.jsonl`.

`jobs.jsonl` contains one job per line: unique `id`; integer submission `day`;
paper `stock` smooth/textured; binary `rush`; `pages` (8, 24 or 60); `press`
north/south. All these values are booked before the preflight decision. They
are exactly the fields in the serving record.

`outcomes.jsonl` is a shuffled export of operational messages, not a job table.
`event_id` identifies a message; `job_id` refers to jobs; integer `revision`
orders reconciliations; `defect` is binary; `note` names the originating feed.
Higher revisions supersede lower revisions. Messages at the same revision
agree. Billing retries have distinct event IDs and retain the same job ID,
revision and disposition. Every supplied job has a final disposition. The
exporter retries reprint billing more often than ordinary invoice billing.
No press, pricing or reporting changes are planned. Follow ../CONTRACT.md.
