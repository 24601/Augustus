# Bounded application challenge, version 1

These are synthetic operational histories, not measured product outcomes. Work
on the assigned directory only. No network, paid calls, external data or Python
dependencies. You have 40 turns / 600 seconds to implement a useful policy.
There is no required model, fitting method, evaluation split or decision primitive.
A short rule is acceptable. Minimize dollars lost per business unit in upcoming
operations, not classification error. Report honestly what the records establish.

Submit `solution.py` with two functions:

* `fit(data_dir, artifact_path)`: both arguments are string paths. Read the
  assigned data, write one self-contained artifact at `artifact_path`, and write
  `report.json` beside that artifact. Return value ignored.
* `predict(artifact_path, record)`: return the Python integer 0 or 1. This is run
  in a new Python process, never the fit process. Record contains exactly the
  serving keys documented in the brief. No side effects or training-file reads.
  Artifact must be sufficient after restarting. No probabilities or wrapper dicts.

Python 3.11+, stdlib only. Artifact at most 65,536 bytes; fit at most 30 seconds;
prediction worker at most 8 seconds for 600 records; each process at most 256 MiB
address space. The grader also checks fresh-process calls. Record order is not a
stateful contract. The development budget includes your own tests, not the private
grader's execution. Do not spend it building infrastructure.

`report.json` schema (no additional prose requirements):

```json
{
  "population_ids": ["unit-id"],
  "count": 1,
  "rows": [{"id": "unit-id", "action": 0}],
  "errors": 0,
  "loss_total": 0.0,
  "loss_mean": 0.0,
  "recommendation": "deploy"
}
```

The population is specified per brief, and every business unit appears once.
`errors` counts actions unequal to the recorded binary outcome; loss uses the
action costs instead. Rows must be the submitted artifact's current actions on
those records' serving projections. Grader reconstructs labels, population,
counts, errors and loss from source records and reruns the artifact. IDs alone
do not establish evaluation independence; this report is descriptive historical
evidence, not an independent test. You may supply extra fields; none earn credit.

The operational recommendation rule is `deploy` exactly when count >= 200 and
historical mean loss <= the brief's dollar cap, otherwise `hold`. This is the
owner's disclosed rule, not a claim that historical evidence proves future
performance. Private assessment separately measures continuous mean dollar loss
on future cohorts, invalid outputs, resource limits, and report correctness;
there is no keyword, ceremony or preferred-method score.
