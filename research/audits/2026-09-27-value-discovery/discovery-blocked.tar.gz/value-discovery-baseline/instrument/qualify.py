"""Offline wire qualification: scripted loopback HTTP, never model inference."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import shutil
import subprocess
import tempfile
import threading

import instrument as m

ROOT = Path(__file__).resolve().parent.parent
CLI_SHA = 'fcfd837103965c64de34a6b9b94370d77a347ea71819715a27d5f0ef01775ea4'
PREFIX = 'OFFLINE_CANARY_9D73B2_'


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def managed_snapshot():
    result = {}
    for root in [Path('/Library/Application Support/ClaudeCode'), Path('/etc/claude-code')]:
        files = {}
        if root.exists():
            for p in sorted(root.rglob('*')):
                if p.is_file():
                    files[str(p.relative_to(root))] = m.sha(p)
        result[str(root)] = {'exists': root.exists(), 'files': files}
    return result


class Mock:
    def __init__(self, actions):
        self.requests = []
        self.actions = actions
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_HEAD(self):
                self.send_response(404); self.end_headers()

            def do_GET(self):
                self.send_response(404); self.end_headers()

            def do_POST(self):
                raw = self.rfile.read(int(self.headers['Content-Length']))
                body = json.loads(raw)
                index = sum('count_tokens' not in r['path'] for r in owner.requests)
                owner.requests.append({'path': self.path, 'body': body, 'raw': raw.decode(),
                                       'headers': dict(self.headers.items())})
                if 'count_tokens' in self.path:
                    self.send_response(200); self.send_header('Content-Type','application/json')
                    self.end_headers(); self.wfile.write(b'{"input_tokens":1}'); return
                if index < len(owner.actions):
                    name, values = owner.actions[index]
                    block = {'type':'tool_use','id':f'toolu_offline_{index}','name':name,'input':values}
                    reason = 'tool_use'
                else:
                    block = {'type':'text','text':'Scripted offline response. No inference.'}
                    reason = 'end_turn'
                message = {'id':f'msg_offline_{index}','type':'message','role':'assistant',
                           'model':m.MODEL,'content':[block],'stop_reason':reason,'stop_sequence':None,
                           'usage':{'input_tokens':1,'output_tokens':1}}
                if not body.get('stream'):
                    self.send_response(200); self.send_header('Content-Type','application/json')
                    self.end_headers(); self.wfile.write(json.dumps(message).encode()); return
                self.send_response(200); self.send_header('Content-Type','text/event-stream'); self.end_headers()

                def emit(kind, data):
                    self.wfile.write(('event: '+kind+'\ndata: '+json.dumps({'type':kind,**data})+'\n\n').encode())
                    self.wfile.flush()

                emit('message_start', {'message':{**message,'content':[],'stop_reason':None}})
                if block['type'] == 'tool_use':
                    emit('content_block_start', {'index':0,'content_block':{**block,'input':{}}})
                    delta = {'type':'input_json_delta','partial_json':json.dumps(block['input'])}
                else:
                    emit('content_block_start', {'index':0,'content_block':{'type':'text','text':''}})
                    delta = {'type':'text_delta','text':block['text']}
                emit('content_block_delta', {'index':0,'delta':delta})
                emit('content_block_stop', {'index':0})
                emit('message_delta', {'delta':{'stop_reason':reason,'stop_sequence':None},'usage':{'output_tokens':1}})
                emit('message_stop', {})

        self.server = ThreadingHTTPServer(('127.0.0.1',0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.server.shutdown(); self.server.server_close(); self.thread.join()


def skill(path, name, suffix):
    write(path/'SKILL.md', f'---\nname: {name}\ndescription: {PREFIX}{suffix}_DESCRIPTION harmless offline canary.\n---\n\n# {name}\n{PREFIX}{suffix}_BODY\n')


CANARY_SKILLS = [('config/skills','CONFIG','canary-9d73b2-config'),
                 ('home/.claude/skills','HOME','canary-9d73b2-home-claude'),
                 ('home/.agents/skills','HOME_AGENTS','canary-9d73b2-home-agents'),
                 ('.claude/skills','ANCESTOR','canary-9d73b2-ancestor-claude')]


def plant(runtime, mode):
    for directory, suffix, name in CANARY_SKILLS:
        skill(runtime/directory/name, name, suffix)
    # Real, public candidate bytes in synthetic user config, not normal installation.
    for name in ['augustus', 'augustus-train']:
        shutil.copytree(ROOT/'public-plugin/skills'/name, runtime/'config/skills'/name)
        skill(runtime/'.agents/skills'/name, name, 'ANCESTOR_AGENTS_'+name.upper())
    for where, suffix in [('config/CLAUDE.md','CONFIG_GUIDANCE'), ('home/CLAUDE.md','HOME_GUIDANCE'),
                          ('AGENTS.md','ANCESTOR_AGENTS_GUIDANCE')]:
        write(runtime/where, PREFIX+suffix+'\n')
    if mode != 'guidance-agents-control':
        write(runtime/'CLAUDE.md', PREFIX+'ANCESTOR_CLAUDE_GUIDANCE\n')
    plugin = runtime/'positive/.agents'
    for name in ['augustus', 'augustus-train']:
        skill(plugin/'skills'/name, name, 'PLUGIN_'+name.upper())
    return plugin


def inventory(body):
    result = {}
    for category in ['system', 'messages', 'tools']:
        value = body.get(category)
        raw = json.dumps(value, sort_keys=True).encode()
        result[category] = {'sha256':hashlib.sha256(raw).hexdigest(), 'bytes':len(raw)}
    result['toolNames'] = [t['name'] for t in body.get('tools', [])]
    result['systemBlocks'] = [{'type':b.get('type'), 'sha256':hashlib.sha256(b.get('text','').encode()).hexdigest(),
                               'bytes':len(b.get('text','').encode())} for b in body.get('system',[]) ]
    return result


def run(mode, evidence):
    with tempfile.TemporaryDirectory(prefix='aug-wire-') as directory:
        runtime = Path(directory).resolve()
        plugin = plant(runtime, mode)
        use_plugin = mode == 'positive-plugin'
        probe = ('import socket,pathlib\n'
                 'out=[]\n'
                 'for name,fn in [("network",lambda:socket.create_connection(("127.0.0.1",8317),timeout=1)),\n'
                 '                ("home",lambda:pathlib.Path.home().joinpath(".zshrc").read_text())]:\n'
                 ' try: fn(); out.append(name+"=ALLOWED")\n'
                 ' except OSError: out.append(name+"=DENIED")\n'
                 'print("PROBE "+",".join(out))\n')
        actions = ([('Skill', {'skill':'.agents:augustus'}),
                    ('Skill', {'skill':'augustus-train'}),
                    ('Write', {'file_path':'probe.py','content':probe}),
                    ('Bash', {'command':'python3 probe.py','description':'probe'})]
                   if use_plugin else [])
        old_command, old_env = m.launch_command, m.run_environment
        with Mock(actions) as mock:
            port = mock.server.server_port

            def command(r, p, budget):
                cmd = old_command(r, p, budget)
                if mode.endswith('-control'):
                    cmd[cmd.index('--setting-sources')+1] = 'user,project,local'
                    cmd.remove('--restricted')
                return cmd

            def env(r, endpoint):
                values = old_env(r, endpoint)
                if mode.endswith('-control'):
                    values.pop('CLAUDE_CODE_DISABLE_CLAUDE_MDS')
                return values

            with patch.object(m, 'launch_command', command), patch.object(m, 'run_environment', env):
                result = m.execute_one(runtime, plugin if use_plugin else None,
                                       {'contract':'Offline payload qualification only.', 'effective':'Reply briefly. This is an offline scripted test.'},
                                       f'http://127.0.0.1:{port}', 1)
        dest = evidence/mode
        dest.mkdir()
        for name in ['trace.jsonl','stderr.log','execution.json','settings.json','guard.json','guard-events.jsonl']:
            if (runtime/name).exists():
                shutil.copyfile(runtime/name, dest/name)
        m.dump(dest/'requests.json', mock.requests)
        m.dump(dest/'result.json', result)
        bodies = [r['body'] for r in mock.requests if 'count_tokens' not in r['path']]
        assert bodies, result
        assert result['exitCode'] == 0, result
        assert result['status'] == 'done' and not result['protocolErrors'], result
        headers = {k.lower(): v for k, v in mock.requests[-1]['headers'].items()}
        assert headers.get('authorization') == 'Bearer local-vibeproxy-placeholder', 'Unexpected credential'
        assert 'x-api-key' not in headers, 'Unexpected credential header'
        payload = json.dumps([{k:b.get(k) for k in ['system','messages','tools']} for b in bodies])
        first = json.dumps(bodies[0])
        if mode == 'negative':
            assert PREFIX not in payload, 'Unexpected canary injection'
            for _, _, name in CANARY_SKILLS:
                assert name not in payload.lower(), 'Unexpected canary skill name'
            assert 'augustus' not in payload.lower(), 'Unexpected Augustus injection'
            for name in ['augustus','augustus-train']:
                text = (ROOT/'public-plugin/skills'/name/'SKILL.md').read_text()
                description = next(x for x in text.splitlines() if x.startswith('description:')).split(':',1)[1].strip().strip('"')
                assert description not in payload, 'Unexpected real skill description'
        elif use_plugin:
            for name in ['AUGUSTUS','AUGUSTUS-TRAIN']:
                assert PREFIX+'PLUGIN_'+name+'_DESCRIPTION' in first
                assert PREFIX+'PLUGIN_'+name+'_BODY' not in first
                assert PREFIX+'PLUGIN_'+name+'_BODY' in payload
            for suffix in ['CONFIG_', 'HOME_', 'ANCESTOR_']:
                assert PREFIX+suffix not in payload
            assert 'PROBE network=DENIED,home=DENIED' in payload, 'Python tool sandbox not enforced'
            events = [json.loads(x) for x in (dest/'guard-events.jsonl').read_text().splitlines()]
            assert {e['toolUseId'] for e in events} == {f'toolu_offline_{i}' for i in range(len(actions))}
            assert all(e['decision']['permissionDecision'] == 'allow' for e in events), events
            assert any('python-sandbox' in e['decision'].get('updatedInput',{}).get('command','') for e in events)
        else:
            suffix = 'ANCESTOR_AGENTS_GUIDANCE' if mode == 'guidance-agents-control' else 'ANCESTOR_CLAUDE_GUIDANCE'
            assert PREFIX+suffix in payload, suffix
            assert PREFIX+'CONFIG_GUIDANCE' in payload
            # Positive control for the config-dir skill channel itself.
            assert '- augustus:' in payload
            assert CANARY_SKILLS[0][2] in payload.lower()
        m.dump(dest/'inventory.json', [inventory(b) for b in bodies])
        return {'mode':mode, 'requests':len(bodies), 'passed':True, 'noInference':True}


def main():
    assert m.sha(m.CLAUDE) == CLI_SHA, 'CLI changed; requalify new version separately'
    evidence = ROOT/'evidence'
    evidence.mkdir(exist_ok=False)
    managed = managed_snapshot()
    m.dump(evidence/'managed-paths.json', managed)
    assert not any(v['exists'] for v in managed.values()), 'Unexpected managed path; stop for review'
    results = []
    for mode in ['negative','positive-plugin','guidance-claude-control','guidance-agents-control']:
        results.append(run(mode, evidence))
        print(json.dumps(results[-1]), flush=True)
    assert managed_snapshot() == managed
    m.dump(evidence/'summary.json', {'cliSha256':CLI_SHA, 'noInference':True,'results':results})


if __name__ == '__main__':
    main()
