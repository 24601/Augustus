"""Baseline-arm value discovery: two fresh attempts per task, no Augustus plugin."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import socket
import tempfile
import threading
import time
import urllib.error
import urllib.request

import instrument as m

CEILING = 3.0
ATTEMPTS = 4
TURNS = 40
TIMEOUT = 600
REDACTED = {'authorization', 'x-api-key', 'proxy-authorization', 'cookie'}
COMMON = '''
Execution environment: the working directory is your disposable fixture.
TASK.md is the immutable brief. CONTRACT.md in this directory is the submission
contract its final line refers to; read both. Use Read/Glob/Grep and Write/Edit here.
CONTRACT.md and everything under data/ are read-only inputs here.
Write solution.py, the artifact, report.json and your own checks using other names.
Bash accepts only `python3 relative_script.py [arguments...]`, not shell syntax,
interpreter flags, -c, -m, pipes, redirection, installs, or network commands.
Write a Python check script when stdin, subprocesses, or multiple steps are needed.
Python scripts run in a stdlib-only OS sandbox with no network, no credentials,
and no reads or writes outside this fixture except read-only system libraries.
Do not use nested agents, network tools, account actions, or package installs.
Deliver solution.py, the artifact your fit writes, and report.json, and retain
your generated checks here. There is no visible evaluator to find.
'''


class Recorder:
    """Loopback relay that records request bodies without credential headers."""

    def __init__(self, upstream, path):
        self.records = []
        owner = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def log_message(self, *args):
                pass

            def relay(self, body=None):
                headers = {k: v for k, v in self.headers.items()
                           if k.lower() not in {'host', 'content-length', 'connection', 'accept-encoding'}}
                request = urllib.request.Request(upstream + self.path, data=body,
                                                 headers=headers, method=self.command)
                try:
                    response = urllib.request.urlopen(request, timeout=TIMEOUT)
                except urllib.error.HTTPError as e:
                    response = e
                except OSError as e:
                    self.send_response(502); self.send_header('Content-Length','0'); self.end_headers()
                    owner.note(self.command, self.path, body, self.headers, None, str(type(e).__name__))
                    return
                status = response.status
                owner.note(self.command, self.path, body, self.headers, status, None)
                self.send_response(status)
                for key, value in response.headers.items():
                    if key.lower() not in {'transfer-encoding', 'content-length', 'connection'}:
                        self.send_header(key, value)
                self.send_header('Transfer-Encoding', 'chunked')
                self.end_headers()
                while True:
                    chunk = response.read(1)
                    if not chunk:
                        break
                    self.wfile.write(b'%x\r\n' % len(chunk) + chunk + b'\r\n')
                    self.wfile.flush()
                self.wfile.write(b'0\r\n\r\n'); self.wfile.flush()
                response.close()

            def do_GET(self):
                self.relay()

            def do_HEAD(self):
                self.relay()

            def do_POST(self):
                length = int(self.headers.get('Content-Length') or 0)
                self.relay(self.rfile.read(length))

        self.path = Path(path)
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def note(self, method, path, body, headers, status, error):
        try:
            parsed = json.loads(body) if body else None
        except json.JSONDecodeError:
            parsed = None
        record = {'method': method, 'path': path, 'status': status, 'error': error,
                  'headers': {k: ('[redacted]' if k.lower() in REDACTED else v) for k, v in headers.items()},
                  'body': parsed,
                  'bodySha256': hashlib.sha256(body).hexdigest() if body else None}
        self.records.append(record)
        with self.path.open('a') as f:
            f.write(json.dumps(record) + '\n')

    def __enter__(self):
        self.thread.start()
        return f'http://127.0.0.1:{self.server.server_port}'

    def __exit__(self, *args):
        self.server.shutdown(); self.server.server_close(); self.thread.join()


def plan():
    return [{'id': f'discovery-{task}-r{repeat}', 'task': task, 'repeat': repeat, 'arm': 'none'}
            for repeat in [1, 2] for task in ['coldchain', 'printshop']]


def attempt(root, tasks, record, remaining):
    source = Path(tasks)/record['task']
    runtime = Path(tempfile.mkdtemp(prefix='augdisc-run-')).resolve()
    staged = runtime/'task'
    (staged/'data').mkdir(parents=True)
    shutil.copyfile(Path(tasks)/'CONTRACT.md', staged/'CONTRACT.md')
    for p in sorted((source/'data').iterdir()):
        if p.is_symlink() or not p.is_file():
            raise ValueError('Task data must be plain files')
        shutil.copyfile(p, staged/'data'/p.name)
    m.INPUT_FILES = ['CONTRACT.md'] + [f'data/{p.name}' for p in sorted((staged/'data').iterdir())]
    contract = (source/'BRIEF.md').read_text()
    prompt = {'contract': contract, 'effective': contract + '\n' + COMMON}
    with m.local_proxy() as (upstream, routing):
        m.dump(runtime/'routing.json', routing)
        with Recorder(upstream, runtime/'requests.jsonl') as endpoint:
            observed = m.execute_one(runtime, None, prompt, endpoint, remaining, staged)
    return runtime, observed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tasks', required=True)
    parser.add_argument('--tasks-sha256', required=True)
    parser.add_argument('--state', required=True)
    parser.add_argument('--authorize-inference', action='store_true')
    args = parser.parse_args()
    m.TURNS, m.TIMEOUT = TURNS, TIMEOUT
    root = Path(args.state).resolve(); root.mkdir(parents=True, exist_ok=True)
    archive = Path(args.tasks).resolve()
    if m.sha(archive) != args.tasks_sha256:
        raise ValueError('Task archive hash mismatch')
    tasks = root/'tasks'
    if not tasks.exists():
        tasks.mkdir()
        m.extract(archive, tasks) if hasattr(m, 'extract') else shutil.unpack_archive(str(archive), str(tasks))
    state_path = root/'state.json'
    state = json.loads(state_path.read_text()) if state_path.exists() else {
        'stage': 'value-discovery', 'arm': 'none', 'model': m.MODEL, 'turns': TURNS,
        'timeoutSeconds': TIMEOUT, 'costCeiling': CEILING, 'maxAttempts': ATTEMPTS,
        'tasksSha256': args.tasks_sha256, 'claudeSha256': m.sha(m.CLAUDE),
        'instrumentSha256': m.sha(m.SELF), 'runnerSha256': m.sha(Path(__file__).resolve()),
        'records': []}
    m.dump(state_path, state)
    if not args.authorize_inference:
        print(json.dumps({'prepared': str(root), 'inferenceStarted': False, 'plan': plan()}, indent=2)); return
    for planned in plan():
        done = {r['id'] for r in state['records']}
        if planned['id'] in done:
            continue
        spent = sum(r['cost'] for r in state['records'] if isinstance(r.get('cost'), (int, float)))
        blocked = [r for r in state['records'] if not isinstance(r.get('cost'), (int, float))
                   or r['status'] not in ['done', 'budget_exhausted']]
        if blocked or len(state['records']) >= ATTEMPTS or spent >= CEILING:
            print(json.dumps({'stopped': 'unknown cost or outcome, ceiling, or attempt limit',
                              'spent': spent, 'attempts': len(state['records'])})); break
        entry = {**planned, 'status': 'running', 'cost': None, 'startedAt': time.time()}
        state['records'].append(entry); m.dump(state_path, state)
        try:
            runtime, observed = attempt(root, tasks, entry, CEILING - spent)
            entry.update(observed)
        except Exception as exc:
            runtime = None
            entry.update(status='failed', cost=None, error=f'{type(exc).__name__}: {exc}')
        finally:
            if runtime is not None:
                m.collect(runtime, root/'runs'/planned['id'])
                for name in ['requests.jsonl']:
                    if (runtime/name).exists():
                        shutil.copyfile(runtime/name, root/'runs'/planned['id']/name)
                entry['runtime'] = str(runtime)
            m.dump(state_path, state)
        print(json.dumps(entry), flush=True)
        if entry['status'] not in ['done', 'budget_exhausted']:
            print(json.dumps({'stopped': 'attempt did not complete; reconcile before any retry'})); break


if __name__ == '__main__':
    main()
