import ast
import unittest
from pathlib import Path

import instrument


class LaunchContract(unittest.TestCase):
    def test_no_ineffective_managed_override(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            env = instrument.run_environment(Path(d), 'http://127.0.0.1:1')
        self.assertNotIn('CLAUDE_CODE_MANAGED_SETTINGS_PATH', env)

    def test_proxy_is_inside_attempt_not_campaign(self):
        tree = ast.parse(Path(instrument.__file__).read_text())
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run_variant')
        loop = next(n for n in ast.walk(fn) if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == 'planned')
        proxies = [n for n in ast.walk(loop) if isinstance(n, ast.With)
                   and any(isinstance(i.context_expr, ast.Call)
                           and isinstance(i.context_expr.func, ast.Name)
                           and i.context_expr.func.id == 'local_proxy' for i in n.items)]
        self.assertEqual(len(proxies), 1)


if __name__ == '__main__':
    unittest.main()
