"""Observe bundled proxy transforms with fake credentials and mock upstream only."""
from pathlib import Path
import json
import os
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

from qualify import Mock, ROOT
import instrument as m


def run(kind, body, provenance):
    dest = ROOT/'proxy-evidence'/kind
    dest.mkdir(parents=True, exist_ok=False)
    with tempfile.TemporaryDirectory(prefix='aug-proxy-mock-') as d, Mock([]) as upstream:
        root = Path(d).resolve()
        (root/'auth').mkdir()
        with socket.socket() as s:
            s.bind(('127.0.0.1',0)); port = s.getsockname()[1]
        # Synthetic, non-working keys. Never consult real proxy config/auth files.
        token = 'sk-ant-oat01-OFFLINE-NOT-A-CREDENTIAL' if kind == 'oauth-shaped' else 'OFFLINE-NOT-A-CREDENTIAL'
        config = {'host':'127.0.0.1','port':port,'auth-dir':str(root/'auth'),
                  'request-retry':0,'request-timeout':10,'debug':False,'logging-to-file':False,
                  'remote-management':{'disable-auto-update-panel':True},
                  'quota-exceeded':{'switch-project':False,'switch-preview-model':False},
                  'claude-api-key':[{'api-key':token,'base-url':f'http://127.0.0.1:{upstream.server.server_port}',
                                     'models':[{'name':m.MODEL,'alias':m.MODEL}]}]}
        m.dump(root/'config.json', config)
        profile = '\n'.join([
            '(version 1)', '(allow default)', '(deny network*)',
            f'(allow network-bind (local ip "localhost:{port}"))',
            f'(allow network-inbound (local ip "localhost:{port}"))',
            f'(allow network-outbound (remote ip "localhost:{upstream.server.server_port}"))',
            '(deny file-read-data (subpath '+json.dumps(str(Path.home()))+'))',
            '(deny file-write* (subpath '+json.dumps(str(Path.home()))+'))',
        ])+'\n'
        (root/'network.sb').write_text(profile)
        env = {'HOME':str(root),'PATH':'/usr/bin:/bin','TMPDIR':str(root),'LANG':'en_US.UTF-8'}
        command = ['/usr/bin/sandbox-exec','-f',str(root/'network.sb'),str(m.PROXY),'-config',str(root/'config.json'),'-local-model']
        m.dump(dest/'launch.json', {'command':command,'environment':env,'syntheticConfig':config,'sandbox':profile,
                                  'binarySha256':m.sha(m.PROXY)})
        with (root/'proxy.log').open('w') as log:
            p = subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
            response = None
            try:
                for _ in range(50):
                    if p.poll() is not None:
                        raise RuntimeError('Offline proxy exited')
                    try:
                        with urllib.request.urlopen(f'http://127.0.0.1:{port}/v1/models',timeout=1) as r:
                            catalog = json.load(r)
                        break
                    except OSError:
                        time.sleep(.1)
                else:
                    raise RuntimeError('Offline proxy startup timed out')
                m.dump(dest/'catalog.json', catalog)
                request = urllib.request.Request(f'http://127.0.0.1:{port}/v1/messages',
                          data=json.dumps(body).encode(), headers={'Content-Type':'application/json',
                          'anthropic-version':'2023-06-01','User-Agent':'claude-cli/2.1.282 (external, cli)'})
                try:
                    with urllib.request.urlopen(request,timeout=15) as r:
                        response = {'status':r.status,'body':r.read().decode()}
                except urllib.error.HTTPError as e:
                    response = {'status':e.code,'body':e.read().decode()}
                m.dump(dest/'response.json', response)
            finally:
                p.terminate()
                try: p.wait(timeout=3)
                except subprocess.TimeoutExpired: p.kill(); p.wait()
                m.dump(dest/'upstream-requests.json', upstream.requests)
                (dest/'proxy.log').write_text((root/'proxy.log').read_text())
        if not upstream.requests or response['status'] != 200:
            # Known structural gap: an OAuth-shaped key makes the executor demand a
            # profile from the real provider before forwarding, so its post-transform
            # payload cannot be observed offline. Recorded, never claimed as clean.
            m.dump(dest/'comparison.json', {'inputProvenance':provenance, 'observed':False,
                                            'reason':'proxy did not forward to the mock upstream',
                                            'status':response and response['status'], 'noInference':True})
            print(json.dumps({'kind':kind,'upstreamRequests':len(upstream.requests),
                              'status':response and response['status'],'observed':False}),flush=True)
            return
        post = upstream.requests[-1]['body']
        m.dump(dest/'comparison.json', {
            'inputProvenance':provenance,
            'observed':True,
            'changedTopLevelKeys':[k for k in sorted(set(body)|set(post)) if body.get(k)!=post.get(k)],
            'inputSystem':body.get('system'), 'outputSystem':post.get('system'),
            'inputMessages':body.get('messages'), 'outputMessages':post.get('messages'),
            'noInference':True,
            'limit':'Synthetic configured API-key entry, OAuth-shaped token is not real auth-file route attestation.'})
        print(json.dumps({'kind':kind,'upstreamRequests':len(upstream.requests),
                          'status':response['status'],'observed':True}),flush=True)


if __name__ == '__main__':
    source = ROOT/'evidence/negative/requests.json'
    body = json.loads(source.read_text())[0]['body']
    provenance = {'source':str(source.relative_to(ROOT)), 'sourceSha256':m.sha(source),
                  'bodySha256':__import__('hashlib').sha256(json.dumps(body,sort_keys=True).encode()).hexdigest()}
    for kind in ['api-key','oauth-shaped']:
        run(kind, body, provenance)
