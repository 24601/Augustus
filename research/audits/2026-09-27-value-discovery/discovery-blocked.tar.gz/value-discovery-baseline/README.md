# Isolation qualification by captured request payloads (no inference)

Every run here talks to a scripted loopback HTTP server. **No model inference,
no provider call, no spend, no normal-configuration change.** Sentinel skills and
ancestor guidance exist only inside disposable synthetic `HOME`/`CLAUDE_CONFIG_DIR`/
ancestor trees under a temporary directory; the real user global skill repository,
installed plugins and settings were never written or read as configuration.

Pinned agent CLI: `2.1.282`, sha256
`fcfd837103965c64de34a6b9b94370d77a347ea71819715a27d5f0ef01775ea4`. The
qualifier refuses to run against a different binary.

## What the captured payloads actually show

`instrument/qualify.py` records the complete request body (`system`, `messages`,
`tools`), plus request headers, for each POST.

| Mode | Launch | Wire result |
| --- | --- | --- |
| `negative` | pilot flags: `--restricted`, `--setting-sources ''`, `CLAUDE_CODE_DISABLE_CLAUDE_MDS=1` | No sentinel string, no sentinel skill **name**, no `augustus` substring, and neither released skill description anywhere in the payload |
| `positive-plugin` | same, plus `--plugin-dir`/`--add-dir` on a synthetic plugin | Both skill *descriptions* present in the first request's skill listing; neither *body* present until its `Skill` call, then both bodies appear; no config/home/ancestor sentinel |
| `guidance-claude-control` | `--setting-sources user,project,local`, no `--restricted`, CLAUDE.md enabled | Ancestor `CLAUDE.md` and config-dir `CLAUDE.md` sentinels present; config-dir skills advertised, including the real `- augustus:` description and `canary-9d73b2-config` |
| `guidance-agents-control` | same, with ancestor `AGENTS.md` and no ancestor `CLAUDE.md` | Ancestor `AGENTS.md` sentinel present via the bundled `agents-md` plugin |

The two controls are the point: they prove these channels are **observable on the
wire when enabled**, so the baseline's absence is a measurement, not a blind spot.
`--restricted` is the operative control; a further control run with relaxed
setting sources but `--restricted` still present showed no injection at all.

Also verified in `positive-plugin`: the bare skill name `augustus-train` resolves
(the explicit arm's wording does not name `.agents:`), every `tool_use` has a
recorded guard decision, the Bash command is rewritten into the Python sandbox,
and the in-sandbox probe reports `network=DENIED,home=DENIED`.

## Categorized baseline prompt inventory

From `evidence/negative/`, reviewed locally in full. Hashes and byte counts per
category and per system block are in `inventory.json`.

- 3 `system` blocks: a billing/version header (74 B), an SDK identity line (62 B),
  and the agent instruction block (3564 B) which names the model and lists the
  **bundled** skills (`dataviz`, `verify`, `debug`, …).
- 1 `user` message plus a trailing `system` message. The only `<system-reminder>`
  is Claude Code's git attribution guidance.
- 7 tool schemas: `Bash`, `Edit`, `Glob`, `Grep`, `Read`, `Skill`, `Write`. The
  `Skill` schema is byte-identical between baseline and plugin arms (the plugin
  skills are advertised in the instruction text, not the schema).
- Other top-level keys: `context_management`, `max_tokens`, `metadata`, `model`,
  `output_config`, `stream`, `thinking`.

Nothing unexpected was found, but note the scope: **"no Augustus" is verified;
"no skills at all" is false** — bundled skill descriptions are present in every
arm, constant across arms, and their invocation is denied by the guard.

## Corrections to earlier isolation claims

- `CLAUDE_CODE_MANAGED_SETTINGS_PATH` is **dropped**. In this build the managed
  directory override getter returns nothing, so it never contributed isolation.
  `instrument/test_contract.py` fails if it returns.
- Standard managed-settings paths were checked for presence and file hashes only,
  before and after the runs (`evidence/managed-paths.json`): both absent and
  unchanged. The qualifier stops if either exists.
- The main CLI process is **not** under Seatbelt. An outer network fence was
  attempted and reverted: nesting Seatbelt makes the stricter Python tool sandbox
  fail with `sandbox_apply: Operation not permitted`, which would break every
  Bash call. CLI egress containment is therefore the constructed environment
  (loopback `ANTHROPIC_BASE_URL`, placeholder token, fresh `HOME`/config/TMPDIR),
  not OS policy. Request headers confirm only `Authorization: Bearer
  local-vibeproxy-placeholder` and no `x-api-key`.
- Plugin snapshots are now copied to a neutral `runtime/plugin/.agents` path,
  because `--add-dir` puts the directory name in the prompt and an `old`/`new`
  path would have told the model which arm it was in.
- A missing guard decision is now a `guard-coverage` protocol failure: a hook that
  fails to spawn is treated as non-blocking by the CLI, so silence must fail the run.
- `TASK.md` is included in the post-run input-integrity check.

## Post-proxy transform: partly verified, partly residual

`instrument/proxy_offline.py` starts the bundled CLIProxyAPI 7.3.17 binary
(sha256 `c18062c8a020e74ba8d57eb7816fc69c12e16854798b718725620bc41d2b310c`) with a
**synthetic non-working key**, a mock upstream, and an OS sandbox that permits
only the two loopback ports. It never reads the normal proxy configuration or
credential files.

- `api-key` route: the proxy forwarded the captured baseline body with **no
  changed top-level keys**; `system` and `messages` are byte-identical
  (`proxy-evidence/api-key/comparison.json`).
- `oauth-shaped` route: **not observed.** An `sk-ant-oat`-shaped key makes the
  executor fetch an OAuth profile from the hard-coded real provider host before
  forwarding anything; the sandbox blocked that, so the request never reached the
  mock upstream (HTTP 500, recorded with `observed: false`). No provider was
  contacted.

**Residual, not a clean claim:** the campaign's actual route is auth-file OAuth to
the official base URL, and that hop is *not* qualified here. The binary contains
cloaking, forwarded-system-prompt-collection and cache-control-injection symbols,
so byte transparency on that route is uncharacterized. It is however identical
across arms (it depends on neither the plugin directory nor the prompt prefix), so
it cannot differentially contaminate a comparison, even though it can shape the
absolute prompt.

## Reproduce

```bash
cd .amp/in/artifacts/isolation-qualification
PYTHONDONTWRITEBYTECODE=1 python3 instrument/test_contract.py
PYTHONDONTWRITEBYTECODE=1 python3 instrument/qualify.py        # writes evidence/
PYTHONDONTWRITEBYTECODE=1 python3 instrument/proxy_offline.py  # writes proxy-evidence/
```

Each needs its output directory to be absent. None of them performs inference.

## For the next paid pilot

`instrument/instrument.py` now starts and stops the temporary proxy **inside each
attempt**, so no proxy process state is shared between runs, and each run keeps its
own `routing.json`. Remaining known items to disclose or fix before spending:
the proxy launch in the campaign path still inherits the operator environment and
attempts its own startup update fetches; and the temporary credential copy can be
refreshed by the proxy, which may rotate the normal token.
