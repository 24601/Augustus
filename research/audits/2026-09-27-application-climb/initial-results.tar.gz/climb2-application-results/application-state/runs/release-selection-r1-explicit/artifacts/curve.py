"""Loss curve for compact around its optimum on post-change rows."""
import json
rows = [r for r in json.load(open("rows.json")) if r["day"] >= 90]
for t in [0.02, 0.03, 0.04, 0.05, 0.055, 0.06, 0.065, 0.07, 0.075, 0.08, 0.09, 0.1, 0.12, 0.15, 0.2]:
    fn = sum(1 for r in rows if r["fraud"] and r["scores"]["compact"] < t)
    fp = sum(1 for r in rows if not r["fraud"] and r["scores"]["compact"] >= t)
    print(f"t={t:<6} fn={fn:2d} fp={fp:3d} loss={(8*fn+fp)/len(rows):.3f} review_rate={sum(1 for r in rows if r['scores']['compact']>=t)/len(rows):.2f}")
fr = sorted(r["scores"]["compact"] for r in rows if r["fraud"])
print("fraud compact scores lowest:", fr[:6])
