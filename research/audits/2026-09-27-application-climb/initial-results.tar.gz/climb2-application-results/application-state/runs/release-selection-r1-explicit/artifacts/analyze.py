"""Per-stock, per-era discrimination and cost-optimal threshold analysis."""
import json, random
rows = json.load(open("rows.json"))
FN, FP = 8, 1

def auc(S, k):
    pos = [r["scores"][k] for r in S if r["fraud"]]
    neg = [r["scores"][k] for r in S if not r["fraud"]]
    w = sum((p > n) + 0.5 * (p == n) for p in pos for n in neg)
    return w / (len(pos) * len(neg))

def loss(S, k, t, direction=1):
    L = 0
    for r in S:
        s = r["scores"][k] * direction
        review = s >= t * direction if direction == 1 else s >= t * direction
        if review and not r["fraud"]: L += FP
        if not review and r["fraud"]: L += FN
    return L / len(S)

def best_t(S, k):
    cands = sorted(set(r["scores"][k] for r in S)) + [1.01]
    best = None
    for t in cands:
        l = loss(S, k, t)
        if best is None or l < best[0]: best = (l, t)
    return best

eras = {
    "pre<90": [r for r in rows if r["day"] < 90],
    "post>=90": [r for r in rows if r["day"] >= 90],
    "d90-109": [r for r in rows if 90 <= r["day"] < 110],
    "d110-119": [r for r in rows if r["day"] >= 110],
}
for name, S in eras.items():
    print(f"== {name} n={len(S)} fraud={sum(r['fraud'] for r in S)}")
    for k in ("legacy", "compact", "large"):
        bl, bt = best_t(S, k)
        print(f"  {k:8s} auc={auc(S,k):.3f} loss@0.5={loss(S,k,0.5):.3f} in-sample best loss={bl:.3f} t={bt}")

# Temporal: fit threshold on 90-109, evaluate on 110-119
tr, te = eras["d90-109"], eras["d110-119"]
print("== temporal fit 90-109 -> test 110-119")
for k in ("legacy", "compact", "large"):
    bl, bt = best_t(tr, k)
    print(f"  {k:8s} t={bt} train={bl:.3f} test={loss(te,k,bt):.3f}")
# Using all history to fit (shift check)
print("== fit on all history -> test 110-119 / post")
for k in ("legacy", "compact"):
    bl, bt = best_t(rows, k)
    print(f"  {k:8s} t={bt} post={loss(eras['post>=90'],k,bt):.3f} test={loss(te,k,bt):.3f}")
print("constant review post:", sum(1 for r in eras["post>=90"] if not r["fraud"]) / 300,
      "constant allow post:", 8 * sum(r["fraud"] for r in eras["post>=90"]) / 300)
