"""Fraud-review decision for the new checkout funnel (standard library only).

Policy: register the `compact` stock (9 ms, within the 15 ms allowance) and
review when its score >= a cost-tuned threshold. The threshold is fitted only on
rows from the current funnel (day >= FUNNEL_CHANGE_DAY), because the funnel
changed on day 90 and older rows do not represent next week's traffic. `day` and
`fraud` are used only at fit time; serving uses only `scores[stock]`.

Missing, non-numeric, boolean, non-finite or out-of-[0,1] scores -> review.
"""
import math

VERSION = 1
FUNNEL_CHANGE_DAY = 90  # operations.md: checkout funnel changed on day 90
MIN_CURRENT_ROWS = 100


def _valid_score(v):
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return False
    return math.isfinite(v) and 0.0 <= v <= 1.0


def _loss(pairs, t, fn_cost, fp_cost):
    total = 0
    for s, y in pairs:
        review = s >= t
        if review and not y:
            total += fp_cost
        elif not review and y:
            total += fn_cost
    return total / len(pairs)


def _candidate_thresholds(scores):
    u = sorted(set(scores))
    mids = [(a + b) / 2 for a, b in zip(u, u[1:])]
    return [0.0] + mids + [1.0 + 1e-9]


def _fit_threshold(pairs, fn_cost, fp_cost):
    """Midpoint threshold minimizing empirical cost; ties go to the lower
    (more reviewing) threshold."""
    cands = _candidate_thresholds([s for s, _ in pairs])
    return min(cands, key=lambda t: (_loss(pairs, t, fn_cost, fp_cost), t))


def fit(rows, config):
    fn_cost = config.get("fn_cost", 8)
    fp_cost = config.get("fp_cost", 1)
    max_latency = config.get("max_latency_ms", 15)
    stock = "compact"
    latency = config["stocks"][stock]["latency_ms"]
    if latency > max_latency:
        raise ValueError(f"{stock} latency {latency} ms exceeds {max_latency} ms")

    current = [r for r in rows if r.get("day", -1) >= FUNNEL_CHANGE_DAY]
    pairs = [(r["scores"][stock], int(r["fraud"])) for r in current
             if _valid_score(r.get("scores", {}).get(stock))]
    if len(pairs) < MIN_CURRENT_ROWS:
        # Too little current-funnel evidence to set a cut: review everything.
        return {
            "version": VERSION,
            "stock": "constant",
            "action": "review",
            "warning": f"only {len(pairs)} valid current-funnel rows; need {MIN_CURRENT_ROWS}",
        }

    threshold = _fit_threshold(pairs, fn_cost, fp_cost)
    return {
        "version": VERSION,
        "stock": stock,
        "latency_ms": latency,
        "threshold": threshold,
        "rule": "review if score is invalid or score >= threshold",
        "fit_summary": {
            "rows_used": len(pairs),
            "min_day": FUNNEL_CHANGE_DAY,
            "fraud_rate": sum(y for _, y in pairs) / len(pairs),
            "in_sample_loss": _loss(pairs, threshold, fn_cost, fp_cost),
        },
    }


def decide(artifact, row):
    try:
        stock = artifact["stock"]
        if stock == "constant":
            return "allow" if artifact.get("action") == "allow" else "review"
        threshold = float(artifact["threshold"])
        score = row["scores"][stock]
    except (KeyError, TypeError, ValueError):
        return "review"
    if not math.isfinite(threshold) or not _valid_score(score):
        return "review"
    return "review" if score >= threshold else "allow"
