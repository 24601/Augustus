"""Validate the fit procedure on held-out current-funnel rows.

Compares: shipped (compact, threshold fitted on current funnel only), compact
threshold fitted on all history, legacy incumbent >= 0.5, legacy refit on the
current funnel, cost-optimal constant. (A bootstrap-smoothed threshold was also
tried and gave identical out-of-fold loss, so it was dropped.) All candidates are fitted on train folds only.
"""
import json, random
import solution

rows = json.load(open("rows.json"))
config = json.load(open("config.json"))
FN, FP = config["fn_cost"], config["fp_cost"]
post = [r for r in rows if r["day"] >= 90]
pre = [r for r in rows if r["day"] < 90]


def mean_loss(decider, S):
    L = 0
    for r in S:
        d = decider(r)
        if d == "review" and not r["fraud"]: L += FP
        if d == "allow" and r["fraud"]: L += FN
    return L / len(S)


def raw_min_threshold(S, k):
    pairs = [(r["scores"][k], r["fraud"]) for r in S]
    cands = solution._candidate_thresholds([s for s, _ in pairs])
    return min(cands, key=lambda t: (solution._loss(pairs, t, FN, FP), t))


def candidates(train):
    art = solution.fit(pre + train, config)  # fit must itself ignore pre rows
    t_all_c = raw_min_threshold(pre + train, "compact")
    t_raw_l = raw_min_threshold(train, "legacy")
    n_fraud = sum(r["fraud"] for r in train)
    const = "review" if FP * (len(train) - n_fraud) < FN * n_fraud else "allow"
    return {
        "shipped_compact": lambda r: solution.decide(art, {"request_id": r["request_id"], "scores": {"compact": r["scores"]["compact"]}}),
        "compact_all_history": lambda r: "review" if r["scores"]["compact"] >= t_all_c else "allow",
        "legacy>=0.5": lambda r: "review" if r["scores"]["legacy"] >= 0.5 else "allow",
        "legacy_refit": lambda r: "review" if r["scores"]["legacy"] >= t_raw_l else "allow",
        "constant": lambda r: const,
    }, art


print("== temporal: train day 90-109, test day 110-119")
tr = [r for r in post if r["day"] < 110]
te = [r for r in post if r["day"] >= 110]
c, art = candidates(tr)
print("  shipped threshold", round(art["threshold"], 5))
for k, f in c.items():
    print(f"  {k:22s} test={mean_loss(f, te):.3f}")

print("== repeated 5-fold CV over current-funnel rows (20 repeats), out-of-fold loss")
rng = random.Random(7)
agg = {}
thr = []
per_repeat = {}
for rep in range(20):
    idx = list(range(len(post)))
    rng.shuffle(idx)
    folds = [idx[i::5] for i in range(5)]
    tot = {}
    for f in folds:
        fs = set(f)
        train = [post[i] for i in idx if i not in fs]
        test = [post[i] for i in f]
        c, art = candidates(train)
        thr.append(art["threshold"])
        for k, fn in c.items():
            tot[k] = tot.get(k, 0) + mean_loss(fn, test) * len(test)
    for k, v in tot.items():
        per_repeat.setdefault(k, []).append(v / len(post))
for k, v in per_repeat.items():
    v = sorted(v)
    print(f"  {k:22s} mean={sum(v)/len(v):.3f} range=[{v[0]:.3f},{v[-1]:.3f}]")
thr.sort()
print(f"  shipped thresholds across folds: min={thr[0]:.4f} median={thr[len(thr)//2]:.4f} max={thr[-1]:.4f}")

print("== bootstrap 95% CI of one OOF repeat for shipped policy (row-level resample)")
idx = list(range(len(post)))
random.Random(11).shuffle(idx)
folds = [idx[i::5] for i in range(5)]
oof = [0] * len(post)
for f in folds:
    fs = set(f)
    art = solution.fit([post[i] for i in idx if i not in fs], config)
    for i in f:
        r = post[i]
        d = solution.decide(art, {"request_id": r["request_id"], "scores": {"compact": r["scores"]["compact"]}})
        oof[i] = FP if (d == "review" and not r["fraud"]) else FN if (d == "allow" and r["fraud"]) else 0
b = random.Random(3)
means = sorted(sum(oof[b.randrange(300)] for _ in range(300)) / 300 for _ in range(4000))
print(f"  OOF mean={sum(oof)/300:.3f} 95% CI=[{means[100]:.3f},{means[3900]:.3f}] P(loss>0.45)={sum(m>0.45 for m in means)/len(means):.4f}")
