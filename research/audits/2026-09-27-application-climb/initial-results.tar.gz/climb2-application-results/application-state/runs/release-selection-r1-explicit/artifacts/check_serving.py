"""Fit, export artifact.json, reload in a fresh process, replay and edge-test."""
import json, subprocess, sys, time
import solution

rows = json.load(open("rows.json"))
config = json.load(open("config.json"))
art = solution.fit(rows, config)
text = json.dumps(art, indent=2, allow_nan=False)
open("artifact.json", "w").write(text)
print(text)
assert art["stock"] in config["stocks"] and config["stocks"][art["stock"]]["latency_ms"] <= config["max_latency_ms"]

serving = [{"request_id": r["request_id"], "scores": {art["stock"]: r["scores"][art["stock"]]}} for r in rows]
local = [solution.decide(art, s) for s in serving]
open("serving_rows.json", "w").write(json.dumps(serving))

edge = [
    {"request_id": "a", "scores": {}},
    {"request_id": "b"},
    {"request_id": "c", "scores": None},
    {"request_id": "d", "scores": {"compact": None}},
    {"request_id": "e", "scores": {"compact": "0.01"}},
    {"request_id": "f", "scores": {"compact": True}},
    {"request_id": "g", "scores": {"compact": False}},
    {"request_id": "h", "scores": {"compact": float("nan")}},
    {"request_id": "i", "scores": {"compact": float("inf")}},
    {"request_id": "j", "scores": {"compact": -0.01}},
    {"request_id": "k", "scores": {"compact": 1.01}},
    {"request_id": "l", "scores": {"legacy": 0.01}},
    {"request_id": "m", "scores": {"compact": [0.01]}},
    {"request_id": "n", "scores": "compact"},
    None,
]
for e in edge:
    assert solution.decide(art, e) == "review", e
t = art["threshold"]
assert solution.decide(art, {"request_id": "x", "scores": {"compact": t}}) == "review"
assert solution.decide(art, {"request_id": "y", "scores": {"compact": 0.0}}) == "allow"
assert solution.decide(art, {"request_id": "z", "scores": {"compact": 0}}) == "allow"
assert solution.decide(art, {"request_id": "w", "scores": {"compact": 1}}) == "review"
assert solution.decide({"stock": "compact"}, {"request_id": "v", "scores": {"compact": 0.0}}) == "review"
print("edge cases: all invalid inputs -> review; boundary ok")

child = subprocess.run([sys.executable, "check_child.py"], capture_output=True, text=True, timeout=120)
assert child.returncode == 0, child.stderr
fresh = json.loads(child.stdout)
assert fresh["decisions"] == local, "fresh-process replay mismatch"
print("fresh-process replay: identical on", len(local), "rows;",
      f"decide p99={fresh['p99_us']:.1f}us max={fresh['max_us']:.1f}us (plus {config['stocks'][art['stock']]['latency_ms']} ms stock)")

post = [(r, d) for r, d in zip(rows, local) if r["day"] >= 90]
loss = sum(1 if d == "review" and not r["fraud"] else 8 if d == "allow" and r["fraud"] else 0 for r, d in post) / len(post)
print(f"in-sample current-funnel loss={loss:.3f} review_rate={sum(d=='review' for _, d in post)/len(post):.3f}")
