"""Fresh process: only solution.py + artifact.json + serving rows (no outcomes)."""
import json, time
import solution

art = json.load(open("artifact.json"))
serving = json.load(open("serving_rows.json"))
out, lat = [], []
for s in serving:
    t0 = time.perf_counter()
    out.append(solution.decide(art, s))
    lat.append((time.perf_counter() - t0) * 1e6)
lat.sort()
print(json.dumps({"decisions": out, "p99_us": lat[int(0.99 * len(lat))], "max_us": lat[-1]}))
