import json, math
rows = json.load(open("rows.json"))
print(len(rows), rows[0])
keys = set()
for r in rows: keys |= set(r.keys())
print(keys)
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
post = [r for r in rows if r["day"] >= 90]
pre = [r for r in rows if r["day"] < 90]
print("pre", len(pre), "post", len(post))
for name, S in (("pre", pre), ("post", post)):
    print(name, "fraud rate", sum(r["fraud"] for r in S) / len(S))
bad = {}
for r in rows:
    for k, v in r["scores"].items():
        ok = isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 <= v <= 1
        if not ok: bad.setdefault(k, []).append(v)
    for k in ("legacy", "compact", "large"):
        if k not in r["scores"]: bad.setdefault(k, []).append("MISSING")
print({k: (len(v), v[:5]) for k, v in bad.items()})
print(sorted(set(type(r["fraud"]).__name__ + str(r["fraud"]) for r in rows)))
