import json, math
from collections import Counter

rows = json.load(open("rows.json"))
print(type(rows), len(rows))
print(rows[:3])
keys = Counter()
for r in rows:
    keys[tuple(sorted(r))] += 1
print(keys)
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
bad = Counter()
for r in rows:
    for s in ("legacy", "compact", "large"):
        v = r.get("scores", {}).get(s)
        ok = isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 <= v <= 1
        if not ok:
            bad[(s, repr(v)[:20])] += 1
print("invalid", bad)
for name, sel in (("pre", lambda d: d < 90), ("post", lambda d: d >= 90)):
    sub = [r for r in rows if sel(r["day"])]
    print(name, len(sub), "fraud rate", sum(r["fraud"] for r in sub) / max(1, len(sub)))
print(Counter(type(r["fraud"]).__name__ + str(r["fraud"]) for r in rows))
