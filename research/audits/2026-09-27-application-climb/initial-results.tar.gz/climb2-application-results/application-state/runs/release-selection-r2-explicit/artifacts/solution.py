"""Fraud-review decision for the post-day-90 checkout funnel.

fit(rows, config) -> JSON-serializable artifact {"stock", "threshold", ...}
decide(artifact, row) -> "allow" | "review"

Policy: review when the registered stock's score >= threshold; any missing,
malformed, non-finite, boolean or out-of-[0,1] score (or broken artifact)
routes to review. Only stocks within config["max_latency_ms"] are eligible.
Thresholds are chosen on rows from the current funnel only (day >= 90), since
the scores are not calibrated and legacy degraded after the funnel change.
"""
import math

CUTOVER_DAY = 90
MIN_CURRENT_ROWS = 50
FOLDS = 5
VERSION = 1


def _valid(v):
    return (isinstance(v, (int, float)) and not isinstance(v, bool)
            and math.isfinite(v) and 0.0 <= v <= 1.0)


def _cost(review, fraud, fn, fp):
    if review:
        return 0 if fraud else fp
    return fn if fraud else 0


def _best_threshold(pairs, fn, fp):
    """Threshold minimizing total loss for 'review if score >= t'.

    pairs: list of (score, fraud). Returns (total_loss, threshold). The cut is
    placed midway between the last allowed and first reviewed score so small
    score drift does not flip boundary cases; ties prefer the lower threshold
    (more review) because missed fraud is the costlier error.
    """
    pairs = sorted(pairs)
    # Start with review-everything (t = 0).
    total = sum(_cost(True, f, fn, fp) for _, f in pairs)
    best = (total, 0.0)
    i = 0
    n = len(pairs)
    while i < n:
        s = pairs[i][0]
        while i < n and pairs[i][0] == s:
            f = pairs[i][1]
            total += _cost(False, f, fn, fp) - _cost(True, f, fn, fp)
            i += 1
        nxt = pairs[i][0] if i < n else 1.0 + 1e-9
        t = (s + nxt) / 2.0 if i < n else float("inf")
        if total < best[0]:
            best = (total, t)
    return best


def _pairs(rows, stock):
    out = []
    for r in rows:
        v = (r.get("scores") or {}).get(stock)
        if _valid(v):
            out.append((float(v), 1 if r["fraud"] else 0))
    return out


def _cv_loss(rows, stock, fn, fp):
    """Deterministic k-fold loss of the threshold-fitting procedure, per row.

    Rows with invalid scores count as review (the serving fallback)."""
    total = 0
    for k in range(FOLDS):
        tr = [r for i, r in enumerate(rows) if i % FOLDS != k]
        te = [r for i, r in enumerate(rows) if i % FOLDS == k]
        _, t = _best_threshold(_pairs(tr, stock), fn, fp)
        for r in te:
            v = (r.get("scores") or {}).get(stock)
            review = (not _valid(v)) or v >= t
            total += _cost(review, r["fraud"], fn, fp)
    return total / len(rows)


def fit(rows, config):
    fn = config["fn_cost"]
    fp = config["fp_cost"]
    current = [r for r in rows if r.get("day", 0) >= CUTOVER_DAY]
    if len(current) < MIN_CURRENT_ROWS:
        current = list(rows)
    # Deterministic order independent of input order.
    current.sort(key=lambda r: str(r.get("request_id")))
    n = len(current)
    n_fraud = sum(1 for r in current if r["fraud"])

    # Cost-optimal constant (constant review routes everything to the team).
    review_all = (n - n_fraud) * fp / n
    allow_all = n_fraud * fn / n
    candidates = [{"stock": "constant", "action": "review" if review_all <= allow_all else "allow",
                   "cv_loss": min(review_all, allow_all)}]
    if candidates[0]["action"] == "allow":
        # Never ship silent authorization of everything; review-all is the safe constant.
        candidates[0] = {"stock": "constant", "action": "review", "cv_loss": review_all}

    for stock, meta in sorted(config["stocks"].items()):
        if meta["latency_ms"] > config["max_latency_ms"]:
            continue
        cv = _cv_loss(current, stock, fn, fp)
        fit_loss, t = _best_threshold(_pairs(current, stock), fn, fp)
        candidates.append({"stock": stock, "threshold": t if math.isfinite(t) else 2.0,
                           "cv_loss": cv, "fit_loss": fit_loss / n,
                           "latency_ms": meta["latency_ms"]})

    chosen = min(candidates, key=lambda c: (c["cv_loss"], c.get("latency_ms", 0)))
    art = {"version": VERSION, "rule": "review if score >= threshold; invalid -> review",
           "n_fit_rows": n, "fit_fraud_rate": n_fraud / n,
           "candidates": [{k: v for k, v in c.items()} for c in candidates]}
    art.update({k: v for k, v in chosen.items()})
    return art


def decide(artifact, row):
    try:
        stock = artifact["stock"]
        if stock == "constant":
            return "allow" if artifact.get("action") == "allow" else "review"
        t = artifact["threshold"]
        if not _valid(t) and not (isinstance(t, (int, float)) and not isinstance(t, bool) and t > 1):
            return "review"
        v = row["scores"][stock]
        if not _valid(v):
            return "review"
        return "review" if v >= t else "allow"
    except Exception:
        return "review"
