import json, random
from collections import Counter

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
FN, FP = cfg["fn_cost"], cfg["fp_cost"]


def loss(sub, s, t, direction=1):
    # review when direction*score >= direction*t
    tot = 0
    for r in sub:
        v = r["scores"][s]
        rev = v >= t if direction == 1 else v <= t
        if rev and not r["fraud"]:
            tot += FP
        elif not rev and r["fraud"]:
            tot += FN
    return tot / len(sub)


def auc(sub, s):
    pos = [r["scores"][s] for r in sub if r["fraud"]]
    neg = [r["scores"][s] for r in sub if not r["fraud"]]
    w = 0
    for p in pos:
        for n in neg:
            w += 1 if p > n else 0.5 if p == n else 0
    return w / (len(pos) * len(neg))


def best(sub, s):
    cands = sorted({r["scores"][s] for r in sub}) + [1.01]
    return min((loss(sub, s, t), t) for t in cands)


pre = [r for r in rows if r["day"] < 90]
post = [r for r in rows if r["day"] >= 90]
for name, sub in (("pre", pre), ("post", post)):
    print(name, "n", len(sub))
    for s in ("legacy", "compact", "large"):
        vals = Counter(r["scores"][s] for r in sub)
        print(f"  {s:8s} auc={auc(sub, s):.3f} loss@0.5={loss(sub, s, 0.5):.3f} best={best(sub, s)} top-values={vals.most_common(2)}")

# time buckets within post
for lo in range(90, 120, 10):
    b = [r for r in post if lo <= r["day"] < lo + 10]
    print(lo, len(b), sum(r["fraud"] for r in b), {s: round(auc(b, s), 3) for s in ("legacy", "compact", "large")})

# compact zeros
z = [r for r in post if r["scores"]["compact"] == 0]
print("compact==0 post", len(z), "fraud", sum(r["fraud"] for r in z))
z = [r for r in pre if r["scores"]["compact"] == 0]
print("compact==0 pre", len(z), "fraud", sum(r["fraud"] for r in z))
