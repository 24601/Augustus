"""Out-of-sample checks of solution.fit on post-change data (day >= 90)."""
import json, random
import solution

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
post = [r for r in rows if r["day"] >= 90]


def serve_row(art, r):
    s = art["stock"]
    return {"request_id": r["request_id"], "scores": {} if s == "constant" else {s: r["scores"][s]}}


def mean_loss(art, sub):
    tot = 0
    for r in sub:
        d = solution.decide(art, serve_row(art, r))
        if d == "review" and not r["fraud"]:
            tot += cfg["fp_cost"]
        elif d == "allow" and r["fraud"]:
            tot += cfg["fn_cost"]
    return tot / len(sub)


# 1. temporal holdout: fit on everything before day 110, test on 110-119
train = [r for r in rows if r["day"] < 110]
test = [r for r in rows if r["day"] >= 110]
art = solution.fit(train, cfg)
print("temporal fit<110 -> test 110-119:", art, "loss", round(mean_loss(art, test), 4), "n", len(test))
train = [r for r in rows if r["day"] < 100]
test = [r for r in rows if 100 <= r["day"] < 120]
art = solution.fit(train, cfg)
print("temporal fit<100 -> test 100-119:", art, "loss", round(mean_loss(art, test), 4), "n", len(test))

# 2. repeated 5-fold CV over post rows (pre rows always included in fit input)
pre = [r for r in rows if r["day"] < 90]
rng = random.Random(0)
losses = []
for rep in range(20):
    idx = list(range(len(post)))
    rng.shuffle(idx)
    for k in range(5):
        te = [post[i] for i in idx[k::5]]
        tr = [post[i] for i in idx if i not in set(idx[k::5])]
        a = solution.fit(pre + tr, cfg)
        losses.append(mean_loss(a, te))
losses.sort()
m = sum(losses) / len(losses)
print(f"5-fold x20 CV: mean {m:.4f}  fold p5 {losses[len(losses)//20]:.3f} p95 {losses[-len(losses)//20]:.3f} max {losses[-1]:.3f}")

# 3. bootstrap of final artifact's post loss (in-sample; descriptive only)
final = solution.fit(rows, cfg)
per = []
for r in post:
    d = solution.decide(final, serve_row(final, r))
    per.append(cfg["fp_cost"] if d == "review" and not r["fraud"] else cfg["fn_cost"] if d == "allow" and r["fraud"] else 0)
bs = []
for _ in range(2000):
    s = [per[rng.randrange(len(per))] for _ in per]
    bs.append(sum(s) / len(s))
bs.sort()
print("final artifact:", final)
print(f"final in-sample post loss {sum(per)/len(per):.4f}; bootstrap 95% [{bs[50]:.3f}, {bs[1949]:.3f}]")
json.dump(final, open("artifact.json", "w"), indent=2)
