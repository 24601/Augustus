"""Fresh-process reload of artifact.json + failure-path checks. Run after validate.py."""
import json, math, subprocess, sys

CHILD = r'''
import json, sys
sys.path.insert(0, ".")
import solution
art = json.load(open("artifact.json"))
t = art["threshold"]
cases = [
    ({"request_id": "a", "scores": {"compact": t}}, "review"),
    ({"request_id": "b", "scores": {"compact": t - 1e-6}}, "allow"),
    ({"request_id": "c", "scores": {"compact": 0.9}}, "review"),
    ({"request_id": "d", "scores": {"compact": 0}}, "allow"),
    ({"request_id": "e", "scores": {}}, "review"),
    ({"request_id": "f"}, "review"),
    ({"request_id": "g", "scores": {"compact": None}}, "review"),
    ({"request_id": "h", "scores": {"compact": "0.01"}}, "review"),
    ({"request_id": "i", "scores": {"compact": True}}, "review"),
    ({"request_id": "j", "scores": {"compact": False}}, "review"),
    ({"request_id": "k", "scores": {"compact": float("nan")}}, "review"),
    ({"request_id": "l", "scores": {"compact": float("inf")}}, "review"),
    ({"request_id": "m", "scores": {"compact": -0.01}}, "review"),
    ({"request_id": "n", "scores": {"compact": 1.01}}, "review"),
    ({"request_id": "o", "scores": {"legacy": 0.0}}, "review"),
    ({"request_id": "p", "scores": None}, "review"),
    (None, "review"),
]
fails = 0
for row, want in cases:
    got = solution.decide(art, row)
    if got != want:
        fails += 1
        print("FAIL", row, got, want)
assert solution.decide({}, {"scores": {"compact": 0.0}}) == "review"
assert solution.decide({"stock": "compact"}, {"scores": {"compact": 0.0}}) == "review"
rows = json.load(open("rows.json"))
post = [r for r in rows if r["day"] >= 90]
loss = 0
for r in post:
    d = solution.decide(art, {"request_id": r["request_id"], "scores": {"compact": r["scores"]["compact"]}})
    loss += (1 if d == "review" and not r["fraud"] else 8 if d == "allow" and r["fraud"] else 0)
print("stock", art["stock"], "threshold", t, "post replay loss", round(loss / len(post), 4))
print("edge cases failed:", fails)
'''

with open("_child_check.py", "w") as f:
    f.write(CHILD)
art = json.load(open("artifact.json"))
assert json.loads(json.dumps(art)) == art
out = subprocess.run([sys.executable, "_child_check.py"], capture_output=True, text=True)
print(out.stdout, out.stderr)
