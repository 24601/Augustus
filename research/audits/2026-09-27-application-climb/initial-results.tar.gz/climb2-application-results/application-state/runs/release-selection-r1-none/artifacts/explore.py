import json, math, collections

rows = json.load(open("rows.json"))
print(type(rows), len(rows))
print(rows[:3])
keys = collections.Counter(k for r in rows for k in r)
print(keys)
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
post = [r for r in rows if r["day"] >= 90]
pre = [r for r in rows if r["day"] < 90]
print("pre", len(pre), "post", len(post))
for name, sub in (("pre", pre), ("post", post)):
    print(name, "fraud rate", sum(r["fraud"] for r in sub) / max(1, len(sub)))

def valid(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 <= v <= 1

for s in ("legacy", "compact", "large"):
    bad = [r["scores"].get(s) for r in rows if not valid(r["scores"].get(s))]
    print(s, "invalid", len(bad), bad[:10])

def best_thr(sub, s):
    pts = sorted((r["scores"][s], r["fraud"]) for r in sub if valid(r["scores"].get(s)))
    n = len(pts)
    P = sum(y for _, y in pts)
    # threshold t: review if score >= t. start with review everything
    best = (sum(1 - y for _, y in pts) / n, -1.0)
    fn = 0; fp = n - P
    i = 0
    while i < n:
        j = i
        while j < n and pts[j][0] == pts[i][0]:
            fn += pts[j][1]; fp -= 1 - pts[j][1]; j += 1
        thr = pts[j][0] if j < n else 1.01
        loss = (8 * fn + fp) / n
        if loss < best[0]:
            best = (loss, (pts[j - 1][0] + thr) / 2 if j < n else 1.01)
        i = j
    return best

def loss_at(sub, s, t):
    L = 0
    for r in sub:
        v = r["scores"].get(s)
        rev = (not valid(v)) or v >= t
        L += (1 - r["fraud"]) if rev else 8 * r["fraud"]
    return L / len(sub)

for s in ("legacy", "compact", "large"):
    print(s, "legacy>=0.5 post loss", round(loss_at(post, s, 0.5), 4),
          "best pre", best_thr(pre, s), "best post (in-sample)", best_thr(post, s))
print("constant review post", sum(1 - r["fraud"] for r in post) / len(post))
print("constant allow post", 8 * sum(r["fraud"] for r in post) / len(post))
# day distribution post
print(collections.Counter(r["day"] // 10 for r in rows))
