import json, random, collections
from explore import valid, best_thr, loss_at  # reuses helpers (explore prints on import)

rows = json.load(open("rows.json"))
post = [r for r in rows if r["day"] >= 90]
S = "compact"

pos = sorted(r["scores"][S] for r in post if r["fraud"])
neg = sorted(r["scores"][S] for r in post if not r["fraud"])
print("\n--- compact post-change ---")
print("fraud scores (lowest 10):", pos[:10])
print("legit scores (top 25):", neg[-25:])
print("exact zeros: fraud", sum(v == 0 for v in pos), "legit", sum(v == 0 for v in neg))

# Per-10-day block loss of compact at the in-sample thr, and legacy pre/post by block
for blk in range(12):
    sub = [r for r in rows if r["day"] // 10 == blk]
    print(blk, "legacy@0.486", round(loss_at(sub, "legacy", 0.4865), 3),
          "compact@0.07", round(loss_at(sub, S, 0.0704), 3),
          "fraud", sum(r["fraud"] for r in sub))

# Forward-chaining: fit on 90..109, test on 110..119
tr = [r for r in post if r["day"] < 110]; te = [r for r in post if r["day"] >= 110]
l, t = best_thr(tr, S)
print("forward: train loss", round(l, 4), "thr", t, "test loss", round(loss_at(te, S, t), 4))
tr = [r for r in post if r["day"] < 100]; te = [r for r in post if r["day"] >= 100]
l, t = best_thr(tr, S)
print("forward 90-99 -> 100-119: thr", t, "test loss", round(loss_at(te, S, t), 4))

# Repeated 5-fold CV on post rows
rng = random.Random(0)
losses = []; thrs = []
for rep in range(40):
    idx = list(range(len(post))); rng.shuffle(idx)
    for k in range(5):
        te = [post[i] for i in idx[k::5]]
        tr = [post[i] for j, i in enumerate(idx) if j % 5 != k]
        _, t = best_thr(tr, S); thrs.append(t)
        losses.append(loss_at(te, S, t) * len(te))
print("CV mean loss", round(sum(losses) / (40 * len(post)), 4))
print("thr spread", min(thrs), sorted(thrs)[len(thrs) // 2], max(thrs))

# Bootstrap of the chosen rule's loss on post rows (uncertainty on next week)
_, T = best_thr(post, S)
bs = []
for _ in range(2000):
    smp = [post[rng.randrange(len(post))] for _ in post]
    bs.append(loss_at(smp, S, T))
bs.sort()
print("in-sample thr", T, "bootstrap 95% of loss", bs[50], bs[1950], "P(loss>0.45)", sum(b > 0.45 for b in bs) / len(bs))
# Loss curve around threshold
for t in (0.02, 0.04, 0.05, 0.06, 0.0704, 0.08, 0.1, 0.15, 0.2, 0.3):
    print("thr", t, round(loss_at(post, S, t), 4), "review rate",
          round(sum(r["scores"][S] >= t for r in post) / len(post), 3))
