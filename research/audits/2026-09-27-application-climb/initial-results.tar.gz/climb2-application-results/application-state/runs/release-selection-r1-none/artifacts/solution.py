"""Fraud-review decision: one latency-eligible stock + a cost-optimal threshold.

fit() uses only post-funnel-change rows (day >= CHANGE_DAY, per operations.md),
drops stocks over the latency allowance, picks the stock with the lowest
cross-validated post-change loss, and sets its cost-minimising threshold.
decide() reviews on any missing/invalid score (fail closed).
"""
import math
import random

CHANGE_DAY = 90  # checkout funnel change (operations.md); earlier rows are a different regime
CV_FOLDS = 5
CV_REPEATS = 10


def _valid(v):
    return (isinstance(v, (int, float)) and not isinstance(v, bool)
            and math.isfinite(v) and 0.0 <= v <= 1.0)


def _best_threshold(pts, fn_cost, fp_cost):
    """pts: list of (score, fraud). Review iff score >= threshold. Returns (loss, thr)."""
    pts = sorted(pts)
    n = len(pts)
    fn, fp = 0, sum(1 - y for _, y in pts)
    best = ((fp_cost * fp) / n, 0.0)  # review everything
    i = 0
    while i < n:
        j = i
        while j < n and pts[j][0] == pts[i][0]:
            fn += pts[j][1]
            fp -= 1 - pts[j][1]
            j += 1
        loss = (fn_cost * fn + fp_cost * fp) / n
        # Midpoint between this tied group and the next score (allow-all above max).
        thr = (pts[j - 1][0] + pts[j][0]) / 2 if j < n else 1.0 + 1e-9
        if loss < best[0] - 1e-12:
            best = (loss, thr)
        i = j
    return best


def _loss(pts, thr, fn_cost, fp_cost):
    return sum(fp_cost * (1 - y) if s >= thr else fn_cost * y for s, y in pts) / len(pts)


def _cv_loss(pts, fn_cost, fp_cost, rng):
    total = 0.0
    for _ in range(CV_REPEATS):
        idx = list(range(len(pts)))
        rng.shuffle(idx)
        for k in range(CV_FOLDS):
            te = [pts[i] for i in idx[k::CV_FOLDS]]
            tr = [pts[i] for j, i in enumerate(idx) if j % CV_FOLDS != k]
            thr = _best_threshold(tr, fn_cost, fp_cost)[1]
            total += _loss(te, thr, fn_cost, fp_cost) * len(te)
    return total / (CV_REPEATS * len(pts))


def fit(rows, config, seed=0):
    fn_cost = config.get("fn_cost", 8)
    fp_cost = config.get("fp_cost", 1)
    max_lat = config.get("max_latency_ms", 15)
    rng = random.Random(seed)
    recent = [r for r in rows if r.get("day", 0) >= CHANGE_DAY] or list(rows)
    n = len(recent)
    frauds = sum(1 for r in recent if r["fraud"])

    # Constant fallback: review-all vs allow-all.
    review_all, allow_all = fp_cost * (n - frauds) / n, fn_cost * frauds / n
    best = {"stock": "constant", "action": "review" if review_all <= allow_all else "allow",
            "cv_loss": min(review_all, allow_all)}
    report = {"constant": best["cv_loss"]}

    for name, info in sorted(config.get("stocks", {}).items()):
        if info.get("latency_ms", float("inf")) > max_lat:
            report[name] = "ineligible: latency"
            continue
        # Invalid training scores are reviewed at serving, so they cost fp/0 regardless of thr;
        # the threshold is fitted on valid ones and the CV below is on valid rows only.
        pts = [(float(r["scores"][name]), int(r["fraud"])) for r in recent
               if _valid(r.get("scores", {}).get(name))]
        if len(pts) < 50:
            report[name] = "ineligible: too few valid scores"
            continue
        cv = _cv_loss(pts, fn_cost, fp_cost, rng)
        report[name] = cv
        if cv < best["cv_loss"]:
            thr = _best_threshold(pts, fn_cost, fp_cost)[1]
            best = {"stock": name, "threshold": thr, "cv_loss": cv,
                    "in_sample_loss": _loss(pts, thr, fn_cost, fp_cost)}

    best["fit_rows"] = n
    best["change_day"] = CHANGE_DAY
    best["candidates_cv_loss"] = report
    return best


def decide(artifact, row):
    try:
        stock = artifact["stock"]
        if stock == "constant":
            return "allow" if artifact.get("action") == "allow" else "review"
        v = row["scores"][stock]
        thr = float(artifact["threshold"])
    except Exception:
        return "review"
    if not _valid(v) or not math.isfinite(thr):
        return "review"
    return "review" if v >= thr else "allow"
