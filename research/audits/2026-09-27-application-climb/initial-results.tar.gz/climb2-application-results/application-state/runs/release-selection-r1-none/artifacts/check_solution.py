import json, subprocess, sys, math
import solution

rows = json.load(open("rows.json"))
config = json.load(open("config.json"))
post = [r for r in rows if r["day"] >= 90]


def loss(art, sub):
    L = 0
    for r in sub:
        d = solution.decide(art, {"request_id": r["request_id"],
                                  "scores": {art["stock"]: r["scores"].get(art["stock"])}}
                            if art["stock"] != "constant" else {"request_id": r["request_id"], "scores": {}})
        L += (1 - r["fraud"]) if d == "review" else 8 * r["fraud"]
    return L / len(sub)


# 1. Forward-chaining holdouts: fit on earlier data (incl. pre-change, which fit filters), test later.
for cut in (100, 105, 110, 115):
    tr = [r for r in rows if r["day"] < cut]
    te = [r for r in rows if r["day"] >= cut]
    a = solution.fit(tr, config)
    print(f"cut={cut} stock={a['stock']} thr={a.get('threshold'):.5f} "
          f"test_loss={loss(a, te):.4f} n_test={len(te)}")

# 2. Final artifact
art = solution.fit(rows, config)
print(json.dumps(art, indent=1))
print("in-sample post-change loss", loss(art, post))
with open("artifact.json", "w") as f:
    json.dump(art, f)

# 3. Fail-closed cases
bad = [None, "0.01", True, False, float("nan"), float("inf"), -0.1, 1.5, [0.01], {}]
for v in bad:
    assert solution.decide(art, {"request_id": "x", "scores": {art["stock"]: v}}) == "review", v
assert solution.decide(art, {"request_id": "x", "scores": {}}) == "review"
assert solution.decide(art, {"request_id": "x"}) == "review"
assert solution.decide(art, {"request_id": "x", "scores": {"legacy": 0.0}}) == "review"
assert solution.decide(art, {"request_id": "x", "scores": {art["stock"]: 0}}) == "allow"
assert solution.decide({}, {"scores": {}}) == "review"
print("fail-closed checks OK")

# 4. Fresh process, JSON reload
code = ("import json, solution; a=json.load(open('artifact.json'));"
        "print(solution.decide(a, {'request_id':'r','scores':{a['stock']:0.5}}),"
        "solution.decide(a, {'request_id':'r','scores':{a['stock']:0.0}}),"
        "solution.decide(a, {'request_id':'r','scores':{}}))")
out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
print("fresh process:", out.stdout.strip(), out.stderr.strip())
