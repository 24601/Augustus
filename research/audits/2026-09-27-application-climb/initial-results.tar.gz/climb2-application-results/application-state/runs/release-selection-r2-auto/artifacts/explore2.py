import json, random

rows = json.load(open("rows.json"))
post = [r for r in rows if r["day"] >= 90]
pts = sorted((r["scores"]["compact"], r["fraud"], r["day"]) for r in post)
# binned fraud rate by compact score deciles
k = len(pts) // 10
for i in range(10):
    b = pts[i * k:(i + 1) * k]
    print("decile", i, "range %.4f-%.4f" % (b[0][0], b[-1][0]), "fraud", sum(p[1] for p in b))
print("fraud scores:", [round(p[0], 4) for p in pts if p[1]])
print("max legit score below 0.1:", sorted(p[0] for p in pts if not p[1])[:15])
# daily fraud rate per week post
for w in range(90, 120, 10):
    s = [p for p in pts if w <= p[2] < w + 10]
    print("days", w, len(s), sum(p[1] for p in s))


def loss(pts, t):
    return sum(8 * y if s < t else (1 - y) for s, y, *_ in pts) / len(pts)


def best_t(pts):
    fr = sorted(p[0] for p in pts if p[1])
    cands = sorted(set(p[0] for p in pts))
    best = min(cands, key=lambda t: (loss(pts, t), t))
    return best

# temporal: fit 90-109, test 110-119
tr = [p for p in pts if p[2] < 110]; te = [p for p in pts if p[2] >= 110]
t = best_t(tr)
print("temporal fit t", t, "train", loss(tr, t), "test", loss(te, t), "n test", len(te))
# repeated CV
random.seed(0)
res = []
for rep in range(200):
    sh = pts[:]; random.shuffle(sh)
    folds = [sh[i::5] for i in range(5)]
    for i in range(5):
        tr = [p for j, f in enumerate(folds) if j != i for p in f]
        t = best_t(tr)
        res.append(loss(folds[i], t))
print("5fold CV mean", sum(res) / len(res), "p95 fold", sorted(res)[int(.95 * len(res))])
