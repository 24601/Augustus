import os
if os.path.exists("_bad_rows.py") and os.path.getsize("_bad_rows.py") == 0:
    os.remove("_bad_rows.py")
