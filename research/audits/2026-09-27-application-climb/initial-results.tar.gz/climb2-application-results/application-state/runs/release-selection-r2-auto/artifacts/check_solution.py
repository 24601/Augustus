"""Checks: fit, JSON round trip, fresh-process decide, invalid inputs, temporal holdout."""
import json, subprocess, sys
import solution

rows = json.load(open("rows.json"))
config = json.load(open("config.json"))

art = solution.fit(rows, config)
json.dump(art, open("artifact.json", "w"), indent=2)
print("artifact", art)
assert art["stock"] in list(config["stocks"]) + ["constant"]
if art["stock"] != "constant":
    assert config["stocks"][art["stock"]]["latency_ms"] <= config["max_latency_ms"]

# Fresh process: only solution.py + reloaded artifact, serving rows w/o labels/day.
post = [r for r in rows if r["day"] >= 90]
serve = [{"request_id": r["request_id"], "scores": {art["stock"]: r["scores"][art["stock"]]}} for r in post] \
    if art["stock"] != "constant" else [{"request_id": r["request_id"], "scores": {}} for r in post]
bad = [{"request_id": "x", "scores": {}}, {"request_id": "x", "scores": {art["stock"]: None}},
       {"request_id": "x", "scores": {art["stock"]: True}}, {"request_id": "x", "scores": {art["stock"]: False}},
       {"request_id": "x", "scores": {art["stock"]: "0.01"}}, {"request_id": "x", "scores": {art["stock"]: float("nan")}},
       {"request_id": "x", "scores": {art["stock"]: -0.1}}, {"request_id": "x", "scores": {art["stock"]: 1.5}},
       {"request_id": "x", "scores": {art["stock"]: float("inf")}}, {"request_id": "x"}, {"request_id": "x", "scores": None}]
json.dump({"serve": serve}, open("serve_rows.json", "w"))
child = r'''
import json, math, solution
art = json.load(open("artifact.json"))
serve = json.load(open("serve_rows.json"))["serve"]
out = [solution.decide(art, r) for r in serve]
bad = [{}, {"scores": {}}, {"scores": None}]
s = art["stock"]
for v in [None, True, False, "0.01", float("nan"), -0.1, 1.5, float("inf"), [0.01]]:
    bad.append({"request_id": "x", "scores": {s: v}})
badout = [solution.decide(art, r) for r in bad]
print(json.dumps({"out": out, "bad": badout}))
'''
open("_child_check.py", "w").write(child)
res = subprocess.run([sys.executable, "_child_check.py"], capture_output=True, text=True)
assert res.returncode == 0, res.stderr
o = json.loads(res.stdout)
assert set(o["out"]) <= {"allow", "review"}
assert all(d == "review" for d in o["bad"]), o["bad"]
loss = sum(8 * r["fraud"] if d == "allow" else (1 - r["fraud"]) for r, d in zip(post, o["out"])) / len(post)
print("fresh-process in-sample post-change loss %.4f review rate %.3f" % (loss, o["out"].count("review") / len(post)))
print("invalid inputs all -> review: OK")

# Temporal holdout: fit on everything before day 110, test on days 110-119.
art_t = solution.fit([r for r in rows if r["day"] < 110], config)
te = [r for r in rows if r["day"] >= 110]
lt = sum(8 * r["fraud"] if solution.decide(art_t, r) == "allow" else (1 - r["fraud"]) for r in te) / len(te)
print("temporal holdout (fit <110, test 110-119, n=%d): stock %s t %s loss %.4f" % (len(te), art_t["stock"], art_t.get("threshold"), lt))

# Baseline: old rule legacy >= 0.5 on post-change rows
lb = sum(8 * r["fraud"] if r["scores"]["legacy"] < 0.5 else (1 - r["fraud"]) for r in post) / len(post)
print("old rule legacy>=0.5 post-change loss %.4f" % lb)
