
import json, math, solution
art = json.load(open("artifact.json"))
serve = json.load(open("serve_rows.json"))["serve"]
out = [solution.decide(art, r) for r in serve]
bad = [{}, {"scores": {}}, {"scores": None}]
s = art["stock"]
for v in [None, True, False, "0.01", float("nan"), -0.1, 1.5, float("inf"), [0.01]]:
    bad.append({"request_id": "x", "scores": {s: v}})
badout = [solution.decide(art, r) for r in bad]
print(json.dumps({"out": out, "bad": badout}))
