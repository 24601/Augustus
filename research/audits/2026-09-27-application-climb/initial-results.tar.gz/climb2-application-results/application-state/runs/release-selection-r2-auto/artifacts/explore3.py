import json, random

rows = json.load(open("rows.json"))
post = [r for r in rows if r["day"] >= 90]
pts = [(r["scores"]["compact"], r["fraud"], r["day"]) for r in post]


def loss(pts, t):
    return sum(8 * y if s < t else (1 - y) for s, y, *_ in pts) / len(pts)

for t in [0.03, 0.035, 0.038, 0.04, 0.045, 0.05, 0.055, 0.06, 0.065, 0.07, 0.071]:
    print("t", t, "loss", round(loss(pts, t), 4), "review rate", round(sum(s >= t for s, *_ in pts) / len(pts), 3))


def smooth_best(tr, bw):
    # minimize expected loss with each score jittered by gaussian-ish uniform kernel of width bw
    cands = sorted(set(p[0] for p in tr))
    def sl(t):
        tot = 0.0
        for s, y, *_ in tr:
            # prob that score+noise < t with uniform noise in [-bw,bw]
            pa = min(1, max(0, (t - s + bw) / (2 * bw)))
            tot += 8 * y * pa + (1 - y) * (1 - pa)
        return tot
    grid = [i / 2000 for i in range(0, 400)]
    return min(grid, key=sl)


def emp_best(tr):
    cands = sorted(set(p[0] for p in tr))
    return min(cands, key=lambda t: (loss(tr, t), t))

rules = {
    "emp": emp_best,
    "emp*0.8": lambda tr: 0.8 * emp_best(tr),
    "smooth.005": lambda tr: smooth_best(tr, 0.005),
    "smooth.01": lambda tr: smooth_best(tr, 0.01),
    "smooth.02": lambda tr: smooth_best(tr, 0.02),
}
random.seed(1)
splits = []
for rep in range(40):
    sh = pts[:]; random.shuffle(sh)
    folds = [sh[i::5] for i in range(5)]
    for i in range(5):
        splits.append(([p for j, f in enumerate(folds) if j != i for p in f], folds[i]))
tr_t = [p for p in pts if p[2] < 110]; te_t = [p for p in pts if p[2] >= 110]
for name, fn in rules.items():
    res = []; ts = []
    for tr, te in splits:
        t = fn(tr); ts.append(t); res.append(loss(te, t))
    tt = fn(tr_t)
    print(name, "CV mean %.4f" % (sum(res) / len(res)), "fold p95 %.3f" % sorted(res)[int(.95 * len(res))],
          "t range %.4f-%.4f" % (min(ts), max(ts)), "temporal t %.4f test %.3f" % (tt, loss(te_t, tt)),
          "full t %.4f" % fn(pts))
