import json, math
from collections import Counter

rows = json.load(open("rows.json"))
print(type(rows), len(rows))
print(rows[0])
print(Counter(tuple(sorted(r.keys())) for r in rows))
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
for name in ["legacy", "compact", "large"]:
    vals = [r["scores"].get(name) for r in rows]
    bad = [v for v in vals if not (isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 <= v <= 1)]
    print(name, "invalid", len(bad), Counter(repr(b) for b in bad).most_common(5))

def valid(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 <= v <= 1

for label, sub in [("pre", [r for r in rows if r["day"] < 90]), ("post", [r for r in rows if r["day"] >= 90])]:
    n = len(sub); f = sum(r["fraud"] for r in sub)
    print(label, n, "fraud rate", f / n, "all-review loss", (n - f) / n, "all-allow", 8 * f / n)
    for name in ["legacy", "compact", "large"]:
        pts = [(r["scores"][name], r["fraud"]) for r in sub if valid(r["scores"].get(name))]
        inv = [r for r in sub if not valid(r["scores"].get(name))]
        best = None
        for t in sorted(set(p[0] for p in pts)) + [1.01]:
            loss = sum(8 * y if s < t else (1 - y) for s, y in pts) + sum(1 - r["fraud"] for r in inv)
            if best is None or loss < best[0]:
                best = (loss, t)
        l05 = sum(8 * y if s < 0.5 else (1 - y) for s, y in pts) + sum(1 - r["fraud"] for r in inv)
        print("  ", name, "invalid", len(inv), "insample-best", best[0] / n, "t", best[1], "@0.5", l05 / n)
