"""Fraud-review decision: one latency-eligible stock + a single score threshold.

fit() uses only rows from the current checkout funnel (day >= change_day, default 90),
because scores are not calibrated across the funnel change. For each stock within the
latency allowance it picks a threshold minimizing a smoothed (uniform-jitter) expected
business loss, then keeps the stock with the lowest 5-fold cross-validated loss.
Missing/invalid scores always map to "review".
"""
import math
import random

CHANGE_DAY = 90
BANDWIDTH = 0.01
GRID = [i / 2000 for i in range(2001)]


def _valid(v):
    return (isinstance(v, (int, float)) and not isinstance(v, bool)
            and math.isfinite(v) and 0.0 <= v <= 1.0)


def _smoothed_threshold(pts, fn_cost, fp_cost, bw=BANDWIDTH):
    """pts: list of (score, fraud). Review iff score >= threshold."""
    def sl(t):
        tot = 0.0
        for s, y in pts:
            p_allow = min(1.0, max(0.0, (t - s + bw) / (2 * bw)))
            tot += fn_cost * y * p_allow + fp_cost * (1 - y) * (1 - p_allow)
        return tot
    return min(GRID, key=sl)


def _loss(rows, stock, threshold, fn_cost, fp_cost):
    tot = 0.0
    for r in rows:
        v = r["scores"].get(stock)
        review = (not _valid(v)) or v >= threshold
        tot += fp_cost * (1 - r["fraud"]) if review else fn_cost * r["fraud"]
    return tot / len(rows)


def _fit_threshold(rows, stock, fn_cost, fp_cost):
    pts = [(r["scores"][stock], r["fraud"]) for r in rows if _valid(r["scores"].get(stock))]
    if not pts:
        return None
    return _smoothed_threshold(pts, fn_cost, fp_cost)


def fit(rows, config):
    fn_cost = config.get("fn_cost", 8)
    fp_cost = config.get("fp_cost", 1)
    max_lat = config.get("max_latency_ms", 15)
    change_day = config.get("change_day", CHANGE_DAY)
    recent = [r for r in rows if r.get("day", 0) >= change_day and r.get("fraud") in (0, 1)]

    const_loss = (sum(fp_cost * (1 - r["fraud"]) for r in recent) / len(recent)) if recent else None
    best = {"stock": "constant", "decision": "review", "cv_loss": const_loss}
    if len(recent) < 20:
        return best

    rng = random.Random(0)
    shuffled = recent[:]
    rng.shuffle(shuffled)
    folds = [shuffled[i::5] for i in range(5)]

    for stock, meta in sorted(config.get("stocks", {}).items()):
        if meta.get("latency_ms", float("inf")) > max_lat:
            continue
        cv = 0.0
        ok = True
        for i in range(5):
            train = [r for j, f in enumerate(folds) if j != i for r in f]
            t = _fit_threshold(train, stock, fn_cost, fp_cost)
            if t is None:
                ok = False
                break
            cv += _loss(folds[i], stock, t, fn_cost, fp_cost) * len(folds[i])
        if not ok:
            continue
        cv /= len(recent)
        if best["cv_loss"] is None or cv < best["cv_loss"]:
            t = _fit_threshold(recent, stock, fn_cost, fp_cost)
            best = {
                "stock": stock,
                "threshold": t,
                "cv_loss": cv,
                "train_loss": _loss(recent, stock, t, fn_cost, fp_cost),
                "fit_rows": len(recent),
                "change_day": change_day,
            }
    return best


def decide(artifact, row):
    try:
        stock = artifact["stock"]
        if stock == "constant":
            return "allow" if artifact.get("decision") == "allow" else "review"
        v = (row.get("scores") or {}).get(stock)
        t = artifact["threshold"]
        if not _valid(v) or not _valid(t):
            return "review"
        return "review" if v >= t else "allow"
    except Exception:
        return "review"
