"""Enzyme dispatch policy: exact legality rules plus expected-cost minimisation.

Transit is uniform on the route's inclusive integer bounds (operations.md), so
the expected cost of each legal action is computed exactly per row. The history
log is not needed to estimate anything; `fit` only freezes the cost schedule.
"""
import math

_PARAMS = (
    "ground_handling_hours", "cold_handling_hours",
    "ground_base", "ground_per_kg", "cold_base", "cold_per_kg",
    "late_base", "late_value_fraction", "hold_base", "hold_value_fraction",
)


def fit(rows, config):
    return {
        "policy": "exact-expected-cost-v1",
        "params": {k: float(config[k]) for k in _PARAMS},
    }


def _num(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise ValueError("not a number")
    x = float(x)
    if not math.isfinite(x) or x < 0:
        raise ValueError("bad number")
    return x


def _int_hours(x):
    v = _num(x)
    if v != int(v):
        raise ValueError("non-integer hours")
    return int(v)


def _current_certificate(certs):
    best = None
    for c in certs:
        if not isinstance(c, dict) or c.get("signed") is not True:
            continue
        rev = _num(c["revision"])
        if best is not None and rev == best[0]:
            raise ValueError("duplicate signed revision")
        if best is None or rev > best[0]:
            best = (rev, c)
    return None if best is None else best[1]


def _route(r):
    if not isinstance(r, dict) or r.get("open") is not True:
        return None
    lo, hi = _int_hours(r["min_hours"]), _int_hours(r["max_hours"])
    if lo < 1 or lo > hi:
        raise ValueError("bad route bounds")
    return lo, hi


def _late_prob(lo, hi, handling, deadline):
    # arrival = handling + t, late iff arrival > deadline
    first_late = max(lo, math.floor(deadline - handling) + 1)
    n_late = max(0, hi - first_late + 1)
    return n_late / (hi - lo + 1)


def _options(p, row):
    value = _num(row["order_value"])
    weight = _num(row["weight_kg"])
    hold_cost = p["hold_base"] + p["hold_value_fraction"] * value
    opts = {"hold": hold_cost}

    cert = _current_certificate(row["certificates"])
    if cert is None or cert.get("status") != "released":
        return opts
    budget = _num(cert["remaining_units"])
    rate = _num(row["ambient_units_per_hour"])
    deadline = _num(row["deadline_hours"])
    late_fee = p["late_base"] + p["late_value_fraction"] * value

    g = _route(row["ground"])
    if g is not None:
        gh = p["ground_handling_hours"]
        if rate * (gh + g[1]) <= budget:
            opts["ground"] = (p["ground_base"] + p["ground_per_kg"] * weight
                              + _late_prob(g[0], g[1], gh, deadline) * late_fee)

    c = _route(row["cold"])
    if c is not None and row["cold_boxes_available"] is True:
        ch = p["cold_handling_hours"]
        prot = _num(row["cold_protection_hours"])
        if rate * max(0.0, ch + c[1] - prot) <= budget:
            opts["cold"] = (p["cold_base"] + p["cold_per_kg"] * weight
                            + _late_prob(c[0], c[1], ch, deadline) * late_fee)
    return opts


def decide(artifact, row):
    try:
        opts = _options(artifact["params"], row)
    except (KeyError, TypeError, ValueError, AttributeError):
        return "hold"
    # Ties resolve toward hold, then cold (no ground-late variance).
    order = {"hold": 0, "cold": 1, "ground": 2}
    return min(opts, key=lambda a: (round(opts[a], 9), order[a]))
