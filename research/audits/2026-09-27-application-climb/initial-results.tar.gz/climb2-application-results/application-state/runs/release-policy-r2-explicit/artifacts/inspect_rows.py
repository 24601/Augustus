import json
rows = json.load(open("rows.json"))
print(type(rows), len(rows))
print(json.dumps(rows[0], indent=1))
print(json.dumps(rows[1], indent=1))
keys = set()
for r in rows:
    keys |= set(r)
print(sorted(keys))
from collections import Counter
print(Counter(r.get("historical_action") for r in rows))
routes = Counter()
for r in rows:
    for k, v in r.items():
        if isinstance(v, dict) and "min_hours" in v:
            routes[(k, v["min_hours"], v["max_hours"])] += 1
print(routes.most_common(30))
