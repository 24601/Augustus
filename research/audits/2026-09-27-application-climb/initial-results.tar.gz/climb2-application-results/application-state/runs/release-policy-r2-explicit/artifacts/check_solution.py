"""Checks: log consistency with the manual, legality, expected cost vs legacy,
edge cases, and JSON export/reload in a fresh process."""
import json, subprocess, sys, time, copy
import solution

rows = json.load(open("rows.json"))
config = json.load(open("config.json"))
t0 = time.time()
art = solution.fit(rows, config)
blob = json.dumps(art)
print("fit s", round(time.time() - t0, 3), "artifact bytes", len(blob))
p = art["params"]

# 1. Observed transit lies inside declared bounds; on_time matches arithmetic.
bad = 0
for r in rows:
    a = r["historical_action"]
    if a in ("ground", "cold"):
        rt = r[a]; t = r["observed_transit_hours"]
        h = p[a + "_handling_hours"]
        if not (rt["min_hours"] <= t <= rt["max_hours"]):
            bad += 1
        if (h + t <= r["deadline_hours"]) != r["observed_on_time"]:
            bad += 1
print("log inconsistencies", bad)

# 2. Independent legality oracle.
def legal(r, a):
    if a == "hold":
        return True
    signed = [c for c in r["certificates"] if c.get("signed") is True]
    if not signed:
        return False
    cur = max(signed, key=lambda c: c["revision"])
    if cur["status"] != "released" or not r[a]["open"]:
        return False
    if a == "ground":
        dose = r["ambient_units_per_hour"] * (p["ground_handling_hours"] + r["ground"]["max_hours"])
    else:
        if r["cold_boxes_available"] is not True:
            return False
        dose = r["ambient_units_per_hour"] * max(0, p["cold_handling_hours"] + r["cold"]["max_hours"] - r["cold_protection_hours"])
    return dose <= cur["remaining_units"]

def exp_cost(r, a):
    v, w = r["order_value"], r["weight_kg"]
    if a == "hold":
        return p["hold_base"] + p["hold_value_fraction"] * v
    lo, hi = r[a]["min_hours"], r[a]["max_hours"]
    h = p[a + "_handling_hours"]
    late = sum(1 for t in range(lo, hi + 1) if h + t > r["deadline_hours"]) / (hi - lo + 1)
    return p[a + "_base"] + p[a + "_per_kg"] * w + late * (p["late_base"] + p["late_value_fraction"] * v)

serve = [{k: v for k, v in r.items() if k not in ("historical_action", "observed_transit_hours", "observed_on_time")} for r in rows]
acts = [solution.decide(art, r) for r in serve]
illegal = sum(not legal(r, a) for r, a in zip(rows, acts))
legacy_illegal = sum(not legal(r, r["historical_action"]) for r in rows)
# brute-force optimum among legal actions
opt = [min((a for a in ("hold", "cold", "ground") if legal(r, a)), key=lambda a: exp_cost(r, a)) for r in rows]
mine = sum(exp_cost(r, a) for r, a in zip(rows, acts)) / len(rows)
best = sum(exp_cost(r, a) for r, a in zip(rows, opt)) / len(rows)
leg = sum(exp_cost(r, r["historical_action"]) for r in rows) / len(rows)
from collections import Counter
print("illegal", illegal, "legacy illegal", legacy_illegal)
print("expected mean cost: policy", round(mine, 3), "oracle-opt", round(best, 3), "legacy", round(leg, 3), "ceiling", config["maximum_mean_cost"])
print("actions", Counter(acts))

# 3. Edge cases.
r0 = copy.deepcopy(serve[0])
cases = {}
x = copy.deepcopy(r0); x["certificates"] = [c for c in x["certificates"] if not c["signed"]]; cases["no signed"] = x
x = copy.deepcopy(r0); x["certificates"].append({"revision": 9, "signed": True, "status": "quarantine", "remaining_units": 999}); cases["quarantine latest"] = x
x = copy.deepcopy(r0); x["certificates"].append({"revision": 9, "signed": True, "status": "revoked", "remaining_units": 999}); cases["revoked latest"] = x
x = copy.deepcopy(r0); x["ground"]["open"] = False; x["cold"]["open"] = False; cases["all closed"] = x
x = copy.deepcopy(r0); x["certificates"] = [{"revision": 1, "signed": True, "status": "released", "remaining_units": 0}]; x["cold_protection_hours"] = 100; cases["zero budget full protection"] = x
x = copy.deepcopy(r0); del x["ground"]; cases["missing field"] = x
x = copy.deepcopy(r0); x["ground"]["open"] = "true"; x["cold_boxes_available"] = 1; cases["truthy non-bool"] = x
for name, c in cases.items():
    print(name, "->", solution.decide(art, c), "legal", legal(c, solution.decide(art, c)) if "missing" not in name else "")

# 4. Fresh-process reload.
json.dump(art, open("artifact_check.json", "w"))
json.dump(serve, open("serve_check.json", "w"))
script = ("import json,solution\nart=json.load(open('artifact_check.json'))\n"
          "rows=json.load(open('serve_check.json'))\nprint(json.dumps([solution.decide(art,r) for r in rows]))\n")
open("reload_check_child.py", "w").write(script)
t0 = time.time()
out = subprocess.run([sys.executable, "reload_check_child.py"], capture_output=True, text=True)
print("reload match", json.loads(out.stdout) == acts, "serve s", round(time.time() - t0, 3), out.stderr[:200])
