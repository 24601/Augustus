import json,solution
art=json.load(open('artifact_check.json'))
rows=json.load(open('serve_check.json'))
print(json.dumps([solution.decide(art,r) for r in rows]))
