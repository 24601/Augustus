import json, subprocess, sys, collections
import solution

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
art = json.loads(json.dumps(solution.fit(rows, cfg)))
json.dump(art, open("artifact_check.json", "w"))
# fresh-process reload
out = subprocess.run([sys.executable, "-c",
    "import json,solution;a=json.load(open('artifact_check.json'));"
    "r=json.load(open('rows.json'));print(solution.decide(a,r[0]))"],
    capture_output=True, text=True)
print("fresh process:", out.stdout.strip(), out.stderr.strip()[-200:])


def legal(row, act):
    if act == "hold":
        return True
    signed = [c for c in row["certificates"] if c["signed"]]
    if not signed:
        return False
    cur = max(signed, key=lambda c: c["revision"])
    if cur["status"] != "released":
        return False
    r = row[act]
    if not r["open"]:
        return False
    a = row["ambient_units_per_hour"]
    if act == "ground":
        dose = a * (cfg["ground_handling_hours"] + r["max_hours"])
    else:
        if not row["cold_boxes_available"]:
            return False
        dose = a * max(0, cfg["cold_handling_hours"] + r["max_hours"] - row["cold_protection_hours"])
    return dose <= cur["remaining_units"]


def exp_cost(row, act):
    v = row["order_value"]
    if act == "hold":
        return cfg["hold_base"] + cfg["hold_value_fraction"] * v
    r = row[act]
    h = cfg[act + "_handling_hours"]
    base = cfg[act + "_base"] + cfg[act + "_per_kg"] * row["weight_kg"]
    ts = range(r["min_hours"], r["max_hours"] + 1)
    pl = sum(h + t > row["deadline_hours"] for t in ts) / len(ts)
    return base + pl * (cfg["late_base"] + cfg["late_value_fraction"] * v)


illegal = 0
tot = leg = 0.0
acts = collections.Counter()
for row in rows:
    serve = {k: v for k, v in row.items() if k not in
             ("historical_action", "observed_transit_hours", "observed_on_time")}
    a = solution.decide(art, serve)
    acts[a] += 1
    illegal += not legal(row, a)
    tot += exp_cost(row, a)
    la = row["historical_action"]
    leg += exp_cost(row, la)
    if not legal(row, la):
        pass
n = len(rows)
print("n", n, "actions", dict(acts), "illegal", illegal)
print("policy expected mean cost %.2f  legacy %.2f  ceiling %.1f" % (tot / n, leg / n, cfg["maximum_mean_cost"]))

# sanity: observed transits fall within declared bounds
bad = sum(1 for r in rows if r["observed_transit_hours"] is not None and not
          (r[r["historical_action"]]["min_hours"] <= r["observed_transit_hours"] <= r[r["historical_action"]]["max_hours"]))
print("observed transit out of bounds:", bad)
