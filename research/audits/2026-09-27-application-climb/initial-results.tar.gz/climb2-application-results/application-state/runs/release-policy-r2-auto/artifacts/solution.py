"""Enzyme dispatch policy.

The operations manual fully specifies the transit distribution (uniform over
the inclusive integer interval [min_hours, max_hours]) and the cost schedule,
so expected cost per action is computed exactly from the row. The historical
log is selection-biased and is not needed to estimate anything; `fit` only
carries the public configuration into the artifact.
"""

import math

_KEYS = (
    "ground_handling_hours", "cold_handling_hours",
    "ground_base", "ground_per_kg", "cold_base", "cold_per_kg",
    "late_base", "late_value_fraction", "hold_base", "hold_value_fraction",
)


def fit(rows, config):
    return {"config": {k: float(config[k]) for k in _KEYS}}


def _num(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        return None
    x = float(x)
    if not math.isfinite(x) or x < 0:
        return None
    return x


def _current_budget(row):
    """Remaining units if the current signed record is a release, else None."""
    certs = row.get("certificates")
    if not isinstance(certs, list):
        return None
    best = None
    for c in certs:
        if not isinstance(c, dict) or c.get("signed") is not True:
            continue
        rev = _num(c.get("revision"))
        if rev is None:
            continue
        if best is None or rev > best[0]:
            best = (rev, c)
    if best is None:
        return None
    cur = best[1]
    if cur.get("status") != "released":
        return None
    return _num(cur.get("remaining_units"))


def _route(row, name):
    r = row.get(name)
    if not isinstance(r, dict) or r.get("open") is not True:
        return None
    lo, hi = _num(r.get("min_hours")), _num(r.get("max_hours"))
    if lo is None or hi is None or lo != int(lo) or hi != int(hi) or lo > hi:
        return None
    return int(lo), int(hi)


def _late_prob(handling, lo, hi, deadline):
    n = hi - lo + 1
    late = sum(1 for t in range(lo, hi + 1) if handling + t > deadline)
    return late / n


def decide(artifact, row):
    cfg = artifact["config"]
    value = _num(row.get("order_value"))
    weight = _num(row.get("weight_kg"))
    deadline = _num(row.get("deadline_hours"))
    ambient = _num(row.get("ambient_units_per_hour"))
    protect = _num(row.get("cold_protection_hours"))
    budget = _current_budget(row)

    hold_cost = cfg["hold_base"] + cfg["hold_value_fraction"] * (value or 0.0)
    if None in (value, weight, deadline, ambient, budget):
        return "hold"
    late_pen = cfg["late_base"] + cfg["late_value_fraction"] * value

    options = [(hold_cost, 2, "hold")]

    g = _route(row, "ground")
    if g is not None:
        gh = cfg["ground_handling_hours"]
        dose = ambient * (gh + g[1])
        if dose <= budget:
            cost = (cfg["ground_base"] + cfg["ground_per_kg"] * weight
                    + late_pen * _late_prob(gh, g[0], g[1], deadline))
            options.append((cost, 0, "ground"))

    c = _route(row, "cold")
    if c is not None and row.get("cold_boxes_available") is True and protect is not None:
        ch = cfg["cold_handling_hours"]
        dose = ambient * max(0.0, ch + c[1] - protect)
        if dose <= budget:
            cost = (cfg["cold_base"] + cfg["cold_per_kg"] * weight
                    + late_pen * _late_prob(ch, c[0], c[1], deadline))
            options.append((cost, 1, "cold"))

    return min(options)[2]
