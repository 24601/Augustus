"""Enzyme dispatch policy.

The operations manual publishes the transit distribution (independent uniform
integers on [min_hours, max_hours]) and the full cost schedule, so the policy
computes expected cost analytically per action instead of learning from the
selection-biased historical log. Legality (signed certificate, thermal worst
case, route availability) is enforced as a hard filter before cost comparison.
"""

import math

_KEYS = (
    "ground_handling_hours", "cold_handling_hours",
    "ground_base", "ground_per_kg", "cold_base", "cold_per_kg",
    "late_base", "late_value_fraction", "hold_base", "hold_value_fraction",
)


def fit(rows, config):
    return {"params": {k: float(config[k]) for k in _KEYS}}


def _num(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise ValueError
    x = float(x)
    if not math.isfinite(x) or x < 0:
        raise ValueError
    return x


def _current_budget(row):
    """Remaining units of the greatest signed revision if released, else None."""
    best = None
    for c in row.get("certificates") or []:
        if not isinstance(c, dict) or c.get("signed") is not True:
            continue
        rev = _num(c.get("revision"))
        if best is None or rev > best[0]:
            best = (rev, c)
    if best is None or best[1].get("status") != "released":
        return None
    return _num(best[1].get("remaining_units"))


def _route(row, name):
    r = row.get(name)
    if not isinstance(r, dict) or r.get("open") is not True:
        return None
    lo, hi = _num(r.get("min_hours")), _num(r.get("max_hours"))
    if lo != int(lo) or hi != int(hi) or lo > hi:
        return None
    return int(lo), int(hi)


def _p_late(handling, lo, hi, deadline):
    # Actual transit uniform over integers lo..hi; late iff handling + t > deadline.
    n = hi - lo + 1
    late = sum(1 for t in range(lo, hi + 1) if handling + t > deadline)
    return late / n


def decide(artifact, row):
    try:
        p = artifact["params"]
        value = _num(row["order_value"])
        weight = _num(row["weight_kg"])
        deadline = _num(row["deadline_hours"])
        ambient = _num(row["ambient_units_per_hour"])
        best_action = "hold"
        best_cost = p["hold_base"] + p["hold_value_fraction"] * value

        budget = _current_budget(row)
        if budget is None:
            return "hold"
        late_cost = p["late_base"] + p["late_value_fraction"] * value

        g = _route(row, "ground")
        if g is not None:
            gh = p["ground_handling_hours"]
            if ambient * (gh + g[1]) <= budget:
                cost = (p["ground_base"] + p["ground_per_kg"] * weight
                        + _p_late(gh, g[0], g[1], deadline) * late_cost)
                if cost < best_cost:
                    best_action, best_cost = "ground", cost

        c = _route(row, "cold")
        if c is not None and row.get("cold_boxes_available") is True:
            ch = p["cold_handling_hours"]
            protect = _num(row["cold_protection_hours"])
            if ambient * max(0.0, ch + c[1] - protect) <= budget:
                cost = (p["cold_base"] + p["cold_per_kg"] * weight
                        + _p_late(ch, c[0], c[1], deadline) * late_cost)
                if cost < best_cost:
                    best_action, best_cost = "cold", cost
        return best_action
    except Exception:
        return "hold"
