import json, subprocess, sys, collections

import solution

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
art = json.loads(json.dumps(solution.fit(rows, cfg)))
json.dump(art, open("artifact_check.json", "w"))

# Fresh-process reload check.
code = ("import json,solution;a=json.load(open('artifact_check.json'));"
        "r=json.load(open('rows.json'));"
        "print(json.dumps([solution.decide(a,x) for x in r]))")
out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
fresh = json.loads(out.stdout)

def legal(row, a):
    if a == "hold":
        return True
    signed = [c for c in row["certificates"] if c["signed"]]
    if not signed:
        return False
    cur = max(signed, key=lambda c: c["revision"])
    if cur["status"] != "released":
        return False
    amb = row["ambient_units_per_hour"]
    if a == "ground":
        return row["ground"]["open"] and amb * (cfg["ground_handling_hours"] + row["ground"]["max_hours"]) <= cur["remaining_units"]
    return (row["cold"]["open"] and row["cold_boxes_available"] and
            amb * max(0, cfg["cold_handling_hours"] + row["cold"]["max_hours"] - row["cold_protection_hours"]) <= cur["remaining_units"])

def exp_cost(row, a):
    v, w, d = row["order_value"], row["weight_kg"], row["deadline_hours"]
    if a == "hold":
        return cfg["hold_base"] + cfg["hold_value_fraction"] * v
    h = cfg[a + "_handling_hours"]
    r = row[a]
    ts = range(r["min_hours"], r["max_hours"] + 1)
    pl = sum(h + t > d for t in ts) / len(ts)
    return cfg[a + "_base"] + cfg[a + "_per_kg"] * w + pl * (cfg["late_base"] + cfg["late_value_fraction"] * v)

acts = [solution.decide(art, r) for r in rows]
assert acts == fresh, "fresh-process mismatch"
illegal = sum(not legal(r, a) for r, a in zip(rows, acts))
mean = sum(exp_cost(r, a) for r, a in zip(rows, acts)) / len(rows)
legacy_illegal = sum(not legal(r, r["historical_action"]) for r in rows)
legacy_mean = sum(exp_cost(r, r["historical_action"]) for r in rows) / len(rows)
print("rows", len(rows), "actions", collections.Counter(acts))
print("illegal", illegal, "expected mean cost", round(mean, 3), "ceiling", cfg["maximum_mean_cost"])
print("legacy illegal", legacy_illegal, "legacy expected mean", round(legacy_mean, 3))

# Sanity: observed transits within published bounds.
bad = 0
for r in rows:
    a = r["historical_action"]
    if a != "hold":
        t = r["observed_transit_hours"]
        if not (r[a]["min_hours"] <= t <= r[a]["max_hours"]):
            bad += 1
print("observed transits outside bounds", bad)
assert illegal == 0 and mean <= cfg["maximum_mean_cost"]
print("OK")
