import json, math
rows = json.load(open("rows.json"))
print(type(rows), len(rows))
print(rows[:3])
keys = {}
for r in rows:
    for k in r: keys[k] = keys.get(k, 0) + 1
print(keys)
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
def bad(v):
    return isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not 0 <= v <= 1
for s in ["legacy", "compact", "large"]:
    nb = sum(1 for r in rows if bad(r.get("scores", {}).get(s)))
    nbnew = sum(1 for r in rows if r["day"] >= 90 and bad(r.get("scores", {}).get(s)))
    print(s, "invalid", nb, "invalid new", nbnew)
old = [r for r in rows if r["day"] < 90]; new = [r for r in rows if r["day"] >= 90]
print("old", len(old), sum(r["fraud"] for r in old), "new", len(new), sum(r["fraud"] for r in new))
print(set(type(r["fraud"]).__name__ for r in rows), set(r["fraud"] for r in rows))
odd = [r for r in rows if any(bad(r["scores"].get(s)) for s in ["legacy","compact","large"])][:8]
print(odd)
