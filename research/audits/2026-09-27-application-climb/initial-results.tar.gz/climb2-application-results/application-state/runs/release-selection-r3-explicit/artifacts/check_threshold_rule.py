"""Compare smoothed-loss threshold (shipped) vs raw empirical argmin on identical splits."""
import json, random
import solution as S
rows = json.load(open("rows.json"))
new = [r for r in rows if r["day"] >= 90]
data = lambda rs: [(r["scores"]["compact"], r["fraud"]) for r in rs]
def raw(d):
    vals = sorted({s for s, _ in d})
    c = [(a + b) / 2 for a, b in zip(vals, vals[1:])]
    return min(c, key=lambda t: (S._loss(d, t, 8, 1), t))
random.seed(7)
res = {"smooth": [], "raw": []}
for _ in range(200):
    sh = new[:]; random.shuffle(sh)
    tr, te = data(sh[:200]), data(sh[200:])
    res["smooth"].append(S._loss(te, S._pick_threshold(tr, 8, 1), 8, 1))
    res["raw"].append(S._loss(te, raw(tr), 8, 1))
d = [a - b for a, b in zip(res["smooth"], res["raw"])]
for k, v in res.items():
    print(k, "mean %.4f worst %.3f" % (sum(v) / len(v), max(v)))
print("paired diff smooth-raw mean %.4f; smooth better %d, worse %d, tie %d" % (
    sum(d) / len(d), sum(x < 0 for x in d), sum(x > 0 for x in d), sum(x == 0 for x in d)))
