import json, random
rows = json.load(open("rows.json"))
new = [r for r in rows if r["day"] >= 90]
z = [r for r in new if r["scores"]["compact"] == 0]
print("compact zeros in new:", len(z), "fraud", sum(r["fraud"] for r in z), "days", sorted(r["day"] for r in z)[:5], "...")
zo = [r for r in rows if r["day"] < 90 and r["scores"]["compact"] == 0]
print("compact zeros old:", len(zo))
def loss(rs, t):
    return sum((8 if r["fraud"] else 0) if r["scores"]["compact"] < t else (0 if r["fraud"] else 1) for r in rs) / len(rs)
for i in range(50, 95):
    t = i / 1000
    print("t=%.3f loss %.3f" % (t, loss(new, t)))
fr = sorted(r["scores"]["compact"] for r in new if r["fraud"])
lg = sorted(r["scores"]["compact"] for r in new if not r["fraud"])
print("fraud scores", fr)
print("legit top 30", lg[-30:])
# bootstrap distribution of optimal threshold
random.seed(1)
vs = sorted(set(r["scores"]["compact"] for r in new))
ts = [(a + b) / 2 for a, b in zip(vs, vs[1:])]
opt = []
for _ in range(300):
    b = [random.choice(new) for _ in new]
    opt.append(min(ts, key=lambda t: loss(b, t)))
opt.sort()
print("bootstrap opt t: p5 %.4f p50 %.4f p95 %.4f" % (opt[15], opt[150], opt[285]))
