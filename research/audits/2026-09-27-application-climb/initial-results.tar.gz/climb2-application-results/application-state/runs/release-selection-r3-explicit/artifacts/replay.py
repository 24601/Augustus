import json, solution
art = json.load(open("artifact.json"))
print(json.dumps([solution.decide(art, r) for r in json.load(open("serve_rows.json"))]))
