"""Fit, export/reload, fresh-process replay, holdout evaluation and failure-path checks."""
import json, subprocess, sys, random
import solution

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
FN, FP = cfg["fn_cost"], cfg["fp_cost"]
new = [r for r in rows if r["day"] >= 90]

def serve_row(r, stock):
    return {"request_id": r["request_id"], "scores": {} if stock == "constant" else {stock: r["scores"][stock]}}

def mean_loss(art, rs):
    L = 0
    for r in rs:
        d = solution.decide(art, serve_row(r, art["stock"]))
        assert d in ("allow", "review")
        L += (FP if d == "review" and not r["fraud"] else 0) + (FN if d == "allow" and r["fraud"] else 0)
    return L / len(rs), sum(solution.decide(art, serve_row(r, art["stock"])) == "review" for r in rs) / len(rs)

# 1. full fit + JSON export
art = solution.fit(rows, cfg)
json.dump(art, open("artifact.json", "w"), indent=2, sort_keys=True)
art2 = json.loads(json.dumps(art))
print("artifact:", json.dumps(art, sort_keys=True))
assert art["stock"] in ("legacy", "compact", "constant") and cfg["stocks"].get(art["stock"], {"latency_ms": 0})["latency_ms"] <= 15
print("in-sample new-funnel loss/review-rate:", mean_loss(art2, new))

# 2. temporal holdout: fit on everything before day 105, evaluate on days 105-119
tr = [r for r in rows if r["day"] < 105]; te = [r for r in rows if r["day"] >= 105]
a = solution.fit(tr, cfg)
print("temporal holdout: stock=%s t=%s  test loss/review-rate=%s  n=%d" % (a["stock"], a.get("threshold"), mean_loss(a, te), len(te)))
print("  legacy>=0.5 on same test:", sum((FP if r["scores"]["legacy"] >= .5 and not r["fraud"] else 0) + (FN if r["scores"]["legacy"] < .5 and r["fraud"] else 0) for r in te) / len(te))

# 3. repeated random splits of new-funnel rows (old rows always in train, ignored by fit)
random.seed(7)
ls, stocks = [], {}
for _ in range(100):
    sh = new[:]; random.shuffle(sh)
    a = solution.fit([r for r in rows if r["day"] < 90] + sh[:200], cfg)
    stocks[a["stock"]] = stocks.get(a["stock"], 0) + 1
    ls.append(mean_loss(a, sh[200:])[0])
ls.sort()
print("100x 200/100 splits: mean %.3f p5 %.3f p50 %.3f p95 %.3f max %.3f stocks %s" % (sum(ls) / len(ls), ls[5], ls[50], ls[95], ls[-1], stocks))

# 4. failure paths
st = art["stock"]
bad = [{}, {"request_id": "x"}, {"request_id": "x", "scores": None}, {"request_id": "x", "scores": {}},
       {"request_id": "x", "scores": {st: None}}, {"request_id": "x", "scores": {st: "0.01"}},
       {"request_id": "x", "scores": {st: True}}, {"request_id": "x", "scores": {st: False}},
       {"request_id": "x", "scores": {st: float("nan")}}, {"request_id": "x", "scores": {st: float("inf")}},
       {"request_id": "x", "scores": {st: -0.01}}, {"request_id": "x", "scores": {st: 1.5}},
       {"request_id": "x", "scores": {st: [0.01]}}, None, "garbage",
       {"request_id": "x", "scores": {"large": 0.0, "legacy": 0.0}}]
for b in bad:
    assert solution.decide(art2, b) == "review", b
assert solution.decide({}, {"scores": {st: 0.0}}) == "review"
assert solution.decide(None, {"scores": {st: 0.0}}) == "review"
t = art["threshold"]
assert solution.decide(art2, {"request_id": "x", "scores": {st: t}}) == "review"
assert solution.decide(art2, {"request_id": "x", "scores": {st: 0.0}}) == "allow"
assert solution.decide(art2, {"request_id": "x", "scores": {st: 0}}) == "allow"
assert solution.decide(art2, {"request_id": "x", "scores": {st: 1}}) == "review"
print("failure-path and boundary checks passed")

# 5. fresh process replay using only solution.py + artifact.json
json.dump([serve_row(r, st) for r in new], open("serve_rows.json", "w"))
out = subprocess.run([sys.executable, "replay.py"], capture_output=True, text=True)
assert out.returncode == 0, out.stderr
fresh = json.loads(out.stdout)
local = [solution.decide(art, serve_row(r, st)) for r in new]
assert fresh == local
print("fresh-process replay identical on", len(fresh), "rows")
