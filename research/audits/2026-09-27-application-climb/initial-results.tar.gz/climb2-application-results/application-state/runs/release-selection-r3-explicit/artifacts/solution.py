"""Checkout fraud-review decision: one latency-eligible stock plus a frozen threshold.

fit(rows, config) -> JSON-serializable artifact; decide(artifact, row) -> "allow" | "review".
Standard library only.
"""
import math

VERSION = "checkout-review-1"
REGIME_START_DAY = 90  # funnel change (operations.md); only post-change rows are fit
MIN_REGIME_ROWS = 50


def _valid(v):
    return (not isinstance(v, bool) and isinstance(v, (int, float))
            and math.isfinite(v) and 0.0 <= v <= 1.0)


def _phi(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _loss(data, t, fn, fp):
    """Empirical mean loss of 'review iff score >= t'; invalid scores are reviewed."""
    total = 0.0
    for s, y in data:
        review = s is None or s >= t
        total += (fp if review and not y else 0) + (fn if not review and y else 0)
    return total / len(data)


def _smooth_loss(data, t, h, fn, fp):
    """Expected loss when the threshold is jittered N(t, h): penalizes knife edges."""
    total = 0.0
    for s, y in data:
        if s is None:
            total += 0 if y else fp
            continue
        p_allow = _phi((t - s) / h)
        total += fn * p_allow if y else fp * (1.0 - p_allow)
    return total / len(data)


def _pick_threshold(data, fn, fp):
    vals = sorted({s for s, _ in data if s is not None})
    if not vals:
        return None
    cands = [(a + b) / 2 for a, b in zip(vals, vals[1:])] + [vals[0], vals[-1] + 1e-9]
    q = lambda p: vals[min(len(vals) - 1, int(p * len(vals)))]
    h = max(0.05 * (q(0.9) - q(0.1)), 1e-6)
    return min(cands, key=lambda t: (_smooth_loss(data, t, h, fn, fp), t))


def _folds(n, k):
    # deterministic interleaved folds (rows are independently sampled orders)
    return [list(range(i, n, k)) for i in range(k)]


def _cv_loss(data, fn, fp, k=5):
    total = 0.0
    for test_idx in _folds(len(data), k):
        ts = set(test_idx)
        train = [d for i, d in enumerate(data) if i not in ts]
        test = [data[i] for i in test_idx]
        t = _pick_threshold(train, fn, fp)
        total += _loss(test, t if t is not None else -1.0, fn, fp) * len(test)
    return total / len(data)


def fit(rows, config):
    fn = float(config.get("fn_cost", 8))
    fp = float(config.get("fp_cost", 1))
    max_lat = float(config.get("max_latency_ms", float("inf")))
    stocks = config.get("stocks", {})

    regime = [r for r in rows if isinstance(r.get("day"), (int, float))
              and r["day"] >= REGIME_START_DAY]
    if len(regime) < MIN_REGIME_ROWS:
        regime = list(rows)
    regime.sort(key=lambda r: (r.get("day", 0), str(r.get("request_id", ""))))
    labels = [1 if r.get("fraud") else 0 for r in regime]
    n = len(regime)
    rate = sum(labels) / n if n else 0.0

    # constant comparator: cheaper of all-allow vs all-review (review if tied/no data)
    allow_loss, review_loss = fn * rate, fp * (1 - rate)
    best = {"stock": "constant", "action": "allow" if n and allow_loss < review_loss else "review",
            "cv_loss": min(allow_loss, review_loss) if n else None}
    evaluated = {"constant": best["cv_loss"]}

    for name in sorted(stocks):
        lat = stocks[name].get("latency_ms")
        if not isinstance(lat, (int, float)) or lat > max_lat:
            evaluated[name] = "ineligible: latency %s ms > %s ms" % (lat, max_lat)
            continue
        data = []
        for r, y in zip(regime, labels):
            v = (r.get("scores") or {}).get(name)
            data.append((float(v) if _valid(v) else None, y))
        if n < 10 or all(s is None for s, _ in data):
            evaluated[name] = "no usable scores"
            continue
        cv = _cv_loss(data, fn, fp)
        evaluated[name] = round(cv, 6)
        if best["cv_loss"] is None or cv < best["cv_loss"]:
            t = _pick_threshold(data, fn, fp)
            best = {"stock": name, "threshold": t, "cv_loss": cv,
                    "fit_loss": _loss(data, t, fn, fp)}

    artifact = {
        "version": VERSION,
        "stock": best["stock"],
        "rule": "review iff score is missing/invalid or score >= threshold",
        "fit_rows": n,
        "regime_start_day": REGIME_START_DAY,
        "fit_fraud_rate": round(rate, 6),
        "costs": {"fn": fn, "fp": fp},
        "candidates_cv_loss": evaluated,
        "cv_loss": None if best["cv_loss"] is None else round(best["cv_loss"], 6),
        "meets_max_mean_loss": (best["cv_loss"] is not None
                                and best["cv_loss"] <= config.get("max_mean_loss", float("inf"))),
    }
    if best["stock"] == "constant":
        artifact["action"] = best["action"]
    else:
        artifact["threshold"] = best["threshold"]
        artifact["fit_loss"] = round(best["fit_loss"], 6)
    return artifact


def decide(artifact, row):
    try:
        stock = artifact["stock"]
        if stock == "constant":
            return "allow" if artifact.get("action") == "allow" else "review"
        t = artifact["threshold"]
        v = row["scores"][stock]
    except Exception:
        return "review"
    if not _valid(v) or isinstance(t, bool) or not isinstance(t, (int, float)) or not math.isfinite(t):
        return "review"
    return "review" if v >= t else "allow"
