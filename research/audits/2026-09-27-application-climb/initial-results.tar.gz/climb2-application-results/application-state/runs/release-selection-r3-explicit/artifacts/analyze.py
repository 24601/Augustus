import json, random
rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
FN, FP = cfg["fn_cost"], cfg["fp_cost"]
new = [r for r in rows if r["day"] >= 90]
old = [r for r in rows if r["day"] < 90]

def loss(rs, s, t, direction=1):
    # review if direction*score >= direction*t
    L = 0
    for r in rs:
        v = r["scores"][s]
        rev = v >= t if direction == 1 else v <= t
        if rev and not r["fraud"]: L += FP
        if not rev and r["fraud"]: L += FN
    return L / len(rs)

def auc(rs, s):
    pos = [r["scores"][s] for r in rs if r["fraud"]]
    neg = [r["scores"][s] for r in rs if not r["fraud"]]
    w = sum((p > n) + 0.5 * (p == n) for p in pos for n in neg)
    return w / (len(pos) * len(neg))

def cands(rs, s):
    vs = sorted(set(r["scores"][s] for r in rs))
    ts = [vs[0]] + [(a + b) / 2 for a, b in zip(vs, vs[1:])] + [vs[-1] + 1e-9]
    return ts

def best(rs, s, direction=1):
    return min((loss(rs, s, t, direction), t) for t in cands(rs, s))

for name, rs in [("old", old), ("new", new)]:
    print(name, "n", len(rs), "rate", sum(r["fraud"] for r in rs) / len(rs))
    print("  const allow", FN * sum(r["fraud"] for r in rs) / len(rs), "const review", 1 - sum(r["fraud"] for r in rs) / len(rs))
    for s in ["legacy", "compact", "large"]:
        zeros = sum(1 for r in rs if r["scores"][s] == 0)
        ones = sum(1 for r in rs if r["scores"][s] == 1)
        print("  %-8s auc %.3f  legacy0.5 %.3f  best(in-sample) %s zeros %d ones %d" % (
            s, auc(rs, s), loss(rs, s, 0.5), best(rs, s), zeros, ones))

# day-bin drift for each stock within new
for lo in range(90, 120, 10):
    rs = [r for r in new if lo <= r["day"] < lo + 10]
    print(lo, len(rs), sum(r["fraud"] for r in rs), {s: round(auc(rs, s), 3) for s in ["legacy", "compact", "large"]})

# temporal split within new: fit threshold on 90-104, test on 105-119
tr = [r for r in new if r["day"] < 105]; te = [r for r in new if r["day"] >= 105]
print("temporal", len(tr), len(te))
for s in ["legacy", "compact", "large"]:
    l, t = best(tr, s)
    print("  %s t=%.4f train %.3f test %.3f" % (s, t, l, loss(te, s, t)))

# repeated random 50/50 CV within new, threshold selection nested
random.seed(0)
res = {s: [] for s in ["legacy", "compact", "legacy05", "review", "large"]}
for rep in range(200):
    sh = new[:]; random.shuffle(sh)
    a, b = sh[:150], sh[150:]
    for s in ["legacy", "compact", "large"]:
        l, t = best(a, s); res[s].append(loss(b, s, t))
    res["legacy05"].append(loss(b, "legacy", 0.5))
    res["review"].append(sum(1 for r in b if not r["fraud"]) / len(b))
for k, v in res.items():
    v.sort()
    print("cv %-9s mean %.3f p5 %.3f p95 %.3f" % (k, sum(v) / len(v), v[10], v[189]))

# threshold-loss curve for compact on new
for t in [i / 100 for i in range(0, 60, 2)]:
    print("compact t=%.2f loss %.3f review rate %.2f" % (t, loss(new, "compact", t), sum(1 for r in new if r["scores"]["compact"] >= t) / len(new)))
