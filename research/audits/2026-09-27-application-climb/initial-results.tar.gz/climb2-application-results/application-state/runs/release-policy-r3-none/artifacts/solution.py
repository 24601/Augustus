"""Enzyme dispatch policy.

The operations manual publishes the transit distribution (uniform over the
inclusive integer range [min_hours, max_hours] per route), the cost schedule,
and the safety rules, so the policy computes exact expected cost per action
rather than learning from the selection-biased historical log. The artifact
only carries the cost/handling parameters from the configuration.
"""

import math

_PARAM_KEYS = (
    "ground_handling_hours",
    "cold_handling_hours",
    "ground_base",
    "ground_per_kg",
    "cold_base",
    "cold_per_kg",
    "late_base",
    "late_value_fraction",
    "hold_base",
    "hold_value_fraction",
)


def fit(rows, config):
    # History is not needed: transit distributions are specified by the manual.
    return {"policy": "expected-cost-v1",
            "params": {k: float(config[k]) for k in _PARAM_KEYS}}


def _num(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise ValueError("not a number")
    x = float(x)
    if not math.isfinite(x) or x < 0:
        raise ValueError("bad number")
    return x


def _current_budget(row):
    """Remaining thermal units if the current signed record is released, else None."""
    best = None
    for cert in row.get("certificates") or []:
        if not isinstance(cert, dict) or cert.get("signed") is not True:
            continue
        rev = _num(cert.get("revision"))
        if best is not None and rev == _num(best.get("revision")):
            return None  # ambiguous authority; wait for QA
        if best is None or rev > _num(best.get("revision")):
            best = cert
    if best is None or best.get("status") != "released":
        return None
    return _num(best.get("remaining_units"))


def _route(row, name):
    r = row.get(name)
    if not isinstance(r, dict) or r.get("open") is not True:
        return None
    lo, hi = _num(r.get("min_hours")), _num(r.get("max_hours"))
    if lo != int(lo) or hi != int(hi) or lo < 1 or lo > hi:
        return None
    return int(lo), int(hi)


def _late_prob(handling, lo, hi, deadline):
    n = hi - lo + 1
    late = sum(1 for t in range(lo, hi + 1) if handling + t > deadline)
    return late / n


def decide(artifact, row):
    try:
        p = artifact["params"]
        budget = _current_budget(row)
        if budget is None:
            return "hold"
        value = _num(row["order_value"])
        weight = _num(row["weight_kg"])
        deadline = _num(row["deadline_hours"])
        ambient = _num(row["ambient_units_per_hour"])

        late_fee = p["late_base"] + p["late_value_fraction"] * value
        options = [(p["hold_base"] + p["hold_value_fraction"] * value, 0, "hold")]

        g = _route(row, "ground")
        if g is not None:
            h = p["ground_handling_hours"]
            if ambient * (h + g[1]) <= budget:
                cost = (p["ground_base"] + p["ground_per_kg"] * weight
                        + _late_prob(h, g[0], g[1], deadline) * late_fee)
                options.append((cost, 1, "ground"))

        c = _route(row, "cold")
        if c is not None and row.get("cold_boxes_available") is True:
            h = p["cold_handling_hours"]
            protect = _num(row["cold_protection_hours"])
            if ambient * max(0.0, h + c[1] - protect) <= budget:
                cost = (p["cold_base"] + p["cold_per_kg"] * weight
                        + _late_prob(h, c[0], c[1], deadline) * late_fee)
                options.append((cost, 2, "cold"))

        return min(options)[2]
    except Exception:
        return "hold"
