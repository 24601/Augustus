import json, subprocess, sys, random

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))

if len(sys.argv) > 1 and sys.argv[1] == "serve":
    import solution
    art = json.load(open("fitted_artifact.json"))
    print(json.dumps([solution.decide(art, {k: v for k, v in r.items() if k not in (
        "historical_action", "observed_transit_hours", "observed_on_time")}) for r in rows]))
    sys.exit()

import solution
art = solution.fit(rows, cfg)
s = json.dumps(art)
open("fitted_artifact.json", "w").write(s)
print("artifact bytes", len(s))
acts = json.loads(subprocess.run([sys.executable, "check_solution.py", "serve"],
                                 capture_output=True, text=True).stdout)


def legal(r, a):
    if a == "hold":
        return True
    signed = [c for c in r["certificates"] if c["signed"] is True]
    if not signed:
        return False
    cur = max(signed, key=lambda c: c["revision"])
    if cur["status"] != "released":
        return False
    route = r[a]
    if not route["open"]:
        return False
    amb = r["ambient_units_per_hour"]
    if a == "ground":
        dose = amb * (cfg["ground_handling_hours"] + route["max_hours"])
    else:
        if not r["cold_boxes_available"]:
            return False
        dose = amb * max(0, cfg["cold_handling_hours"] + route["max_hours"] - r["cold_protection_hours"])
    return dose <= cur["remaining_units"]


def cost(r, a, t):
    if a == "hold":
        return cfg["hold_base"] + cfg["hold_value_fraction"] * r["order_value"]
    c = cfg[a + "_base"] + cfg[a + "_per_kg"] * r["weight_kg"]
    if cfg[a + "_handling_hours"] + t > r["deadline_hours"]:
        c += cfg["late_base"] + cfg["late_value_fraction"] * r["order_value"]
    return c


rng = random.Random(0)
def sim(policy_acts, reps=200):
    tot = 0
    for _ in range(reps):
        for r, a in zip(rows, policy_acts):
            t = rng.randint(r[a]["min_hours"], r[a]["max_hours"]) if a != "hold" else 0
            tot += cost(r, a, t)
    return tot / (reps * len(rows))

bad = sum(not legal(r, a) for r, a in zip(rows, acts))
leg_bad = sum(not legal(r, r["historical_action"]) for r in rows)
print("illegal (policy):", bad, " illegal (legacy):", leg_bad)
from collections import Counter
print("policy actions", Counter(acts), " legacy", Counter(r["historical_action"] for r in rows))
print("mean cost policy", round(sim(acts), 2), " legacy", round(sim([r["historical_action"] for r in rows]), 2),
      " hold-all", round(sim(["hold"] * len(rows), 1), 2), " ceiling", cfg["maximum_mean_cost"])
# observed transits must fall in declared bounds
oob = sum(1 for r in rows if r["historical_action"] != "hold" and not (
    r[r["historical_action"]]["min_hours"] <= r["observed_transit_hours"] <= r[r["historical_action"]]["max_hours"]))
print("observed transit out of bounds:", oob)

# perturbation tests: snapshot changes must be reflected
r = json.loads(json.dumps(rows[0]))
r["ground"]["open"] = False; r["cold"]["open"] = False
assert solution.decide(art, r) == "hold"
r = json.loads(json.dumps(rows[0])); r["certificates"].append({"revision": 99, "signed": True, "status": "revoked", "remaining_units": 999})
assert solution.decide(art, r) == "hold"
r = json.loads(json.dumps(rows[0])); r["certificates"] = [{"revision": 1, "signed": False, "status": "released", "remaining_units": 999}]
assert solution.decide(art, r) == "hold"
print("perturbation asserts ok")
