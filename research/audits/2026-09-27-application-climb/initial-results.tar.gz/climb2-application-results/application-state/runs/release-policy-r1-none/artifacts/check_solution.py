import json, subprocess, sys, collections
import solution

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
art = json.loads(json.dumps(solution.fit(rows, cfg)))
json.dump(art, open("artifact_check.json", "w"))

# fresh-process reload check
code = ("import json,solution;a=json.load(open('artifact_check.json'));"
        "r=json.load(open('rows.json'));print(solution.decide(a,r[0]))")
out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
print("fresh process:", out.stdout.strip(), out.stderr.strip()[:200])

def exp_cost(row, act):
    v, w, d = row["order_value"], row["weight_kg"], row["deadline_hours"]
    if act == "hold":
        return cfg["hold_base"] + cfg["hold_value_fraction"] * v
    r = row[act]
    h = cfg[act + "_handling_hours"]
    ts = range(r["min_hours"], r["max_hours"] + 1)
    pl = sum(h + t > d for t in ts) / len(ts)
    return cfg[act + "_base"] + cfg[act + "_per_kg"] * w + pl * (cfg["late_base"] + cfg["late_value_fraction"] * v)

acts = collections.Counter()
tot = legacy = 0.0
bad_transit = 0
for row in rows:
    a = solution.decide(art, {k: v for k, v in row.items() if not k.startswith(("historical", "observed"))})
    assert a in ("ground", "cold", "hold")
    acts[a] += 1
    tot += exp_cost(row, a)
    la = row["historical_action"]
    legacy += exp_cost(row, la)
    if la != "hold":
        t = row["observed_transit_hours"]
        if not (row[la]["min_hours"] <= t <= row[la]["max_hours"]):
            bad_transit += 1
print("actions", dict(acts))
print("policy expected mean cost", tot / len(rows), "legacy", legacy / len(rows))
print("observed transit outside bounds:", bad_transit)
