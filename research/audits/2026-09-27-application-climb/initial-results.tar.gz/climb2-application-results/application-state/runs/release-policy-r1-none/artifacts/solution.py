"""Enzyme dispatch policy.

The manual fully specifies the transit distribution (uniform integers on the
route's [min_hours, max_hours]) and the cost schedule, so the policy computes
exact expected cost per legal action instead of learning from the biased log.
Safety legality uses worst-case (max_hours) dose and the current signed record.
"""

import math

_KEYS = (
    "ground_handling_hours", "cold_handling_hours",
    "ground_base", "ground_per_kg", "cold_base", "cold_per_kg",
    "late_base", "late_value_fraction", "hold_base", "hold_value_fraction",
)


def fit(rows, config):
    return {k: float(config[k]) for k in _KEYS}


def _num(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        return None
    x = float(x)
    return x if math.isfinite(x) and x >= 0 else None


def _budget(row):
    """Remaining units of the current signed released record, else None."""
    certs = row.get("certificates")
    if not isinstance(certs, list):
        return None
    signed = [c for c in certs if isinstance(c, dict) and c.get("signed") is True]
    if not signed:
        return None
    revs = [_num(c.get("revision")) for c in signed]
    if any(r is None for r in revs):
        return None
    top = max(revs)
    current = [c for c, r in zip(signed, revs) if r == top]
    if len(current) != 1 or current[0].get("status") != "released":
        return None
    return _num(current[0].get("remaining_units"))


def _route(row, name):
    r = row.get(name)
    if not isinstance(r, dict) or r.get("open") is not True:
        return None
    lo, hi = _num(r.get("min_hours")), _num(r.get("max_hours"))
    if lo is None or hi is None or lo > hi or lo != int(lo) or hi != int(hi):
        return None
    return int(lo), int(hi)


def _p_late(lo, hi, handling, deadline):
    n = hi - lo + 1
    late = sum(1 for t in range(lo, hi + 1) if handling + t > deadline)
    return late / n


def decide(artifact, row):
    a = artifact
    value = _num(row.get("order_value"))
    weight = _num(row.get("weight_kg"))
    deadline = _num(row.get("deadline_hours"))
    ambient = _num(row.get("ambient_units_per_hour"))
    protect = _num(row.get("cold_protection_hours"))
    budget = _budget(row)
    if None in (value, weight, deadline, ambient, budget):
        return "hold"

    late_cost = a["late_base"] + a["late_value_fraction"] * value
    best, best_cost = "hold", a["hold_base"] + a["hold_value_fraction"] * value

    g = _route(row, "ground")
    if g is not None:
        h = a["ground_handling_hours"]
        if ambient * (h + g[1]) <= budget:
            cost = (a["ground_base"] + a["ground_per_kg"] * weight
                    + _p_late(g[0], g[1], h, deadline) * late_cost)
            if cost < best_cost:
                best, best_cost = "ground", cost

    c = _route(row, "cold")
    if c is not None and protect is not None and row.get("cold_boxes_available") is True:
        h = a["cold_handling_hours"]
        if ambient * max(0.0, h + c[1] - protect) <= budget:
            cost = (a["cold_base"] + a["cold_per_kg"] * weight
                    + _p_late(c[0], c[1], h, deadline) * late_cost)
            if cost < best_cost:
                best, best_cost = "cold", cost

    return best
