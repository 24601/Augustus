import json, copy, collections
import solution

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
art = json.loads(json.dumps(solution.fit(copy.deepcopy(rows), cfg)))
p = art["params"]

# Observed transit consistent with the stated uniform bounds?
bad = 0
for r in rows:
    a = r["historical_action"]
    if a in ("ground", "cold"):
        t = r["observed_transit_hours"]
        if not (r[a]["min_hours"] <= t <= r[a]["max_hours"]):
            bad += 1
print("observed transit outside bounds:", bad)


def serve(r):
    r = {k: v for k, v in r.items() if k not in
         ("historical_action", "observed_transit_hours", "observed_on_time")}
    return r


mine = collections.Counter(); tot_mine = 0; tot_leg = 0; illegal_leg = 0
for r in rows:
    s = serve(r)
    c = solution._candidates(p, s) or {
        "hold": p["hold_base"] + p["hold_value_fraction"] * s["order_value"]}
    d = solution.decide(art, s)
    assert d in ("ground", "cold", "hold")
    assert d in c, (d, c)
    mine[d] += 1
    tot_mine += c[d]
    a = r["historical_action"]
    if a in c:
        tot_leg += c[a]
    else:
        illegal_leg += 1
        tot_leg += c["hold"]
print("my actions", dict(mine), "expected mean", tot_mine / len(rows))
print("legacy expected mean", tot_leg / len(rows), "legacy illegal", illegal_leg)
print("ceiling", cfg["maximum_mean_cost"])

# Edge cases
base = serve(rows[0])
e = copy.deepcopy(base); e["certificates"] = [{"revision": 1, "signed": False, "status": "released", "remaining_units": 999}]
assert solution.decide(art, e) == "hold"
e = copy.deepcopy(base); e["certificates"].append({"revision": 9, "signed": True, "status": "quarantine", "remaining_units": 999})
assert solution.decide(art, e) == "hold"
e = copy.deepcopy(base); e["ground"]["open"] = False; e["cold"]["open"] = False
assert solution.decide(art, e) == "hold"
e = copy.deepcopy(base); e["cold_boxes_available"] = False
assert solution.decide(art, e) in ("ground", "hold")
e = copy.deepcopy(base); e["certificates"] = [{"revision": 1, "signed": True, "status": "released", "remaining_units": 48}]
# ground dose 3*(1+15)=48 -> equality allowed
assert "ground" in solution._candidates(p, e)
e["certificates"][0]["remaining_units"] = 47
assert "ground" not in solution._candidates(p, e)
print("edge cases ok")
