"""Enzyme dispatch policy.

The operations manual specifies the transit distribution exactly (independent
uniform integers on each route's [min_hours, max_hours]), so the expected cost
of every action is computed analytically rather than learned from the biased
historical log. Safety and availability are hard filters applied first; any
malformed or ambiguous input falls back to hold.
"""

import math

PARAM_KEYS = (
    "ground_handling_hours", "cold_handling_hours",
    "ground_base", "ground_per_kg", "cold_base", "cold_per_kg",
    "late_base", "late_value_fraction", "hold_base", "hold_value_fraction",
)


def _num(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        return None
    if not math.isfinite(x) or x < 0:
        return None
    return x


def _int(x):
    if isinstance(x, bool):
        return None
    if isinstance(x, int):
        return x
    if isinstance(x, float) and math.isfinite(x) and x == int(x):
        return int(x)
    return None


def fit(rows, config):
    params = {}
    for k in PARAM_KEYS:
        v = _num(config.get(k))
        if v is None:
            raise ValueError("bad config value for %s" % k)
        params[k] = float(v)
    return {"version": 1, "params": params}


def _current_budget(row):
    """Remaining units if the greatest signed certificate is a release, else None."""
    certs = row.get("certificates")
    if not isinstance(certs, list):
        return None
    best = None
    seen = set()
    for c in certs:
        if not isinstance(c, dict) or c.get("signed") is not True:
            continue
        rev = _int(c.get("revision"))
        if rev is None:
            return None
        if rev in seen:
            return None  # ambiguous authority
        seen.add(rev)
        if best is None or rev > best[0]:
            best = (rev, c)
    if best is None:
        return None
    cur = best[1]
    if cur.get("status") != "released":
        return None
    return _num(cur.get("remaining_units"))


def _route(row, name):
    r = row.get(name)
    if not isinstance(r, dict) or r.get("open") is not True:
        return None
    lo, hi = _int(r.get("min_hours")), _int(r.get("max_hours"))
    if lo is None or hi is None or lo < 0 or lo > hi:
        return None
    return lo, hi


def _p_late(handling, lo, hi, deadline):
    n = hi - lo + 1
    late = sum(1 for t in range(lo, hi + 1) if handling + t > deadline)
    return late / n


def _candidates(p, row):
    budget = _current_budget(row)
    ambient = _num(row.get("ambient_units_per_hour"))
    weight = _num(row.get("weight_kg"))
    value = _num(row.get("order_value"))
    deadline = _num(row.get("deadline_hours"))
    if None in (budget, ambient, weight, value, deadline):
        return {}
    late_cost = p["late_base"] + p["late_value_fraction"] * value
    out = {}

    g = _route(row, "ground")
    if g is not None:
        gh = p["ground_handling_hours"]
        dose = ambient * (gh + g[1])
        if dose <= budget:
            out["ground"] = (p["ground_base"] + p["ground_per_kg"] * weight
                             + _p_late(gh, g[0], g[1], deadline) * late_cost)

    c = _route(row, "cold")
    prot = _num(row.get("cold_protection_hours"))
    if c is not None and prot is not None and row.get("cold_boxes_available") is True:
        ch = p["cold_handling_hours"]
        dose = ambient * max(0.0, ch + c[1] - prot)
        if dose <= budget:
            out["cold"] = (p["cold_base"] + p["cold_per_kg"] * weight
                           + _p_late(ch, c[0], c[1], deadline) * late_cost)
    out["hold"] = p["hold_base"] + p["hold_value_fraction"] * value
    return out


def decide(artifact, row):
    try:
        p = artifact["params"]
        cands = _candidates(p, row)
    except Exception:
        return "hold"
    if not cands:
        return "hold"
    # Tie-break toward hold, then ground (cheaper carrier, no box use).
    order = {"hold": 0, "ground": 1, "cold": 2}
    return min(cands, key=lambda a: (round(cands[a], 9), order[a]))
