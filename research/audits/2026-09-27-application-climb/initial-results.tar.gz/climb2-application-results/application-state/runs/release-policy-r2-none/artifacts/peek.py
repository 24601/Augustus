import json
rows = json.load(open("rows.json"))
print(type(rows), len(rows))
print(json.dumps(rows[0], indent=1))
print(json.dumps(rows[1], indent=1))
keys = set()
for r in rows:
    keys |= set(r)
print(sorted(keys))
