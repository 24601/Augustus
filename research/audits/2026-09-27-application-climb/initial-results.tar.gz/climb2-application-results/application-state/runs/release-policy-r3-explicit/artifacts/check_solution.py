"""Checks for solution.py: fresh-process reload, legality, expected cost, edge cases."""
import copy, json, subprocess, sys, time

HIST = ("historical_action", "observed_transit_hours", "observed_on_time")

if len(sys.argv) > 1 and sys.argv[1] == "serve":
    import solution
    art = json.load(open("fitted_artifact.json"))
    rows = json.load(open("check_serving_rows.json"))
    t = time.time()
    out = [solution.decide(art, r) for r in rows]
    json.dump({"actions": out, "secs": time.time() - t}, open("check_serving_out.json", "w"))
    sys.exit(0)

import solution
cfg = json.load(open("config.json"))
rows = json.load(open("rows.json"))
t = time.time()
art = solution.fit(copy.deepcopy(rows), cfg)
print("fit secs %.4f" % (time.time() - t))
s = json.dumps(art)
print("artifact bytes", len(s))
open("fitted_artifact.json", "w").write(s)
serving = [{k: v for k, v in r.items() if k not in HIST} for r in rows]
json.dump(serving, open("check_serving_rows.json", "w"))
subprocess.run([sys.executable, "check_solution.py", "serve"], check=True)
res = json.load(open("check_serving_out.json"))
acts = res["actions"]
print("serve secs %.4f" % res["secs"])
assert acts == [solution.decide(art, r) for r in serving], "reload mismatch"
assert set(acts) <= {"ground", "cold", "hold"}


def legal(r, a):  # independent re-implementation of the manual
    if a == "hold":
        return True
    signed = [c for c in r["certificates"] if c.get("signed") is True]
    if not signed:
        return False
    cur = max(signed, key=lambda c: c["revision"])
    if cur["status"] != "released":
        return False
    rt = r[a]
    if not rt["open"]:
        return False
    if a == "ground":
        dose = r["ambient_units_per_hour"] * (cfg["ground_handling_hours"] + rt["max_hours"])
    else:
        if not r["cold_boxes_available"]:
            return False
        dose = r["ambient_units_per_hour"] * max(0, cfg["cold_handling_hours"] + rt["max_hours"] - r["cold_protection_hours"])
    return dose <= cur["remaining_units"]


def ecost(r, a):
    if a == "hold":
        return cfg["hold_base"] + cfg["hold_value_fraction"] * r["order_value"]
    rt = r[a]
    h = cfg[a + "_handling_hours"]
    n = rt["max_hours"] - rt["min_hours"] + 1
    late = sum(h + t > r["deadline_hours"] for t in range(rt["min_hours"], rt["max_hours"] + 1)) / n
    return (cfg[a + "_base"] + cfg[a + "_per_kg"] * r["weight_kg"]
            + late * (cfg["late_base"] + cfg["late_value_fraction"] * r["order_value"]))


bad = [i for i, (r, a) in enumerate(zip(rows, acts)) if not legal(r, a)]
print("illegal actions:", len(bad))
assert not bad
opt = [min((ecost(r, a), a) for a in ("ground", "cold", "hold") if legal(r, a)) for r in rows]
assert all(abs(ecost(r, a) - o[0]) < 1e-9 for r, a, o in zip(rows, acts, opt)), "not cost-optimal"
mean = lambda xs: sum(xs) / len(xs)
print("policy expected mean cost %.3f (ceiling %s)" % (mean([ecost(r, a) for r, a in zip(rows, acts)]), cfg["maximum_mean_cost"]))
print("always-hold mean %.3f" % mean([ecost(r, "hold") for r in rows]))
leg = [a if legal(r, a) else "hold" for r, a in zip(rows, (r["historical_action"] for r in rows))]
print("legacy (illegal->hold) mean %.3f; legacy illegal count %d" % (
    mean([ecost(r, a) for r, a in zip(rows, leg)]),
    sum(not legal(r, r["historical_action"]) for r in rows)))
print("action mix", {a: acts.count(a) for a in set(acts)})

# Observed-log sanity: realized transit within published bounds.
oob = sum(1 for r in rows if r["observed_transit_hours"] is not None and not (
    r[r["historical_action"]]["min_hours"] <= r["observed_transit_hours"] <= r[r["historical_action"]]["max_hours"]))
print("observed transits outside bounds:", oob)

# Hand-built edge cases.
base = {"order_value": 100, "weight_kg": 2, "deadline_hours": 20, "ambient_units_per_hour": 2,
        "cold_protection_hours": 10, "cold_boxes_available": True,
        "ground": {"open": True, "min_hours": 5, "max_hours": 9},
        "cold": {"open": True, "min_hours": 3, "max_hours": 7},
        "certificates": [{"revision": 1, "signed": True, "status": "released", "remaining_units": 20}]}
d = lambda **kw: solution.decide(art, {**copy.deepcopy(base), **kw})
assert d() == "ground"  # dose 2*(1+9)=20 == budget, on time
assert d(certificates=[{"revision": 1, "signed": True, "status": "released", "remaining_units": 19}]) == "cold"
assert d(certificates=[{"revision": 1, "signed": True, "status": "released", "remaining_units": 0}]) == "cold"  # cold dose 0
assert d(certificates=[{"revision": 2, "signed": True, "status": "quarantine", "remaining_units": 99},
                       {"revision": 1, "signed": True, "status": "released", "remaining_units": 99}]) == "hold"
assert d(certificates=[{"revision": 2, "signed": True, "status": "released", "remaining_units": 99},
                       {"revision": 1, "signed": True, "status": "quarantine", "remaining_units": 99}]) == "ground"
assert d(certificates=[{"revision": 3, "signed": False, "status": "revoked", "remaining_units": 0},
                       {"revision": 1, "signed": True, "status": "released", "remaining_units": 99}]) == "ground"
assert d(certificates=[{"revision": 1, "signed": False, "status": "released", "remaining_units": 99}]) == "hold"
assert d(certificates=[]) == "hold"
assert d(ground={"open": False, "min_hours": 5, "max_hours": 9}) == "cold"
assert d(ground={"open": False, "min_hours": 5, "max_hours": 9}, cold_boxes_available=False) == "hold"
assert d(deadline_hours=10) == "ground"  # arrival max 1+9=10 exactly on time
print("edge cases ok")
