"""Enzyme dispatch policy.

Legality is an exact rule from operations.md (current signed certificate,
worst-case thermal dose, route/box availability). Among legal actions the
policy picks the lowest expected cost, where lateness probability is computed
exactly from the published uniform integer transit distribution. The
historical log is selection-biased and adds nothing to that distribution, so
`fit` only freezes the cost/handling parameters.
"""

import math

ARTIFACT_VERSION = "enzyme-dispatch-policy-1"
_PARAMS = (
    "ground_handling_hours", "cold_handling_hours",
    "ground_base", "ground_per_kg", "cold_base", "cold_per_kg",
    "late_base", "late_value_fraction", "hold_base", "hold_value_fraction",
)


def fit(rows, config):
    params = {}
    for key in _PARAMS:
        value = float(config[key])
        if not math.isfinite(value) or value < 0:
            raise ValueError("invalid config value for %s" % key)
        params[key] = value
    return {"version": ARTIFACT_VERSION, "params": params,
            "fit_rows": len(rows) if rows is not None else 0}


def _num(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    value = float(value)
    if not math.isfinite(value) or value < 0:
        return None
    return value


def _current_budget(row):
    """Remaining thermal budget of the current released record, else None."""
    certs = row.get("certificates")
    if not isinstance(certs, list):
        return None
    current = None
    for cert in certs:
        if not isinstance(cert, dict) or cert.get("signed") is not True:
            continue
        rev = _num(cert.get("revision"))
        if rev is None:
            continue
        if current is None or rev > current[0]:
            current = (rev, cert)
        elif rev == current[0]:
            return None  # duplicate signed revision: ambiguous authority
    if current is None or current[1].get("status") != "released":
        return None
    return _num(current[1].get("remaining_units"))


def _route(row, name):
    route = row.get(name)
    if not isinstance(route, dict) or route.get("open") is not True:
        return None
    lo, hi = _num(route.get("min_hours")), _num(route.get("max_hours"))
    if lo is None or hi is None or lo > hi or lo != int(lo) or hi != int(hi):
        return None
    return int(lo), int(hi)


def _p_late(handling, lo, hi, deadline):
    late = sum(1 for t in range(lo, hi + 1) if handling + t > deadline)
    return late / (hi - lo + 1)


def decide(artifact, row):
    p = artifact["params"]
    try:
        value = _num(row.get("order_value"))
        weight = _num(row.get("weight_kg"))
        deadline = _num(row.get("deadline_hours"))
        ambient = _num(row.get("ambient_units_per_hour"))
        protection = _num(row.get("cold_protection_hours"))
        budget = _current_budget(row)
        if None in (value, weight, deadline, ambient, budget):
            return "hold"

        late_cost = p["late_base"] + p["late_value_fraction"] * value
        best_action = "hold"
        best_cost = p["hold_base"] + p["hold_value_fraction"] * value

        ground = _route(row, "ground")
        if ground is not None:
            lo, hi = ground
            gh = p["ground_handling_hours"]
            if ambient * (gh + hi) <= budget:
                cost = (p["ground_base"] + p["ground_per_kg"] * weight
                        + _p_late(gh, lo, hi, deadline) * late_cost)
                if cost < best_cost:
                    best_action, best_cost = "ground", cost

        cold = _route(row, "cold")
        if (cold is not None and row.get("cold_boxes_available") is True
                and protection is not None):
            lo, hi = cold
            ch = p["cold_handling_hours"]
            if ambient * max(0.0, ch + hi - protection) <= budget:
                cost = (p["cold_base"] + p["cold_per_kg"] * weight
                        + _p_late(ch, lo, hi, deadline) * late_cost)
                if cost < best_cost:
                    best_action, best_cost = "cold", cost
        return best_action
    except Exception:
        return "hold"
