"""Enzyme dispatch policy.

The operations manual fully specifies the transit distribution (uniform integer
on [min_hours, max_hours] per route) and the cost schedule, so the policy is an
exact expected-cost minimisation over the legal actions. The biased historical
log is not needed to estimate anything; fit() only exports the cost/handling
parameters.
"""

import math

_KEYS = (
    "ground_handling_hours", "cold_handling_hours",
    "ground_base", "ground_per_kg", "cold_base", "cold_per_kg",
    "late_base", "late_value_fraction", "hold_base", "hold_value_fraction",
)


def fit(rows, config):
    return {"version": 1, "params": {k: float(config[k]) for k in _KEYS}}


def _num(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise ValueError("non-numeric")
    x = float(x)
    if not math.isfinite(x) or x < 0:
        raise ValueError("bad number")
    return x


def _budget(row):
    """Remaining thermal budget of the current signed release, or None."""
    certs = row.get("certificates")
    if not isinstance(certs, list):
        return None
    best = None
    for c in certs:
        if not isinstance(c, dict) or c.get("signed") is not True:
            continue
        rev = c.get("revision")
        if isinstance(rev, bool) or not isinstance(rev, (int, float)):
            continue
        if best is None or rev > best["revision"]:
            best = c
    if best is None or best.get("status") != "released":
        return None
    return _num(best.get("remaining_units"))


def _route(row, name):
    r = row.get(name)
    if not isinstance(r, dict) or r.get("open") is not True:
        return None
    lo, hi = _num(r.get("min_hours")), _num(r.get("max_hours"))
    if lo > hi:
        return None
    return int(math.ceil(lo)), int(math.floor(hi)), hi


def _p_late(lo, hi, handling, deadline):
    n = hi - lo + 1
    if n <= 0:
        return 1.0
    # late iff handling + t > deadline, t integer uniform in [lo, hi]
    first_late = max(lo, int(math.floor(deadline - handling)) + 1)
    return max(0, hi - first_late + 1) / n


def decide(artifact, row):
    try:
        p = artifact["params"]
        budget = _budget(row)
        if budget is None:
            return "hold"
        value = _num(row["order_value"])
        weight = _num(row["weight_kg"])
        deadline = _num(row["deadline_hours"])
        ambient = _num(row["ambient_units_per_hour"])
        late_cost = p["late_base"] + p["late_value_fraction"] * value

        best_action = "hold"
        best_cost = p["hold_base"] + p["hold_value_fraction"] * value

        g = _route(row, "ground")
        if g is not None:
            lo, hi, hmax = g
            gh = p["ground_handling_hours"]
            if ambient * (gh + hmax) <= budget:
                cost = (p["ground_base"] + p["ground_per_kg"] * weight
                        + _p_late(lo, hi, gh, deadline) * late_cost)
                if cost < best_cost:
                    best_action, best_cost = "ground", cost

        c = _route(row, "cold")
        if c is not None and row.get("cold_boxes_available") is True:
            lo, hi, hmax = c
            ch = p["cold_handling_hours"]
            prot = _num(row["cold_protection_hours"])
            if ambient * max(0.0, ch + hmax - prot) <= budget:
                cost = (p["cold_base"] + p["cold_per_kg"] * weight
                        + _p_late(lo, hi, ch, deadline) * late_cost)
                if cost < best_cost:
                    best_action, best_cost = "cold", cost

        return best_action
    except Exception:
        return "hold"
