import json, subprocess, sys, random, copy

import solution

rows = json.load(open("rows.json"))
config = json.load(open("config.json"))
art = solution.fit(rows, config)
s = json.dumps(art)
assert len(s) < 2_000_000
json.dump(json.loads(s), open("check_artifact.json", "w"))

# Fresh-process reload
code = ("import json,solution;a=json.load(open('check_artifact.json'));"
        "r=json.load(open('rows.json'));"
        "print(json.dumps([solution.decide(a,x) for x in r]))")
out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
fresh = json.loads(out.stdout) if out.returncode == 0 else None
print("fresh-process ok:", fresh is not None, out.stderr[-300:])

C = config


def cur(row):
    signed = [c for c in row["certificates"] if c["signed"] is True]
    if not signed:
        return None
    c = max(signed, key=lambda c: c["revision"])
    return c["remaining_units"] if c["status"] == "released" else None


def legal(row, a):
    if a == "hold":
        return True
    b = cur(row)
    if b is None:
        return False
    r = row[a]
    if r["open"] is not True:
        return False
    if a == "ground":
        return row["ambient_units_per_hour"] * (C["ground_handling_hours"] + r["max_hours"]) <= b
    if row["cold_boxes_available"] is not True:
        return False
    return row["ambient_units_per_hour"] * max(0, C["cold_handling_hours"] + r["max_hours"] - row["cold_protection_hours"]) <= b


def exp_cost(row, a):
    v = row["order_value"]
    if a == "hold":
        return C["hold_base"] + C["hold_value_fraction"] * v
    r = row[a]
    h = C[a + "_handling_hours"]
    carrier = C[a + "_base"] + C[a + "_per_kg"] * row["weight_kg"]
    ts = range(r["min_hours"], r["max_hours"] + 1)
    pl = sum(1 for t in ts if h + t > row["deadline_hours"]) / len(ts)
    return carrier + pl * (C["late_base"] + C["late_value_fraction"] * v)


acts = [solution.decide(art, r) for r in rows]
assert fresh is None or fresh == acts
illegal = sum(not legal(r, a) for r, a in zip(rows, acts))
mean = sum(exp_cost(r, a) for r, a in zip(rows, acts)) / len(rows)
opt = sum(min(exp_cost(r, a) for a in ("ground", "cold", "hold") if legal(r, a)) for r in rows) / len(rows)
hold = sum(exp_cost(r, "hold") for r in rows) / len(rows)
print("n", len(rows), "illegal", illegal, "mean exp cost", round(mean, 3), "oracle", round(opt, 3), "all-hold", round(hold, 3))
print("action mix", {a: acts.count(a) for a in set(acts)})

# Historical: legacy legality + transit bounds sanity
leg_illegal = sum(not legal(r, r["historical_action"]) for r in rows)
oob = sum(1 for r in rows if r["historical_action"] != "hold" and not (
    r[r["historical_action"]]["min_hours"] <= r["observed_transit_hours"] <= r[r["historical_action"]]["max_hours"]))
print("legacy illegal", leg_illegal, "observed out of bounds", oob)
hist_real = []
for r in rows:
    a = r["historical_action"]
    if a == "hold":
        hist_real.append(exp_cost(r, "hold"))
    else:
        late = C[a + "_handling_hours"] + r["observed_transit_hours"] > r["deadline_hours"]
        hist_real.append(C[a + "_base"] + C[a + "_per_kg"] * r["weight_kg"] + late * (C["late_base"] + C["late_value_fraction"] * r["order_value"]))
print("legacy realized mean", round(sum(hist_real) / len(rows), 3))

# Perturbation: snapshots with changed certs/routes must stay legal
rng = random.Random(0)
bad = 0
for _ in range(20000):
    r = copy.deepcopy(rng.choice(rows))
    for k in ("historical_action", "observed_transit_hours", "observed_on_time"):
        r.pop(k)
    r["ground"]["open"] = rng.random() < 0.7
    r["cold"]["open"] = rng.random() < 0.7
    r["cold_boxes_available"] = rng.random() < 0.7
    r["ambient_units_per_hour"] = rng.randint(0, 30)
    for c in r["certificates"]:
        c["signed"] = rng.random() < 0.6
        c["status"] = rng.choice(["released", "released", "quarantine", "revoked"])
        c["remaining_units"] = rng.randint(0, 200)
    a = solution.decide(art, r)
    assert a in ("ground", "cold", "hold")
    bad += not legal(r, a)
print("perturbed illegal", bad)
print("garbage row ->", solution.decide(art, {}), solution.decide(art, {"certificates": "x"}))
