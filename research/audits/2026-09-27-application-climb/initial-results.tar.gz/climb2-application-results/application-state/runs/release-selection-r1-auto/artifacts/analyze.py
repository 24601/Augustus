"""Compare stocks/thresholds on pre- and post-change data with honest validation."""
import json, random

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
FN, FP = cfg["fn_cost"], cfg["fp_cost"]
post = [r for r in rows if r["day"] >= 90]
pre = [r for r in rows if r["day"] < 90]


def loss(sub, stock, t):
    # review iff score >= t
    tot = 0
    for r in sub:
        rev = r["scores"][stock] >= t
        if r["fraud"] and not rev:
            tot += FN
        elif not r["fraud"] and rev:
            tot += FP
    return tot / len(sub)


def best_t(sub, stock):
    cands = sorted({r["scores"][stock] for r in sub}) + [1.01]
    best = min(cands, key=lambda t: (loss(sub, stock, t), t))
    return best, loss(sub, stock, best)


def auc(sub, stock):
    pos = [r["scores"][stock] for r in sub if r["fraud"]]
    neg = [r["scores"][stock] for r in sub if not r["fraud"]]
    s = sum((p > n) + 0.5 * (p == n) for p in pos for n in neg)
    return s / (len(pos) * len(neg))


for name, sub in (("pre", pre), ("post", post)):
    print(f"== {name} n={len(sub)} fraud={sum(r['fraud'] for r in sub)}")
    print("  constant review", sum(1 - r["fraud"] for r in sub) / len(sub),
          " constant allow", FN * sum(r["fraud"] for r in sub) / len(sub))
    for s in ("legacy", "compact", "large"):
        t, l = best_t(sub, s)
        print(f"  {s:8s} auc={auc(sub, s):.3f} legacy0.5loss={loss(sub, s, 0.5):.3f} in-sample best t={t:.4f} loss={l:.3f}")

# temporal holdout inside post: fit on days 90-109, test on 110-119
tr = [r for r in post if r["day"] < 110]
te = [r for r in post if r["day"] >= 110]
print("== temporal holdout post (fit 90-109 n=%d, test 110-119 n=%d)" % (len(tr), len(te)))
for s in ("legacy", "compact"):
    t, l = best_t(tr, s)
    print(f"  {s}: t={t:.4f} train={l:.3f} test={loss(te, s, t):.3f}")
# Also: pre-fit threshold applied to post
for s in ("legacy", "compact"):
    t, _ = best_t(pre, s)
    print(f"  pre-fit {s} t={t:.4f} on post: {loss(post, s, t):.3f}")

# repeated 5-fold CV on post
rng = random.Random(0)
for s in ("legacy", "compact"):
    outs = []
    for rep in range(40):
        idx = list(range(len(post)))
        rng.shuffle(idx)
        tot = 0
        for k in range(5):
            test = set(idx[k::5])
            trn = [post[i] for i in idx if i not in test]
            tst = [post[i] for i in test]
            t, _ = best_t(trn, s)
            tot += loss(tst, s, t) * len(tst)
        outs.append(tot / len(post))
    outs.sort()
    print(f"  CV post {s}: mean={sum(outs)/len(outs):.3f} range=[{outs[0]:.3f},{outs[-1]:.3f}]")

# bootstrap of the full fit-and-evaluate procedure (optimism-corrected via out-of-bag)
for s in ("legacy", "compact"):
    oob = []
    for b in range(300):
        bs = [rng.randrange(len(post)) for _ in post]
        inb = set(bs)
        t, _ = best_t([post[i] for i in bs], s)
        o = [post[i] for i in range(len(post)) if i not in inb]
        oob.append(loss(o, s, t))
    oob.sort()
    print(f"  OOB bootstrap {s}: mean={sum(oob)/len(oob):.3f} 5%={oob[15]:.3f} 95%={oob[284]:.3f} P(>0.45)={sum(x>0.45 for x in oob)/len(oob):.2f}")

# loss curve near optimum for compact on post
for s in ("legacy", "compact"):
    print(s, [(round(t, 2), round(loss(post, s, t), 3)) for t in [i / 100 for i in range(0, 101, 5)]])
