"""Fine look at compact scores post-change: where frauds and legit orders sit."""
import json

rows = json.load(open("rows.json"))
post = [r for r in rows if r["day"] >= 90]
fr = sorted(r["scores"]["compact"] for r in post if r["fraud"])
lg = sorted(r["scores"]["compact"] for r in post if not r["fraud"])
print("fraud compact:", [round(x, 4) for x in fr])
print("legit compact max/top:", [round(x, 4) for x in lg[-60:]])
print("legit min", lg[0], "fraud min", fr[0], "overall max", max(fr + lg))


def loss(t):
    return (8 * sum(x < t for x in fr) + sum(x >= t for x in lg)) / len(post)


for i in range(40, 101, 2):
    t = i / 1000
    print(f"t={t:.3f} loss={loss(t):.3f} missed_fraud={sum(x < t for x in fr)} reviews={sum(x >= t for x in fr + lg)}")
