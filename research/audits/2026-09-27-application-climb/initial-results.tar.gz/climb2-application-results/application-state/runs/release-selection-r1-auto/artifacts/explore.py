import json, math, collections

rows = json.load(open("rows.json"))
print(len(rows), type(rows))
print(rows[0])
print(rows[-1])
keys = collections.Counter(tuple(sorted(r.keys())) for r in rows)
print(keys)
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
post = [r for r in rows if r["day"] >= 90]
pre = [r for r in rows if r["day"] < 90]
print("pre", len(pre), "post", len(post))
for name, sub in (("pre", pre), ("post", post)):
    print(name, "fraud rate", sum(r["fraud"] for r in sub) / max(1, len(sub)))
# score validity
bad = collections.Counter()
for r in rows:
    for s in ("legacy", "compact", "large"):
        v = r["scores"].get(s)
        if not (isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 <= v <= 1):
            bad[(s, repr(v)[:20])] += 1
print("invalid", bad)
print("fraud types", collections.Counter(type(r["fraud"]).__name__ + repr(r["fraud"]) for r in rows))
print("day hist", sorted(collections.Counter(r["day"] // 10 * 10 for r in rows).items()))
