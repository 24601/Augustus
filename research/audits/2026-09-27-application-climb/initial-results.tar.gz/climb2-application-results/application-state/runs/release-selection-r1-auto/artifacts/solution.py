"""Fraud-review decision: one in-envelope stock plus a cost-optimal threshold.

fit() uses only rows from the current checkout funnel (day >= funnel change),
drops stocks over the latency allowance, selects the stock with the lowest
cross-validated business loss (or `constant` review if nothing beats it), and
sets the threshold by minimizing a kernel-smoothed empirical loss so the cut
does not sit on the edge of a steep loss cliff.

decide() reviews whenever the registered stock's score is missing or invalid.
"""
import math
import random

FUNNEL_CHANGE_DAY = 90  # operations note: checkout funnel changed on day 90
CV_FOLDS = 5
CV_REPEATS = 3
BANDWIDTH_FRACTION = 0.05  # smoothing kernel width as a fraction of score spread


def _valid_score(v):
    return (isinstance(v, (int, float)) and not isinstance(v, bool)
            and math.isfinite(v) and 0.0 <= v <= 1.0)


def _phi(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def _empirical_loss(pairs, t, fn, fp):
    # pairs: (score, fraud); review iff score >= t
    total = 0
    for s, y in pairs:
        if s >= t:
            total += 0 if y else fp
        else:
            total += fn if y else 0
    return total / len(pairs)


def _fit_threshold(pairs, fn, fp):
    """Threshold minimizing a Gaussian-smoothed expected loss."""
    scores = sorted(s for s, _ in pairs)
    lo, hi = scores[0], scores[-1]
    q = lambda p: scores[min(len(scores) - 1, int(p * len(scores)))]
    spread = max(q(0.95) - q(0.05), 1e-6)
    h = BANDWIDTH_FRACTION * spread
    steps = 200
    best_t, best_l = None, None
    for i in range(steps + 1):
        t = lo + (hi - lo) * i / steps
        total = 0.0
        for s, y in pairs:
            p_review = _phi((s - t) / h)
            total += fp * p_review if not y else fn * (1.0 - p_review)
        loss = total / len(pairs)
        if best_l is None or loss < best_l:
            best_t, best_l = t, loss
    return best_t


def _cv_loss(pairs, fn, fp, seed=0):
    rng = random.Random(seed)
    losses = []
    for _ in range(CV_REPEATS):
        idx = list(range(len(pairs)))
        rng.shuffle(idx)
        total = 0.0
        for k in range(CV_FOLDS):
            test = set(idx[k::CV_FOLDS])
            train = [pairs[i] for i in idx if i not in test]
            t = _fit_threshold(train, fn, fp)
            total += sum(_empirical_loss([pairs[i]], t, fn, fp) for i in test)
        losses.append(total / len(pairs))
    return sum(losses) / len(losses)


def fit(rows, config):
    fn = config.get("fn_cost", 8)
    fp = config.get("fp_cost", 1)
    max_latency = config.get("max_latency_ms", 15)
    change_day = config.get("funnel_change_day", FUNNEL_CHANGE_DAY)

    current = [r for r in rows
               if isinstance(r.get("day"), (int, float)) and r["day"] >= change_day
               and r.get("fraud") in (0, 1)]
    if not current:
        current = [r for r in rows if r.get("fraud") in (0, 1)]

    n = len(current)
    fraud_rate = sum(r["fraud"] for r in current) / n if n else 1.0
    # constant `review` costs fp per legit order; constant `allow` is never shipped
    # (missing scores must not be authorized, and allowing all costs more here).
    report = {"constant": {"cv_loss": fp * (1.0 - fraud_rate)}}
    best = {"stock": "constant", "action": "review", "cv_loss": fp * (1.0 - fraud_rate)}

    for name, meta in sorted(config.get("stocks", {}).items()):
        latency = meta.get("latency_ms")
        if not isinstance(latency, (int, float)) or latency > max_latency:
            report[name] = {"excluded": "latency %s ms > %s ms" % (latency, max_latency)}
            continue
        pairs = [(r["scores"][name], r["fraud"]) for r in current
                 if _valid_score(r.get("scores", {}).get(name))]
        if len(pairs) < 50 or len({y for _, y in pairs}) < 2:
            report[name] = {"excluded": "insufficient valid labeled scores"}
            continue
        cv = _cv_loss(pairs, fn, fp)
        report[name] = {"cv_loss": cv}
        if cv < best["cv_loss"]:
            best = {"stock": name, "threshold": _fit_threshold(pairs, fn, fp), "cv_loss": cv}

    artifact = {"stock": best["stock"], "cv_loss": round(best["cv_loss"], 6),
                "fit_rows": n, "funnel_change_day": change_day, "candidates": report}
    if best["stock"] == "constant":
        artifact["action"] = "review"
    else:
        artifact["threshold"] = best["threshold"]
    return artifact


def decide(artifact, row):
    if not isinstance(artifact, dict):
        return "review"
    stock = artifact.get("stock")
    if stock == "constant":
        return "review"  # no stock provisioned, so no score to authorize on
    threshold = artifact.get("threshold")
    if (not isinstance(threshold, (int, float)) or isinstance(threshold, bool)
            or not math.isfinite(threshold)):
        return "review"
    scores = row.get("scores") if isinstance(row, dict) else None
    score = scores.get(stock) if isinstance(scores, dict) else None
    if not _valid_score(score):
        return "review"
    return "review" if score >= threshold else "allow"
