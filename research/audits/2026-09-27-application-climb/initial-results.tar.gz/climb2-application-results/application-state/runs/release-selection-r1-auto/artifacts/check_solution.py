"""End-to-end checks for solution.py."""
import json, math, random, subprocess, sys

import solution

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))
FN, FP = cfg["fn_cost"], cfg["fp_cost"]


def serve_row(r, stock):
    return {"request_id": r["request_id"],
            "scores": {} if stock == "constant" else {stock: r["scores"][stock]}}


def mean_loss(art, sub):
    tot = 0
    for r in sub:
        d = solution.decide(art, serve_row(r, art["stock"]))
        assert d in ("allow", "review")
        if r["fraud"] and d == "allow":
            tot += FN
        elif not r["fraud"] and d == "review":
            tot += FP
    return tot / len(sub)


art = solution.fit(rows, cfg)
art = json.loads(json.dumps(art))
print("artifact:", json.dumps(art, indent=1))
assert art["stock"] in list(cfg["stocks"]) + ["constant"]
assert art["stock"] == "constant" or cfg["stocks"][art["stock"]]["latency_ms"] <= cfg["max_latency_ms"]
post = [r for r in rows if r["day"] >= 90]
print("in-sample post loss:", round(mean_loss(art, post), 3))
print("review rate post:", sum(solution.decide(art, serve_row(r, art["stock"])) == "review" for r in post) / len(post))

# Temporal holdout of the full procedure: fit with data up to day 109, test on 110-119.
early = [r for r in rows if r["day"] < 110]
late = [r for r in rows if r["day"] >= 110]
a2 = json.loads(json.dumps(solution.fit(early, cfg)))
print("temporal holdout: stock=%s thr=%s test loss=%.3f (n=%d)" % (
    a2["stock"], a2.get("threshold"), mean_loss(a2, late), len(late)))

# Out-of-bag bootstrap of the full procedure on post-change rows.
rng = random.Random(1)
oob = []
pre = [r for r in rows if r["day"] < 90]
for b in range(20):
    bs = [rng.randrange(len(post)) for _ in post]
    inb = set(bs)
    a = solution.fit(pre + [post[i] for i in bs], cfg)
    o = [post[i] for i in range(len(post)) if i not in inb]
    oob.append(mean_loss(a, o))
oob.sort()
print("OOB bootstrap full procedure: mean=%.3f 5%%=%.3f 95%%=%.3f max=%.3f P(>0.45)=%.2f" % (
    sum(oob) / len(oob), oob[1], oob[18], oob[-1], sum(x > 0.45 for x in oob) / len(oob)))

# Invalid / missing scores must be reviewed.
bad_values = [None, "0.1", float("nan"), float("inf"), -0.01, 1.01, True, False, [0.0], {}]
for v in bad_values:
    assert solution.decide(art, {"request_id": "x", "scores": {art["stock"]: v}}) == "review", v
assert solution.decide(art, {"request_id": "x", "scores": {}}) == "review"
assert solution.decide(art, {"request_id": "x"}) == "review"
assert solution.decide(art, {"request_id": "x", "scores": None}) == "review"
assert solution.decide(art, None) == "review"
assert solution.decide(art, {"request_id": "x", "scores": {"legacy": 0.0, "large": 0.0}}) == "review"
assert solution.decide(art, {"request_id": "x", "scores": {art["stock"]: 0.0}}) == "allow"
print("invalid-score checks OK")

# Fresh process with only solution.py + exported artifact.
json.dump(art, open("fitted_artifact.json", "w"))
probe = ("import json, solution; a=json.load(open('fitted_artifact.json'));"
         "print(solution.decide(a, {'request_id':'r','scores':{a['stock']:0.0}}),"
         "solution.decide(a, {'request_id':'r','scores':{a['stock']:1.0}}),"
         "solution.decide(a, {'request_id':'r','scores':{}}))")
out = subprocess.run([sys.executable, "-c", probe], capture_output=True, text=True)
print("fresh process:", out.stdout.strip(), out.stderr.strip())
assert out.stdout.split() == ["allow", "review", "review"]
print("ALL CHECKS PASSED")
