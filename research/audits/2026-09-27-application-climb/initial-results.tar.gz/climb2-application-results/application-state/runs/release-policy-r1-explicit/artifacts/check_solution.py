"""Checks: fresh-process reload, legality audit, expected cost vs baselines, edge cases."""
import json, subprocess, sys, copy

rows = json.load(open("rows.json"))
cfg = json.load(open("config.json"))

import solution
art = solution.fit(rows, cfg)
json.dump(art, open("artifact_check.json", "w"))

# Fresh-process replay
code = ("import json,solution;a=json.load(open('artifact_check.json'));"
        "rs=json.load(open('rows.json'));"
        "[r.pop(k,None) for r in rs for k in ('historical_action','observed_transit_hours','observed_on_time')];"
        "print(json.dumps([solution.decide(a,r) for r in rs]))")
fresh = json.loads(subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True).stdout)
local = [solution.decide(art, r) for r in rows]
assert fresh == local, "reload mismatch"

def legal(row, a):
    if a == "hold":
        return True
    signed = [c for c in row["certificates"] if c["signed"] is True]
    if not signed:
        return False
    cur = max(signed, key=lambda c: c["revision"])
    if cur["status"] != "released":
        return False
    r = row[a]
    if not r["open"]:
        return False
    amb = row["ambient_units_per_hour"]
    if a == "ground":
        dose = amb * (cfg["ground_handling_hours"] + r["max_hours"])
    else:
        if not row["cold_boxes_available"]:
            return False
        dose = amb * max(0, cfg["cold_handling_hours"] + r["max_hours"] - row["cold_protection_hours"])
    return dose <= cur["remaining_units"]

def exp_cost(row, a):
    v, w = row["order_value"], row["weight_kg"]
    if a == "hold":
        return cfg["hold_base"] + cfg["hold_value_fraction"] * v
    h = cfg[a + "_handling_hours"]
    r = row[a]
    ts = range(r["min_hours"], r["max_hours"] + 1)
    pl = sum(h + t > row["deadline_hours"] for t in ts) / len(ts)
    return cfg[a + "_base"] + cfg[a + "_per_kg"] * w + pl * (cfg["late_base"] + cfg["late_value_fraction"] * v)

illegal_hist = sum(not legal(r, r["historical_action"]) for r in rows)
assert all(legal(r, a) for r, a in zip(rows, local)), "illegal decision"
mean = lambda xs: sum(xs) / len(xs)
print("ours expected mean cost:", round(mean([exp_cost(r, a) for r, a in zip(rows, local)]), 3))
print("legacy expected mean cost:", round(mean([exp_cost(r, r["historical_action"]) for r in rows]), 3),
      "illegal legacy actions:", illegal_hist)
print("all-hold mean cost:", round(mean([exp_cost(r, "hold") for r in rows]), 3))
print("ceiling:", cfg["maximum_mean_cost"])
from collections import Counter
print("action mix:", Counter(local), "legacy mix:", Counter(r["historical_action"] for r in rows))

# Realized-cost replay where our action matches the logged route
real = []
for r, a in zip(rows, local):
    if a == r["historical_action"] and a != "hold":
        late = not r["observed_on_time"]
        real.append(cfg[a + "_base"] + cfg[a + "_per_kg"] * r["weight_kg"]
                    + late * (cfg["late_base"] + cfg["late_value_fraction"] * r["order_value"]))
        ex = cfg[a + "_handling_hours"] + r["observed_transit_hours"] > r["deadline_hours"]
        assert ex == late, ("on_time semantics mismatch", r["order_id"])
print("matched dispatched rows:", len(real), "realized mean", round(mean(real), 3) if real else None)

# Edge cases
base = copy.deepcopy(rows[0])
for k in ("historical_action", "observed_transit_hours", "observed_on_time"):
    base.pop(k)
def variant(f):
    r = copy.deepcopy(base); f(r); return solution.decide(art, r)
assert variant(lambda r: r.__setitem__("certificates", [])) == "hold"
assert variant(lambda r: r.__setitem__("certificates", [{"revision": 9, "signed": False, "status": "released", "remaining_units": 999}])) == "hold"
assert variant(lambda r: r["certificates"].append({"revision": 4, "signed": True, "status": "quarantine", "remaining_units": 999})) == "hold"
assert variant(lambda r: r["certificates"].append({"revision": 4, "signed": True, "status": "revoked", "remaining_units": 999})) == "hold"
assert variant(lambda r: (r["ground"].__setitem__("open", False), r["cold"].__setitem__("open", False))) == "hold"
assert variant(lambda r: (r["ground"].__setitem__("open", False), r.__setitem__("cold_boxes_available", False))) == "hold"
assert variant(lambda r: r.__setitem__("certificates", "garbage")) == "hold"
assert variant(lambda r: r["ground"].__setitem__("open", "true")) in ("cold", "hold")
# Equality boundary: ground dose exactly equals budget -> allowed
def eq(r):
    r["ground"].update(open=True, min_hours=5, max_hours=5); r["deadline_hours"] = 100
    r["ambient_units_per_hour"] = 2; r["cold"]["open"] = False
    r["certificates"] = [{"revision": 1, "signed": True, "status": "released", "remaining_units": 12}]
assert variant(eq) == "ground"
def over(r):
    eq(r); r["certificates"][0]["remaining_units"] = 11.9
assert variant(over) == "hold"
print("edge cases ok")
