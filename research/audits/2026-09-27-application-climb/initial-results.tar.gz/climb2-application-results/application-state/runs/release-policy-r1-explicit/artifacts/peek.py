import json
rows = json.load(open("rows.json"))
print(type(rows), len(rows))
for r in rows[:2]:
    print(json.dumps(r, indent=1))
keys = set()
for r in rows:
    keys |= set(r)
print(sorted(keys))
