"""Enzyme dispatch policy.

Legality is exact (operations manual rev. 3); among legal actions pick the one
with the lowest expected cost, using the published uniform transit distribution.
The historical log is a biased record of the old dispatcher and is not fit.
"""
import math

PARAM_KEYS = (
    "ground_handling_hours", "cold_handling_hours",
    "ground_base", "ground_per_kg", "cold_base", "cold_per_kg",
    "late_base", "late_value_fraction", "hold_base", "hold_value_fraction",
)


def fit(rows, config):
    return {"policy": "exact-legal-min-expected-cost-v1",
            "params": {k: float(config[k]) for k in PARAM_KEYS}}


def _num(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)):
        raise ValueError("not a number")
    x = float(x)
    if not math.isfinite(x) or x < 0:
        raise ValueError("bad number")
    return x


def _current_budget(certs):
    """Remaining units under the greatest signed revision if released, else None."""
    best = None
    for c in certs:
        if isinstance(c, dict) and c.get("signed") is True:
            rev = _num(c["revision"])
            if best is None or rev > best[0]:
                best = (rev, c)
    if best is None or best[1].get("status") != "released":
        return None
    return _num(best[1]["remaining_units"])


def _route(row, name):
    r = row.get(name)
    if not isinstance(r, dict) or r.get("open") is not True:
        return None
    lo, hi = _num(r["min_hours"]), _num(r["max_hours"])
    if lo != int(lo) or hi != int(hi) or lo < 1 or lo > hi:
        return None
    return int(lo), int(hi)


def _late_prob(handling, lo, hi, deadline):
    late = sum(1 for t in range(lo, hi + 1) if handling + t > deadline)
    return late / (hi - lo + 1)


def decide(artifact, row):
    try:
        p = artifact["params"]
        budget = _current_budget(row["certificates"])
        if budget is None:
            return "hold"
        value = _num(row["order_value"])
        weight = _num(row["weight_kg"])
        deadline = _num(row["deadline_hours"])
        ambient = _num(row["ambient_units_per_hour"])
        late_cost = p["late_base"] + p["late_value_fraction"] * value
        options = [(p["hold_base"] + p["hold_value_fraction"] * value, 2, "hold")]

        g = _route(row, "ground")
        if g is not None:
            gh = p["ground_handling_hours"]
            if ambient * (gh + g[1]) <= budget:
                cost = (p["ground_base"] + p["ground_per_kg"] * weight
                        + late_cost * _late_prob(gh, g[0], g[1], deadline))
                options.append((cost, 0, "ground"))

        c = _route(row, "cold")
        if c is not None and row.get("cold_boxes_available") is True:
            ch = p["cold_handling_hours"]
            protect = _num(row["cold_protection_hours"])
            if ambient * max(0.0, ch + c[1] - protect) <= budget:
                cost = (p["cold_base"] + p["cold_per_kg"] * weight
                        + late_cost * _late_prob(ch, c[0], c[1], deadline))
                options.append((cost, 1, "cold"))

        return min(options)[2]
    except Exception:
        return "hold"
