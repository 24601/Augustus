import json, random

rows = json.load(open("rows.json"))
FN, FP = 8, 1


def loss(rs, s, t):
    # review if score >= t
    L = 0
    for r in rs:
        rev = r["scores"][s] >= t
        if r["fraud"] and not rev:
            L += FN
        elif not r["fraud"] and rev:
            L += FP
    return L / len(rs)


def best_t(rs, s):
    cands = sorted({r["scores"][s] for r in rs}) + [1.01]
    return min(cands, key=lambda t: (loss(rs, s, t), t))


def auc(rs, s):
    pos = [r["scores"][s] for r in rs if r["fraud"]]
    neg = [r["scores"][s] for r in rs if not r["fraud"]]
    c = sum((p > n) + 0.5 * (p == n) for p in pos for n in neg)
    return c / (len(pos) * len(neg))


pre = [r for r in rows if r["day"] < 90]
post = [r for r in rows if r["day"] >= 90]
for s in ["legacy", "compact", "large"]:
    print(s)
    for name, rs in [("pre", pre), ("post", post)]:
        t = best_t(rs, s)
        print(f"  {name}: auc={auc(rs,s):.3f} loss@0.5={loss(rs,s,0.5):.3f} in-sample best t={t:.4f} loss={loss(rs,s,t):.3f}")
    # pre-trained threshold applied to post
    t = best_t(pre, s)
    print(f"  pre-threshold {t:.4f} on post: {loss(post,s,t):.3f}")
    # temporal: fit on days 90-109, test 110-119
    a = [r for r in post if r["day"] < 110]
    b = [r for r in post if r["day"] >= 110]
    t = best_t(a, s)
    print(f"  temporal fit 90-109 t={t:.4f} -> test 110-119 loss={loss(b,s,t):.3f} (n={len(b)})")
    # repeated 5-fold CV on post
    rng = random.Random(0)
    outs = []
    for rep in range(20):
        idx = list(range(len(post)))
        rng.shuffle(idx)
        tot = 0
        for k in range(5):
            te = [post[i] for i in idx[k::5]]
            tr = [post[i] for j, i in enumerate(idx) if j % 5 != k]
            t = best_t(tr, s)
            tot += loss(te, s, t) * len(te)
        outs.append(tot / len(post))
    outs.sort()
    print(f"  post 5fold CV x20: mean={sum(outs)/len(outs):.3f} min={outs[0]:.3f} max={outs[-1]:.3f}")
print("constant review-all post", sum(1 - r["fraud"] for r in post) / len(post))
print("constant allow-all post", 8 * sum(r["fraud"] for r in post) / len(post))
