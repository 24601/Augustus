"""Checks: fit, JSON round-trip, fresh-process serving, invalid inputs,
temporal holdout, and bagged-vs-plain threshold comparison."""
import json, random, subprocess, sys
import solution

rows = json.load(open("rows.json"))
config = json.load(open("config.json"))
FN, FP = config["fn_cost"], config["fp_cost"]

art = solution.fit(rows, config)
json.dump(art, open("artifact.json", "w"), indent=2)
print("artifact:", json.dumps(art))
assert art["stock"] in list(config["stocks"]) + ["constant"]
if art["stock"] != "constant":
    assert config["stocks"][art["stock"]]["latency_ms"] <= config["max_latency_ms"]


def serve_row(r, stock):
    return {"request_id": r["request_id"], "scores": {stock: r["scores"][stock]}} if stock != "constant" else {"request_id": r["request_id"], "scores": {}}


def mean_loss(a, rs):
    L = 0
    for r in rs:
        d = solution.decide(a, serve_row(r, a["stock"]))
        assert d in ("allow", "review")
        L += FN if (r["fraud"] and d == "allow") else FP if (not r["fraud"] and d == "review") else 0
    return L / len(rs)


post = [r for r in rows if r["day"] >= 90]
print("in-sample post loss:", round(mean_loss(art, post), 4))

# Temporal holdout: fit on everything before day 110, test on days 110-119.
for cut in (105, 110):
    a = solution.fit([r for r in rows if r["day"] < cut], config)
    te = [r for r in rows if r["day"] >= cut]
    print(f"temporal fit<{cut}: stock={a['stock']} t={a.get('threshold', 0):.4f} test n={len(te)} loss={mean_loss(a, te):.4f}")

# Repeated random holdout within post (bagged vs plain empirical threshold).
rng = random.Random(1)
bag, plain = [], []
pre = [r for r in rows if r["day"] < 90]
for rep in range(30):
    p = post[:]
    rng.shuffle(p)
    tr, te = p[:200], p[200:]
    a = solution.fit(pre + tr, config)
    bag.append(mean_loss(a, te))
    pairs = solution._pairs(tr, "compact")
    t = solution._best_threshold(pairs, FN, FP)
    plain.append(mean_loss({"stock": "compact", "threshold": t}, te))
print(f"30x 200/100 post holdout: bagged mean={sum(bag)/30:.4f} max={max(bag):.4f} | plain mean={sum(plain)/30:.4f} max={max(plain):.4f}")

# Legacy >= 0.5 baseline on post
print("legacy>=0.5 on post:", round(mean_loss({"stock": "legacy", "threshold": 0.5}, post), 4))

# Invalid inputs must review.
bad = [None, "0.1", float("nan"), float("inf"), -0.1, 1.5, True, False, [0.1], {}]
for b in bad:
    assert solution.decide(art, {"request_id": "x", "scores": {art["stock"]: b}}) == "review", b
assert solution.decide(art, {"request_id": "x", "scores": {}}) == "review"
assert solution.decide(art, {"request_id": "x"}) == "review"
assert solution.decide(art, {"request_id": "x", "scores": None}) == "review"
assert solution.decide(art, {"request_id": "x", "scores": "junk"}) == "review"
assert solution.decide({}, {"request_id": "x", "scores": {"compact": 0.01}}) == "review"
assert solution.decide({"stock": "compact", "threshold": "x"}, {"scores": {"compact": 0.01}}) == "review"
print("invalid-input checks passed")

# Fresh process with only solution.py + reloaded JSON artifact.
code = ("import json,solution;a=json.load(open('artifact.json'));"
        "print(solution.decide(a,{'request_id':'r1','scores':{'compact':0.2}}),"
        "solution.decide(a,{'request_id':'r2','scores':{'compact':0.01}}),"
        "solution.decide(a,{'request_id':'r3','scores':{}}))")
out = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
print("fresh process:", out.stdout.strip(), out.stderr.strip())
assert out.stdout.split() == ["review", "allow", "review"]
print("ALL CHECKS PASSED")
