import json, math
from collections import Counter

rows = json.load(open("rows.json"))
print(type(rows), len(rows))
print(rows[0])
print(Counter(type(r.get("scores")).__name__ for r in rows))
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
keys = Counter(k for r in rows for k in r)
print(keys)


def valid(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 <= v <= 1


for seg, sel in [("pre", lambda r: r["day"] < 90), ("post", lambda r: r["day"] >= 90)]:
    rs = [r for r in rows if sel(r)]
    print(seg, len(rs), "fraud rate", sum(r["fraud"] for r in rs) / len(rs))
    for s in ["legacy", "compact", "large"]:
        vals = [r["scores"].get(s) for r in rs]
        inv = sum(not valid(v) for v in vals)
        print("  ", s, "invalid", inv, Counter(type(v).__name__ for v in vals if not valid(v)))
