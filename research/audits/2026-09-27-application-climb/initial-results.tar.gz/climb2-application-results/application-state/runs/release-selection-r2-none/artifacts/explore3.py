import json

rows = json.load(open("rows.json"))
post = [r for r in rows if r["day"] >= 90]
pos = sorted(r["scores"]["compact"] for r in post if r["fraud"])
neg = sorted(r["scores"]["compact"] for r in post if not r["fraud"])
print("n pos", len(pos), "n neg", len(neg))
print("fraud compact scores:", [round(x, 4) for x in pos])
print("legit top 30:", [round(x, 4) for x in neg[-30:]])


def loss(rs, t):
    return sum(8 if r["fraud"] and r["scores"]["compact"] < t else (1 if not r["fraud"] and r["scores"]["compact"] >= t else 0) for r in rs) / len(rs)


for t in [0.03, 0.04, 0.05, 0.055, 0.06, 0.065, 0.07, 0.075, 0.08, 0.09, 0.1, 0.12, 0.15]:
    print(t, round(loss(post, t), 4), [round(loss([r for r in post if lo <= r["day"] < lo + 10], t), 3) for lo in (90, 100, 110)])
