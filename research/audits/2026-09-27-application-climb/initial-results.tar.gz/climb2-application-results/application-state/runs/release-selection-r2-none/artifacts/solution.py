"""Fraud-review decision policy for the post-day-90 checkout funnel.

fit(rows, config) -> JSON-serializable artifact
decide(artifact, row) -> "allow" | "review"

Policy: register one frozen stock that fits the latency allowance, and review
when its score is >= a threshold learned on current-funnel (day >= 90) outcomes
only. Any missing/invalid score, or any malformed artifact, sends the order to
review.
"""

import math
import random

CHANGE_DAY = 90  # checkout funnel changed on day 90 (operations note)
N_BOOT = 200
SEED = 20260926


def _valid(v):
    return (isinstance(v, (int, float)) and not isinstance(v, bool)
            and math.isfinite(v) and 0.0 <= v <= 1.0)


def _loss(pairs, t, fn, fp):
    """Total cost of 'review iff score >= t' over (score, fraud) pairs."""
    total = 0.0
    for s, y in pairs:
        if s >= t:
            if not y:
                total += fp
        elif y:
            total += fn
    return total


def _best_threshold(pairs, fn, fp):
    """Empirical-loss minimizing threshold; ties broken toward the midpoint
    of the gap below the chosen score (lower = safer given fn > fp)."""
    scores = sorted({s for s, _ in pairs})
    # Candidate cut points: midpoints between consecutive distinct scores,
    # plus below-min (review all) and above-max (allow all).
    cands = [0.0] + [(a + b) / 2 for a, b in zip(scores, scores[1:])] + [1.0 + 1e-9]
    best_t, best_l = None, None
    for t in cands:
        l = _loss(pairs, t, fn, fp)
        if best_l is None or l < best_l:
            best_t, best_l = t, l
    return best_t


def _bagged_threshold(pairs, fn, fp, rng):
    """Median of bootstrap-optimal thresholds: stabilises the cut against
    the few samples that define the empirical optimum."""
    ts = []
    n = len(pairs)
    for _ in range(N_BOOT):
        sample = [pairs[rng.randrange(n)] for _ in range(n)]
        ts.append(_best_threshold(sample, fn, fp))
    ts.sort()
    return ts[len(ts) // 2]


def _pairs(rows, stock):
    out = []
    for r in rows:
        s = (r.get("scores") or {}).get(stock)
        if _valid(s):
            out.append((float(s), 1 if r.get("fraud") else 0))
    return out


def _cv_loss(pairs, fn, fp, folds=5, seed=SEED):
    """Mean per-request loss of the full fitting procedure under k-fold CV."""
    rng = random.Random(seed)
    idx = list(range(len(pairs)))
    rng.shuffle(idx)
    total = 0.0
    for k in range(folds):
        te = [pairs[i] for j, i in enumerate(idx) if j % folds == k]
        tr = [pairs[i] for j, i in enumerate(idx) if j % folds != k]
        t = _bagged_threshold(tr, fn, fp, random.Random(seed + k))
        total += _loss(te, t, fn, fp)
    return total / len(pairs)


def fit(rows, config):
    fn = float(config.get("fn_cost", 8))
    fp = float(config.get("fp_cost", 1))
    max_lat = float(config.get("max_latency_ms", 15))
    current = [r for r in rows if isinstance(r.get("day"), (int, float))
               and r["day"] >= CHANGE_DAY]

    n = len(current)
    n_fraud = sum(1 for r in current if r.get("fraud"))
    # Constant fallback: cheaper of review-all / allow-all on current funnel.
    review_all = (n - n_fraud) * fp / n if n else float("inf")
    allow_all = n_fraud * fn / n if n else float("inf")
    best = {
        "stock": "constant",
        "action": "review" if review_all <= allow_all else "allow",
        "cv_loss": min(review_all, allow_all),
    }

    candidates = {}
    for name, spec in sorted(config.get("stocks", {}).items()):
        if float(spec.get("latency_ms", float("inf"))) > max_lat:
            continue
        pairs = _pairs(current, name)
        if len(pairs) < 50 or not any(y for _, y in pairs):
            continue
        cv = _cv_loss(pairs, fn, fp)
        candidates[name] = cv
        if cv < best["cv_loss"]:
            t = _bagged_threshold(pairs, fn, fp, random.Random(SEED))
            best = {
                "stock": name,
                "threshold": t,
                "cv_loss": cv,
                "train_loss": _loss(pairs, t, fn, fp) / len(pairs),
            }

    best["n_train"] = n
    best["change_day"] = CHANGE_DAY
    best["candidate_cv_loss"] = candidates
    return best


def decide(artifact, row):
    try:
        stock = artifact["stock"]
        if stock == "constant":
            return "allow" if artifact.get("action") == "allow" else "review"
        t = artifact["threshold"]
        if isinstance(t, bool) or not isinstance(t, (int, float)) or not math.isfinite(t):
            return "review"
        scores = row.get("scores")
        if not isinstance(scores, dict):
            return "review"
        s = scores.get(stock)
        if not _valid(s):
            return "review"
        return "review" if s >= t else "allow"
    except Exception:
        return "review"
