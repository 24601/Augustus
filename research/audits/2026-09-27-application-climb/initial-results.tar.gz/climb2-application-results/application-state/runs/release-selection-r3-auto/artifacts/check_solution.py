"""End-to-end checks: fit, JSON round-trip, fresh-process decide, holdout loss, invalid-score handling."""
import json, subprocess, sys, time
import solution

rows = json.load(open("rows.json")); config = json.load(open("config.json"))
t0 = time.time()
art = solution.fit(rows, config)
print("fit seconds:", round(time.time() - t0, 2))
print(json.dumps(art, indent=1))
json.dump(art, open("artifact.json", "w"), indent=1)

post = [r for r in rows if r["day"] >= 90]
def serve_row(r, stock):
    return {"request_id": r["request_id"], "scores": {stock: r["scores"][stock]} if stock in r["scores"] else {}}
def mean_loss(a, sub):
    c = 0
    for r in sub:
        d = solution.decide(a, serve_row(r, a["stock"]))
        c += 8 if (r["fraud"] and d == "allow") else (1 if (not r["fraud"] and d == "review") else 0)
    return c / len(sub)

# Whole-procedure temporal holdout: fit on days <110, evaluate on days 110-119.
a_tr = solution.fit([r for r in rows if r["day"] < 110], config)
te = [r for r in post if r["day"] >= 110]
print(f"holdout (fit <110, test 110-119): stock={a_tr['stock']} t={a_tr['threshold']:.4f} loss={mean_loss(a_tr, te):.4f}")
# And the reverse direction within post period, as a second look.
a_late = solution.fit([r for r in rows if r["day"] < 90 or r["day"] >= 100], config)
early = [r for r in post if r["day"] < 100]
print(f"holdout (fit 100-119, test 90-99): t={a_late['threshold']:.4f} loss={mean_loss(a_late, early):.4f}")
print(f"final artifact, in-sample post loss: {mean_loss(art, post):.4f}")

# Fresh-process reload with solution.py only.
code = ("import json,solution;a=json.load(open('artifact.json'));rs=json.load(open('rows.json'));"
        "print(sum(solution.decide(a,{'request_id':r['request_id'],'scores':{a['stock']:r['scores'][a['stock']]}})=='review' for r in rs))")
open("_fresh.py", "w").write(code)
fresh = subprocess.run([sys.executable, "_fresh.py"], capture_output=True, text=True)
inproc = sum(solution.decide(art, serve_row(r, art["stock"])) == "review" for r in rows)
print("fresh-process reviews:", fresh.stdout.strip(), fresh.stderr.strip(), "in-process:", inproc)
assert fresh.stdout.strip() == str(inproc)

# Invalid / missing scores must be reviewed.
s = art["stock"]
bad = [{}, {"request_id": "x"}, {"request_id": "x", "scores": None}, {"request_id": "x", "scores": {}},
       {"request_id": "x", "scores": {s: None}}, {"request_id": "x", "scores": {s: True}},
       {"request_id": "x", "scores": {s: False}}, {"request_id": "x", "scores": {s: "0.01"}},
       {"request_id": "x", "scores": {s: float("nan")}}, {"request_id": "x", "scores": {s: -0.1}},
       {"request_id": "x", "scores": {s: 1.5}}, {"request_id": "x", "scores": {s: float("inf")}},
       {"request_id": "x", "scores": {"large": 0.0}}]
for b in bad:
    assert solution.decide(art, b) == "review", b
assert solution.decide(art, {"request_id": "x", "scores": {s: 0.0}}) == "allow"
assert solution.decide(art, {"request_id": "x", "scores": {s: 1}}) == "review"
assert config["stocks"][s]["latency_ms"] <= config["max_latency_ms"]
print("invalid-input and latency checks passed")
