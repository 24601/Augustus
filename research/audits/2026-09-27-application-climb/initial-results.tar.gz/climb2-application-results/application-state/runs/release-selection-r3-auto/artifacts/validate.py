"""Validate threshold policies on the compact stock using post-change (day>=90) rows only."""
import json, math, random
rows = json.load(open("rows.json"))
post = [r for r in rows if r["day"] >= 90]
S = "compact"

def loss(t, sub):
    c = 0
    for r in sub:
        v = r["scores"][S]; y = r["fraud"]
        review = v >= t
        c += 8 if (y and not review) else (1 if (not y and review) else 0)
    return c / len(sub)

def fit_t(sub):
    vals = sorted(set(r["scores"][S] for r in sub))
    cands = [0.0] + [(a + b) / 2 for a, b in zip(vals, vals[1:])] + [1.01]
    best = min(loss(t, sub) for t in cands)
    # among optimal thresholds, take the lowest (conservative toward review)
    return min(t for t in cands if loss(t, sub) <= best + 1e-12)

# fraud score distribution
fr = sorted(r["scores"][S] for r in post if r["fraud"])
lg = sorted(r["scores"][S] for r in post if not r["fraud"])
print("fraud compact scores min/quantiles:", fr[:6], "... n=", len(fr))
print("legit compact score quantiles:", [round(lg[int(q * (len(lg) - 1))], 4) for q in (0, .1, .25, .5, .75, .9, 1)])

# per-10-day stability
for d0 in range(90, 120, 10):
    sub = [r for r in post if d0 <= r["day"] < d0 + 10]
    print(f"days {d0}-{d0+9}: n={len(sub)} fraud={sum(r['fraud'] for r in sub)} loss@0.07={loss(0.07, sub):.3f}")

# temporal holdout: fit on 90-109, test on 110-119
tr = [r for r in post if r["day"] < 110]; te = [r for r in post if r["day"] >= 110]
t = fit_t(tr)
print(f"temporal holdout: t={t:.4f} train={loss(t, tr):.4f} test={loss(t, te):.4f} n_test={len(te)}")

# repeated 5-fold CV
rng = random.Random(0); outs = []
for rep in range(40):
    idx = list(range(len(post))); rng.shuffle(idx)
    for k in range(5):
        te_i = set(idx[k::5])
        tr_ = [post[i] for i in idx if i not in te_i]; te_ = [post[i] for i in te_i]
        outs.append(loss(fit_t(tr_), te_))
outs.sort()
print(f"5-fold CV x40: mean={sum(outs)/len(outs):.4f} p90={outs[int(.9*len(outs))]:.4f} max={outs[-1]:.4f}")

# bootstrap of chosen full-post threshold with a safety margin
tf = fit_t(post)
print("full-post fitted t:", tf)
for t in (tf, tf * 0.75, tf * 0.5, 0.03, 0.02):
    bs = []
    for _ in range(2000):
        s = [post[rng.randrange(len(post))] for _ in post]
        bs.append(loss(t, s))
    bs.sort()
    print(f"t={t:.4f} in-sample={loss(t, post):.4f} boot p95={bs[int(.95*len(bs))]:.4f}")

# other baselines on post
print("legacy>=0.5 on post:", sum(8 if (r['fraud'] and r['scores']['legacy'] < .5) else (1 if (not r['fraud'] and r['scores']['legacy'] >= .5) else 0) for r in post) / len(post))
print("constant review:", sum(1 - r["fraud"] for r in post) / len(post), "constant allow:", 8 * sum(r["fraud"] for r in post) / len(post))
