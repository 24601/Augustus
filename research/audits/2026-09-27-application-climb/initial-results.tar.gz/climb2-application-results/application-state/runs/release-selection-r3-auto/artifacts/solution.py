"""Fraud-review decision: one latency-eligible stock + a cost-optimal review threshold.

fit() uses only post-funnel-change rows (day >= 90, per operations note), drops
stocks over the latency allowance, and for each remaining stock picks the review
threshold that minimises bootstrap-averaged business loss (smoother and less
brittle than the single in-sample optimum). The stock with the lowest
cross-validated loss is registered; if none meets max_mean_loss the artifact
falls back to `constant` review-everything. decide() reviews any request whose
registered score is missing or invalid.
"""
import math
import random

CHANGE_DAY = 90
N_BOOT = 200
SEED = 20260926


def _valid(v):
    return (not isinstance(v, bool) and isinstance(v, (int, float))
            and math.isfinite(v) and 0.0 <= v <= 1.0)


def _candidates(scores):
    vals = sorted(set(scores))
    return [0.0] + [(a + b) / 2 for a, b in zip(vals, vals[1:])] + [1.0 + 1e-9]


def _loss_curve(pairs, cands, fn_cost, fp_cost):
    """Mean loss for 'review if score >= t' at each sorted candidate t."""
    pairs = sorted(pairs)
    n = len(pairs)
    total_neg = sum(1 for _, y in pairs if not y)
    out, i, fn, tn = [], 0, 0, 0
    for t in cands:
        while i < n and pairs[i][0] < t:
            if pairs[i][1]:
                fn += 1
            else:
                tn += 1
            i += 1
        out.append((fn_cost * fn + fp_cost * (total_neg - tn)) / n)
    return out


def _fit_threshold(pairs, fn_cost, fp_cost, rng):
    cands = _candidates([s for s, _ in pairs])
    acc = [0.0] * len(cands)
    for _ in range(N_BOOT):
        sample = [pairs[rng.randrange(len(pairs))] for _ in pairs]
        for k, v in enumerate(_loss_curve(sample, cands, fn_cost, fp_cost)):
            acc[k] += v
    best = min(acc)
    # Ties go to the lowest threshold: missed fraud is the expensive error.
    return cands[acc.index(best)]


def _loss_at(pairs, t, fn_cost, fp_cost):
    c = sum(fn_cost if (y and s < t) else (fp_cost if (not y and s >= t) else 0) for s, y in pairs)
    return c / len(pairs)


def _cv_loss(pairs, fn_cost, fp_cost, rng, folds=5):
    idx = list(range(len(pairs)))
    rng.shuffle(idx)
    total = 0.0
    for k in range(folds):
        test = set(idx[k::folds])
        tr = [pairs[i] for i in idx if i not in test]
        te = [pairs[i] for i in test]
        t = _fit_threshold(tr, fn_cost, fp_cost, rng)
        total += _loss_at(te, t, fn_cost, fp_cost) * len(te)
    return total / len(pairs)


def fit(rows, config):
    fn_cost = config.get("fn_cost", 8)
    fp_cost = config.get("fp_cost", 1)
    recent = [r for r in rows if r.get("day", 0) >= CHANGE_DAY] or list(rows)
    constant_loss = fp_cost * sum(1 for r in recent if not r["fraud"]) / max(len(recent), 1)
    best = {"stock": "constant", "threshold": None, "cv_loss": constant_loss}
    report = {}
    for name, meta in sorted(config.get("stocks", {}).items()):
        if meta.get("latency_ms", float("inf")) > config.get("max_latency_ms", 15):
            report[name] = "excluded: latency"
            continue
        # Invalid training scores count as reviewed, as they would be in serving.
        pairs = [(r["scores"][name] if _valid(r["scores"].get(name)) else 2.0, int(bool(r["fraud"])))
                 for r in recent]
        rng = random.Random(SEED)
        cv = _cv_loss(pairs, fn_cost, fp_cost, rng)
        t = _fit_threshold(pairs, fn_cost, fp_cost, random.Random(SEED))
        report[name] = {"cv_loss": round(cv, 4), "threshold": t,
                        "train_loss": round(_loss_at(pairs, t, fn_cost, fp_cost), 4)}
        if cv < best["cv_loss"]:
            best = {"stock": name, "threshold": t, "cv_loss": cv}
    if best["stock"] != "constant" and best["cv_loss"] > config.get("max_mean_loss", float("inf")):
        best = {"stock": "constant", "threshold": None, "cv_loss": constant_loss}
    return {
        "stock": best["stock"],
        "threshold": best["threshold"],
        "rule": "review if score >= threshold or score invalid",
        "fit_rows": len(recent),
        "from_day": CHANGE_DAY,
        "cv_loss": round(best["cv_loss"], 4),
        "candidates": report,
    }


def decide(artifact, row):
    stock = artifact.get("stock")
    t = artifact.get("threshold")
    if stock == "constant" or not _valid(t):
        return "review"
    scores = row.get("scores") if isinstance(row, dict) else None
    v = scores.get(stock) if isinstance(scores, dict) else None
    if not _valid(v):
        return "review"
    return "review" if v >= t else "allow"
