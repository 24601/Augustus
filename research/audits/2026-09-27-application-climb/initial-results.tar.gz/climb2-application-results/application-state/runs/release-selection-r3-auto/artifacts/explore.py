import json, math
rows = json.load(open("rows.json"))
print(len(rows), rows[0])
print(set(tuple(sorted(r.keys())) for r in rows))
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
for name, sub in [("pre", [r for r in rows if r["day"] < 90]), ("post", [r for r in rows if r["day"] >= 90])]:
    print(name, len(sub), "fraud rate", sum(r["fraud"] for r in sub) / len(sub))
    for s in ["legacy", "compact", "large"]:
        bad = 0; vals = []
        for r in sub:
            v = r["scores"].get(s)
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not 0 <= v <= 1:
                bad += 1
            else:
                vals.append((v, r["fraud"]))
        # best threshold loss
        vals.sort()
        P = sum(y for _, y in vals); N = len(vals) - P
        best = (8 * P + 0, None)  # threshold at 0 => review all -> cost N... compute properly
        # review if score >= t: allow below t
        fn = 0; tn = 0
        best = (N * 1, 0.0)
        for i, (v, y) in enumerate(vals):
            if y: fn += 1
            else: tn += 1
            cost = 8 * fn + (N - tn)
            if i + 1 < len(vals) and vals[i + 1][0] == v: continue
            if cost < best[0]: best = (cost, v)
        leg05 = sum(8 if (y and v < 0.5) else (1 if (not y and v >= 0.5) else 0) for v, y in vals)
        print(f"  {s}: invalid={bad} best_insample_loss={(best[0] + bad * 0) / len(sub):.4f} allow<=:{best[1]} loss@0.5={leg05/len(sub):.4f}")
