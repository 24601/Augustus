"""Fraud-review decision: one latency-eligible stock + a cost-optimal threshold.

fit() only learns from orders on the current checkout funnel (day >= 90),
because the day-90 funnel change broke the relationship between scores and
fraud for pre-change traffic. Among stocks within the latency allowance it
estimates each candidate's out-of-sample loss by repeated stratified K-fold
cross-validation, and registers the best one. Serving is a single comparison;
any missing/invalid score goes to review.
"""
import math
import random

FUNNEL_CHANGE_DAY = 90
CV_FOLDS = 5
CV_REPEATS = 20
SEED = 20260926


def _valid(v):
    return (isinstance(v, (int, float)) and not isinstance(v, bool)
            and math.isfinite(v) and 0.0 <= v <= 1.0)


def _fit_threshold(pairs, fn_cost, fp_cost):
    """pairs: [(score, fraud)] with valid scores. Review iff score >= t.

    Scans every cut between distinct scores, returns the midpoint of the
    widest-cost-minimizing gap (midpoints keep a margin on both sides).
    """
    pairs = sorted(pairs)
    n_fraud = sum(y for _, y in pairs)
    # threshold below everything: review all
    best_loss = fp_cost * (len(pairs) - n_fraud)
    best_t = 0.0
    allowed_fraud = allowed_legit = 0
    i = 0
    while i < len(pairs):
        s = pairs[i][0]
        while i < len(pairs) and pairs[i][0] == s:
            if pairs[i][1]:
                allowed_fraud += 1
            else:
                allowed_legit += 1
            i += 1
        loss = fn_cost * allowed_fraud + fp_cost * (len(pairs) - n_fraud - allowed_legit)
        nxt = pairs[i][0] if i < len(pairs) else 1.0 + 1e-9
        if loss < best_loss:
            best_loss, best_t = loss, (s + nxt) / 2.0
    return best_t


def _loss(pairs, t, fn_cost, fp_cost):
    total = 0
    for s, y in pairs:
        review = s is None or s >= t
        if y and not review:
            total += fn_cost
        elif not y and review:
            total += fp_cost
    return total / len(pairs) if pairs else float("inf")


def _cv_loss(pairs, fn_cost, fp_cost):
    rng = random.Random(SEED)
    pos = [p for p in pairs if p[1]]
    neg = [p for p in pairs if not p[1]]
    losses = []
    for _ in range(CV_REPEATS):
        rng.shuffle(pos)
        rng.shuffle(neg)
        folds = [pos[k::CV_FOLDS] + neg[k::CV_FOLDS] for k in range(CV_FOLDS)]
        total = 0.0
        for k in range(CV_FOLDS):
            train = [p for j in range(CV_FOLDS) if j != k for p in folds[j]]
            t = _fit_threshold([p for p in train if p[0] is not None], fn_cost, fp_cost)
            total += _loss(folds[k], t, fn_cost, fp_cost) * len(folds[k])
        losses.append(total / len(pairs))
    return sum(losses) / len(losses)


def fit(rows, config):
    fn_cost = config.get("fn_cost", 8)
    fp_cost = config.get("fp_cost", 1)
    max_latency = config.get("max_latency_ms", 15)
    current = [r for r in rows if r.get("day", 0) >= FUNNEL_CHANGE_DAY] or list(rows)
    n = len(current)
    n_fraud = sum(1 for r in current if r["fraud"])

    # constant baseline: always review (cheaper than always allow when
    # fn_cost * fraud_rate > fp_cost * legit_rate, true here)
    best = {"stock": "constant", "threshold": None,
            "cv_loss": fp_cost * (n - n_fraud) / n if n else None}
    candidates = {}
    for name, spec in sorted(config.get("stocks", {}).items()):
        if spec.get("latency_ms", float("inf")) > max_latency:
            continue
        pairs = []
        for r in current:
            v = r.get("scores", {}).get(name)
            pairs.append((v if _valid(v) else None, 1 if r["fraud"] else 0))
        cv = _cv_loss(pairs, fn_cost, fp_cost)
        t = _fit_threshold([p for p in pairs if p[0] is not None], fn_cost, fp_cost)
        candidates[name] = {"cv_loss": round(cv, 4),
                            "train_loss": round(_loss(pairs, t, fn_cost, fp_cost), 4),
                            "threshold": t}
        if cv < best["cv_loss"]:
            best = {"stock": name, "threshold": t, "cv_loss": cv}

    return {
        "stock": best["stock"],
        "threshold": best["threshold"],
        "rule": "review if score missing/invalid or score >= threshold",
        "fit_rows": n,
        "fit_fraud": n_fraud,
        "fit_from_day": FUNNEL_CHANGE_DAY,
        "cv_loss": round(best["cv_loss"], 4),
        "candidates": candidates,
    }


def decide(artifact, row):
    try:
        stock = artifact["stock"]
        if stock == "constant":
            return "review"
        t = artifact["threshold"]
        v = row["scores"][stock]
        if not _valid(v) or isinstance(t, bool) or not isinstance(t, (int, float)) \
                or not math.isfinite(t):
            return "review"
        return "review" if v >= t else "allow"
    except Exception:
        return "review"
