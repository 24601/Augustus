import json, math
rows = json.load(open("rows.json"))
print(len(rows), rows[0])
keys = set()
for r in rows: keys |= set(r.keys())
print(keys)
days = [r["day"] for r in rows]
print("day range", min(days), max(days))
post = [r for r in rows if r["day"] >= 90]
pre = [r for r in rows if r["day"] < 90]
print("pre", len(pre), "post", len(post))
for name, sub in (("pre", pre), ("post", post)):
    print(name, "fraud rate", sum(r["fraud"] for r in sub) / len(sub))
# score validity
def valid(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and 0 <= v <= 1
for s in ("legacy", "compact", "large"):
    bad = [r["scores"].get(s) for r in rows if not valid(r["scores"].get(s))]
    print(s, "invalid", len(bad), bad[:10])
def loss(sub, s, t):
    L = 0
    for r in sub:
        v = r["scores"].get(s)
        rev = (not valid(v)) or v >= t
        if r["fraud"] and not rev: L += 8
        if not r["fraud"] and rev: L += 1
    return L / len(sub)
print("legacy>=0.5 pre", loss(pre, "legacy", 0.5), "post", loss(post, "legacy", 0.5))
print("all review post", sum(1 - r["fraud"] for r in post) / len(post))
for s in ("legacy", "compact", "large"):
    for name, sub in (("pre", pre), ("post", post)):
        vals = sorted(set(r["scores"][s] for r in sub if valid(r["scores"].get(s))))
        best = min((loss(sub, s, t), t) for t in vals + [1.01])
        print(s, name, "oracle best", best)
