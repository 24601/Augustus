import json
from solution import decide
art = json.load(open("artifact.json"))
rows = json.load(open("rows.json"))
s = art["stock"]
n = L = 0
for r in rows:
    if r["day"] < 90:
        continue
    d = decide(art, {"request_id": r["request_id"], "scores": {s: r["scores"][s]}})
    assert d in ("allow", "review")
    L += 8 if (r["fraud"] and d == "allow") else (1 if (not r["fraud"] and d == "review") else 0)
    n += 1
print("fresh process OK, post loss", round(L / n, 4))
