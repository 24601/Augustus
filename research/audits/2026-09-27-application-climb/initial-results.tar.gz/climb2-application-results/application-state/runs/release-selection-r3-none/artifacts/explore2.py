import json, random
rows = json.load(open("rows.json"))
post = sorted([r for r in rows if r["day"] >= 90], key=lambda r: r["day"])
print("post days", min(r["day"] for r in post), max(r["day"] for r in post))
# compact score by label
f = sorted(r["scores"]["compact"] for r in post if r["fraud"])
g = sorted(r["scores"]["compact"] for r in post if not r["fraud"])
print("fraud n", len(f), "compact fraud min/quantiles", f[0], f[len(f)//10], f[len(f)//2])
print("legit n", len(g), "compact legit quantiles", g[len(g)//2], g[int(len(g)*.9)], g[int(len(g)*.95)], g[-1])
# bins
for lo in [i/20 for i in range(20)]:
    b = [r for r in post if lo <= r["scores"]["compact"] < lo + 0.05]
    if b: print(f"{lo:.2f} n={len(b)} fraud={sum(r['fraud'] for r in b)}")
# weekly fraud rate / separation in post
for d0 in range(90, 120, 10):
    b = [r for r in post if d0 <= r["day"] < d0 + 10]
    print(d0, len(b), sum(r["fraud"] for r in b))
