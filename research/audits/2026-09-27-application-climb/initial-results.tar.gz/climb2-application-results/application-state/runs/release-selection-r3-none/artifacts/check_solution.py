"""Local checks: fit, JSON round-trip, fresh-process decide, holdouts, bad inputs."""
import json, subprocess, sys, random
import solution

rows = json.load(open("rows.json"))
config = json.load(open("config.json"))
C = (config["fn_cost"], config["fp_cost"])

def mean_loss(art, sub):
    L = 0
    for r in sub:
        d = solution.decide(art, {"request_id": r["request_id"],
                                  "scores": {art["stock"]: r["scores"].get(art["stock"])}} if art["stock"] != "constant" else {"request_id": r["request_id"], "scores": {}})
        if r["fraud"] and d == "allow": L += C[0]
        if not r["fraud"] and d == "review": L += C[1]
    return L / len(sub)

art = solution.fit(rows, config)
print(json.dumps(art, indent=1))
assert art["stock"] in list(config["stocks"]) + ["constant"]
assert config["stocks"].get(art["stock"], {"latency_ms": 0})["latency_ms"] <= config["max_latency_ms"]
json.dump(art, open("artifact.json", "w"), indent=1)

post = [r for r in rows if r["day"] >= 90]
print("in-sample post loss", mean_loss(art, post))

# Forward-in-time holdout: fit on days < 110 (post rows 90..109), test on 110..119
tr = [r for r in rows if r["day"] < 110]
te = [r for r in rows if r["day"] >= 110]
a2 = solution.fit(tr, config)
print("temporal holdout: stock", a2["stock"], "t", a2["threshold"], "test loss", round(mean_loss(a2, te), 4), "n", len(te))
# Also fit on 90..99 only, test 100..119
a3 = solution.fit([r for r in rows if r["day"] < 100], config)
print("fit 90-99 -> test 100-119 loss", round(mean_loss(a3, [r for r in rows if r["day"] >= 100]), 4))

# Repeated random 50/50 splits of post rows
rng = random.Random(1)
ls = []
for _ in range(100):
    p = post[:]; rng.shuffle(p)
    a = solution.fit(p[:150], config)
    ls.append(mean_loss(a, p[150:]))
ls.sort()
print("50/50 split holdout loss: mean %.4f p5 %.4f p95 %.4f max %.4f" % (sum(ls)/len(ls), ls[5], ls[94], ls[-1]))

# Bootstrap CI of the full-fit rule's loss on post rows (sampling noise only)
bs = []
for _ in range(2000):
    s = [post[rng.randrange(len(post))] for _ in post]
    bs.append(mean_loss(art, s))
bs.sort()
print("bootstrap in-sample loss 95%% CI: %.4f-%.4f" % (bs[50], bs[1949]))

# Baselines on post rows
legacy_old = {"stock": "legacy", "threshold": 0.5}
print("old rule legacy>=0.5 post loss", mean_loss(legacy_old, post))
print("always review post loss", mean_loss({"stock": "constant"}, post))

# Invalid inputs must review
bad = [None, "0.1", True, False, float("nan"), float("inf"), -0.1, 1.5, [0.1], {}]
for b in bad:
    assert solution.decide(art, {"request_id": "x", "scores": {art["stock"]: b}}) == "review", b
assert solution.decide(art, {"request_id": "x", "scores": {}}) == "review"
assert solution.decide(art, {"request_id": "x"}) == "review"
assert solution.decide(art, {"request_id": "x", "scores": {"large": 0.0}}) == "review"
assert solution.decide({"stock": art["stock"], "threshold": None}, {"scores": {art["stock"]: 0.0}}) == "review"
print("invalid-input checks passed")

# Fresh process, JSON reload, solution.py alone
out = subprocess.run([sys.executable, "fresh_decide.py"], capture_output=True, text=True)
print(out.stdout.strip(), out.stderr.strip())
