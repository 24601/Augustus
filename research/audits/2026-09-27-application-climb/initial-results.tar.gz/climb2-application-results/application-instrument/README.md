# Application experiment instrument — authorized initial block

Separate from the stopped first climb. Its original runner, evidence and ledger
remain untouched at $1.8080588. This experiment has its own $10 reported-agent-cost
ceiling, concurrency one, and 18-attempt limit. Failed/incomplete/unknown-cost
attempts stop continuation, are retained, and are not silently retried. The
in-flight-run overshoot caveat still applies. Combined nominal spend at the new
ceiling is $11.8080588, below the original $15 allowance.

Only release 0.8.1 is supported; the complete skill file-hash map must match
`26b125cf8cd856d9146c705af86641a532b2b9d486841026568382b6f6ec68d4`.
No challenger registration exists. Agent remains `claude-opus-5-5`, medium,
Claude CLI 2.1.282, at most 20 turns and 180 seconds. The existing VibeProxy
isolation implementation is unchanged. Preparation and tests do not start the
live proxy or invoke inference; no normal service/settings changes are made.

## Frozen input contract

Frozen public archive SHA-256:
`523800f786778159a0188ba5486c40898d61e54c7f8023577371fb051b5412c1`.
Parent private freeze manifest SHA-256 (not downloaded or read):
`b1b85d9bad7eea749ccb824661483a35980967883455c908cbcf8ea3f3b7a8da`.
The parent authorized the initial 18 runs after the final offline checks passed.
Exactly eight public files are accepted:

```text
tasks/{selection,policy}/{prompt.md,operations.md,rows.json,config.json}
```

Only regular files/directories are accepted; no links, traversal or duplicate
paths. Limits are 2 MiB per file and 10 MiB total. Do not include hidden future
data or graders. Parent owns grading of `fit(rows, config) -> JSON artifact` and
`decide(artifact, row) -> action string`; the runner does not supply model grades.

Each fresh agent fixture receives:

- Original `prompt.md` as immutable `TASK.md` and in the effective prompt.
- `operations.md`, `rows.json` and `config.json` at the **fixture root**, retaining
  their original names and exact bytes. This supersedes the preliminary inputs/
  convention, as requested by the parent with the frozen archive.
- Other paths in the fixture remain writable for solution.py, checks and fitted JSON.

Both file-tool hooks and the Python OS sandbox deny writes, unlinking and renaming
of the supplied input files. Input hashes are checked after the run.
The prepared source file set and bytes are pinned, as are CLI/runner/plugin bytes.
Agents retain stdlib-only Python execution with no network, external file writes,
credential inheritance, installs, or nested agents. Both Augustus skills can load
in skill arms; neither can load in baseline. Bundled CLI skill descriptions remain
equally visible but their Skill calls are denied.

## Repetition and order

Task A is selection and task B is policy, in that explicit order (not sorted).
Each repeat runs task A's three arms then task B's three
arms. Every task/arm occurs once in each ordinal position across three repeats:

| Repeat | Task A | Task B |
| --- | --- | --- |
| 1 | none, auto, explicit | auto, explicit, none |
| 2 | auto, explicit, none | explicit, none, auto |
| 3 | explicit, none, auto | none, auto, explicit |

IDs are `release-<task>-r<1..3>-<none|auto|explicit>`. None and auto prompts remain
byte-identical. Explicit prepends exactly:

`Before implementing, load augustus-train and apply its relevant guidance.`

No automatic reruns or additional conditions. Exact activation requires a Skill
call, successful tool result and loaded body, not a name mentioned in prose.

## Commands

From `.amp/in/artifacts/application-instrument` on the Mac:

```sh
# Offline only: scripted API responses, real CLI and sandbox checks.
python3 -m unittest -v test_instrument test_cli

# Already performed once; do not reset the campaign state. No inference.
python3 instrument.py prepare \
  --tasks tasks.tar.gz \
  --tasks-sha256 523800f786778159a0188ba5486c40898d61e54c7f8023577371fb051b5412c1 \
  --release ../081-vibeproxy-results/release-agents \
  --state ../application-state

# Inspect state without inference.
python3 instrument.py status --state ../application-state

# The authorized initial block was launched once. Do not retry failures.
python3 instrument.py run --state ../application-state \
  --variant release --authorize-inference
```

Six offline tests passed, including an archive with asymmetric JSON inputs,
all 18 schedule IDs, counterbalanced positions, changed-input rejection, budget
boundaries, and the actual three-arm CLI with successful skill loads and attempted
input overwrites denied. Mock traces live under `selftest/`; they are not paid
attempts. `validation-root-inputs.txt` records the final checks before launch.

Each live attempt will retain its cost/status, trace, guard events, actual command
and nonsecret config, original inputs, and final generated scripts/JSON. This
runner collects rather than evaluates hidden future outcomes. Provider names
remain routing evidence, not independent upstream model attestation.

## Interpreting turn metadata

All commands retain `--max-turns 20`. Claude 2.1.282's result `num_turns` is not
the number of model responses: inspection of the installed binary showed it
increments for emitted user events (including tool-result events). For example,
selection repeat 1 explicit returned `num_turns: 32`, but its trace has only 15
distinct assistant message IDs. The export preserves the raw result count and
separately reports unique assistant message IDs; do not interpret the raw count
as 32 model turns or silently relabel it. The 180-second wall limit is enforced
independently by the runner.
