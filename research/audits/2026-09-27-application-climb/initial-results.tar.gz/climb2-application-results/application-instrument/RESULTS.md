# Application experiment: 18 initial runs, ungraded

All 18 authorized attempts completed successfully at the CLI/protocol level.
No retries, extra variants, timeouts or outcome grading occurred. Every attempt
produced solution.py and additional generated files, all retained. The protected
future data, grader and private freeze manifest were never downloaded or read.

| Task | Arm | Runs | Reported cost | Exact trainer loads |
| --- | --- | ---: | ---: | ---: |
| selection | none | 3 | $0.8753646 | 0 |
| selection | auto | 3 | $0.8929834 | 0 |
| selection | explicit | 3 | $1.1794306 | 3 |
| policy | none | 3 | $0.4670172 | 0 |
| policy | auto | 3 | $0.4513132 | 0 |
| policy | explicit | 3 | $0.6498088 | 3 |

New reported cost: **$4.5159178** of $10. Prior stopped campaign remains
**$1.8080588**. Combined reported cost: **$6.3239766**. No further attempts are
authorized by completion of this block; the unused dollar allowance does not
authorize retries or additional variants.

## Verified execution evidence

- The exact eight-file public archive and complete 0.8.1 skill snapshot were
  fingerprinted. Original task input names and bytes survived in every fixture.
- Selection ran before policy in each repeat. Three cyclic arm orders were used,
  with policy offset by one. Each arm occupied each position once per task.
- All six none/auto prompt pairs were byte-identical. Explicit prompts differed
  only by the exact requested prefix and two newlines.
- Both Augustus skills were available in all skill arms, neither in baseline.
  No automatic arm loaded either body. All explicit arms successfully loaded
  `.agents:augustus-train`, confirmed by calls, tool results and body messages.
- Every init/assistant model and result model-usage key reported
  `claude-opus-5-5`. Effort remained medium. No other model appeared in those
  metadata surfaces. VibeProxy retries/fallback remained disabled in the reused
  isolated backend configuration. This is routing evidence, not independent
  upstream model attestation or invoice reconciliation.
- All commands specified `--max-turns 20`; traces contained 5–15 distinct
  assistant message IDs. Raw result `num_turns` ranged 8–32 because it includes
  tool-result user events; see README for the verified distinction. Wall times
  ranged 39.00–175.31 seconds, within the separate 180-second deadline.
- Six offline checks passed before launch. They exercised the actual CLI,
  both skill loads, network/credential/file isolation, immutable root inputs,
  repeat IDs/order, hash fencing and spend boundaries.
- Twelve Bash calls were denied and retained in the traces: eight `python3 -c`
  invocations, one `python3 --version`, and three attempts to run missing scripts.
  These were guard denials, not failed experiment attempts. The
  same restrictions and recovery opportunity applied to every condition.

## Interpretation and handoff

CLI success is not proof of correct decisions. Parent must evaluate fit/decide
on its frozen future data. Generated checks and self-reported measurements are
artifacts, not independent grades. Three repeats per task provide paired
development evidence but not a broad claim of superiority, general activation
recall, or nontrigger false-positive rate. No dedicated nontrigger tasks were
included in this block.

Use `application-state/runs/release-<selection|policy>-r<1|2|3>-<arm>/artifacts/`
for grading inputs. Adjacent files hold complete selected traces and actual
nonsecret configuration. `observations.json` records costs, loads, inventories,
model usage, counters, generated filenames and solution hashes. Source files
and release skills are unchanged; no normal configuration, installed skills,
tracked checkout, commits or pushes were modified.

The export omits credentials, runtime homes, private proxy configuration and
private proxy logs. Selected trace/config bytes and nonsecret absolute paths
are retained unchanged. The file manifest covers every other exported file.
Mock CLI evidence is isolated under `offline-validation` and excluded from live
counts and spend. A preliminary mock batch used inputs/; the final root-input
batch and `validation-root-inputs.txt` reflect the launched interface.
