"""Offline allowlisted export; no inference, graders, runtime homes or auth."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent/'application-state'
DEST = HERE.parent/'climb2-application-results'
ARCHIVE = HERE.parents[3]/'climb2-application-results.tar.gz'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    state = json.loads((SOURCE/'state.json').read_text())
    assert state['records'] and all(r['status'] != 'running' for r in state['records'])
    assert not DEST.exists() and not ARCHIVE.exists(), 'Never overwrite evidence exports'
    DEST.mkdir()
    shutil.copytree(SOURCE, DEST/'application-state', ignore=shutil.ignore_patterns('lock'))
    instrument = DEST/'application-instrument'; instrument.mkdir()
    for name in ['instrument.py','test_instrument.py','test_cli.py','README.md','RESULTS.md',
                 'validation-root-inputs.txt','tasks.tar.gz','package_results.py']:
        shutil.copyfile(HERE/name, instrument/name)
    shutil.copytree(SOURCE/'plugins/release/.agents', DEST/'081-vibeproxy-results/release-agents')
    offline = DEST/'offline-validation'; offline.mkdir()
    for runtime in sorted((HERE/'selftest').glob('mock-*')):
        target = offline/runtime.name; target.mkdir()
        for name in ['trace.jsonl','stderr.log','guard-events.jsonl','offline-observation.json',
                     'settings.json','guard.json','sandbox.sb','prompt.txt','execution.json']:
            if (runtime/name).is_file(): shutil.copyfile(runtime/name,target/name)
        if (runtime/'fixture').exists(): shutil.copytree(runtime/'fixture',target/'fixture')
    observations = []
    for record in state['records']:
        run = SOURCE/'runs'/record['id']
        rows = []
        for line in (run/'trace.jsonl').read_text().splitlines():
            try: rows.append(json.loads(line))
            except json.JSONDecodeError: pass
        init = next((r for r in rows if r.get('subtype')=='init'), {})
        result = next((r for r in reversed(rows) if r.get('type')=='result'), {})
        manifest = json.loads((run/'artifact-manifest.json').read_text())
        for name, expected in manifest['files'].items():
            assert sha(run/'artifacts'/name)==expected
        for name in ['operations.md','rows.json','config.json']:
            assert sha(run/'artifacts'/name)==state['taskFiles'][record['task']+'/'+name]
        assert sha(run/'artifacts/TASK.md')==state['tasks'][record['task']]
        guards = [json.loads(line) for line in (run/'guard-events.jsonl').read_text().splitlines()] if (run/'guard-events.jsonl').exists() else []
        observations.append({**record, 'turns':result.get('num_turns'),
            'uniqueAssistantMessageIds':len({r['message']['id'] for r in rows if r.get('type')=='assistant'}),
            'availableSkills':init.get('skills'), 'tools':init.get('tools'),
            'responseModels':sorted({r['message']['model'] for r in rows if r.get('type')=='assistant'}),
            'modelUsage':result.get('modelUsage'),
            'solutionSha256':manifest['files'].get('solution.py'),
            'generatedFiles':[name for name in manifest['files'] if name not in ['TASK.md','operations.md','rows.json','config.json']],
            'deniedTools':[g['tool'] for g in guards if g['decision']['permissionDecision']=='deny']})
    known = sum(r['cost'] for r in state['records'] if r.get('cost') is not None)
    summary = {'requestedRuns':18,'attemptedRuns':len(observations),
        'knownReportedCostUsd':known,'unknownCostRuns':[r['id'] for r in state['records'] if r.get('cost') is None],
        'priorCampaignReportedCostUsd':state['priorCampaignReportedCostUsd'],
        'combinedKnownReportedCostUsd':known+state['priorCampaignReportedCostUsd'],
        'parentPrivateFreezeManifestSha256':'b1b85d9bad7eea749ccb824661483a35980967883455c908cbcf8ea3f3b7a8da',
        'grading':'None performed; private data and graders not accessed.', 'records':observations}
    (DEST/'observations.json').write_text(json.dumps(summary,indent=2)+'\n')
    # Preserve content bytes; omit secret-bearing sources rather than rewrite evidence.
    patterns = [rb'sk-ant-[A-Za-z0-9_-]{20,}',rb'sk-[A-Za-z0-9]{32,}',
                rb'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}']
    for p in DEST.rglob('*'):
        if p.is_file():
            assert not any(re.search(pattern,p.read_bytes()) for pattern in patterns), f'Secret-shaped bytes: {p.name}'
    (DEST/'export-receipt.json').write_text(json.dumps({
        'authExported':False,'runtimeHomesExported':False,'privateProxyConfigAndLogsExported':False,
        'credentialShapeScan':'passed','evidenceBytes':'unchanged',
        'nonsecretAbsolutePaths':'retained for exact execution provenance',
        'offlineValidation':'scripted API tests only, excluded from live denominators'},indent=2)+'\n')
    files = sorted(p for p in DEST.rglob('*') if p.is_file())
    (DEST/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(DEST)}\n' for p in files))
    with tarfile.open(ARCHIVE,'w:gz') as out: out.add(DEST,arcname=DEST.name)
    print(json.dumps({'archive':str(ARCHIVE),'sha256':sha(ARCHIVE),
                      'attempts':len(observations),'knownReportedCostUsd':known},indent=2))


if __name__=='__main__': main()
