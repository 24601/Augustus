import json,pathlib,socket,os
results={}
def test(name,fn):
 try: fn(); results[name]="ALLOWED"
 except OSError: results[name]="DENIED"
test("read",lambda:pathlib.Path('/Users/basitmustafa/Developer/Augustus/.amp/in/artifacts/application-instrument/selftest/mock-auto-_n0q1o75/forbidden.txt').read_text())
test("write",lambda:pathlib.Path('/Users/basitmustafa/Developer/Augustus/.amp/in/artifacts/application-instrument/selftest/mock-auto-_n0q1o75/escaped.txt').write_text("bad"))
test("input_write",lambda:pathlib.Path("rows.json").write_text("bad"))
results["input_read"]=json.loads(pathlib.Path("rows.json").read_text())
test("network",lambda:socket.create_connection(("127.0.0.1",8317),timeout=1))
results["credential"]=os.environ.get("ANTHROPIC_AUTH_TOKEN")
pathlib.Path("checks.json").write_text(json.dumps(results))
print(json.dumps(results))
