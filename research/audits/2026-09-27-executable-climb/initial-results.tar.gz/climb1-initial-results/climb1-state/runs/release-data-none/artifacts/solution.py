"""Build a leakage-safe first-message routing dataset."""
import json
import sys

ROLES = ("train", "dev", "confirm")


def _norm(text):
    return " ".join(text.casefold().split())


def _choose_first(rows):
    """Earliest user event per ticket; ties broken by smallest text."""
    chosen = {}
    for row in rows:
        if row.get("role") != "user":
            continue
        ticket = row.get("ticket")
        if ticket is None or row.get("time") is None:
            continue
        key = (str(row["time"]), row.get("text") or "")
        cur = chosen.get(ticket)
        if cur is None or key < cur[0]:
            chosen[ticket] = (key, row)
    return {t: r for t, (_, r) in chosen.items()}


def _role(time, train_end, dev_end):
    if time < train_end:
        return "train"
    if time < dev_end:
        return "dev"
    return "confirm"


def _eligible(ticket, row, train_end, dev_end):
    text = row.get("text")
    if not isinstance(text, str) or not text.strip():
        return None
    if row.get("label") is None or row.get("label_status") != "agreed":
        return None
    role = _role(str(row["time"]), train_end, dev_end)
    label_time = row.get("label_time")
    if role == "train" and (label_time is None or not str(label_time) < train_end):
        return None
    if role == "dev" and (label_time is None or not str(label_time) < dev_end):
        return None
    return {
        "role": role,
        "example": {
            "id": ticket,
            "customer": row.get("customer"),
            "text": text,
            "label": row["label"],
        },
    }


def _sort_key(ticket):
    if isinstance(ticket, (int, float)) and not isinstance(ticket, bool):
        return (0, ticket, "")
    return (1, 0, str(ticket))


def prepare(rows, train_end, dev_end):
    train_end, dev_end = str(train_end), str(dev_end)
    items = []
    for ticket, row in _choose_first(rows).items():
        item = _eligible(ticket, row, train_end, dev_end)
        if item is not None:
            items.append(item)

    parent = list(range(len(items)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    owner = {}
    for i, item in enumerate(items):
        ex = item["example"]
        keys = [("t", _norm(ex["text"]))]
        if ex["customer"] is not None:
            keys.append(("c", json.dumps(ex["customer"], sort_keys=True)))
        for k in keys:
            if k in owner:
                a, b = find(i), find(owner[k])
                if a != b:
                    parent[a] = b
            else:
                owner[k] = i

    best = {}
    for i, item in enumerate(items):
        root = find(i)
        rank = ROLES.index(item["role"])
        best[root] = min(best.get(root, rank), rank)

    out = {r: [] for r in ROLES}
    for i, item in enumerate(items):
        if ROLES.index(item["role"]) == best[find(i)]:
            out[item["role"]].append(item["example"])
    for r in ROLES:
        out[r].sort(key=lambda ex: _sort_key(ex["id"]))
    return out


def main():
    args = json.load(sys.stdin)
    result = prepare(args["rows"], args["train_end"], args["dev_end"])
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
