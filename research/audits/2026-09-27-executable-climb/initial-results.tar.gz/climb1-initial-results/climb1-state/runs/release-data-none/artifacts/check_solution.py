import json
import subprocess
import sys

from solution import prepare


def row(ticket, customer, time, text, label="a", label_time=None, status="agreed",
        role="user", **extra):
    r = dict(ticket=ticket, customer=customer, time=time, role=role, text=text,
             label=label, label_time=label_time or time, label_status=status)
    r.update(extra)
    return r


TE, DE = "2024-02-01", "2024-03-01"


def ids(out):
    return {k: [e["id"] for e in v] for k, v in out.items()}


def check(name, got, want):
    assert got == want, f"{name}: got {got}, want {want}"
    print("ok", name)


# Earliest user event wins; staff events ignored; equal-time tie by smallest text.
rows = [
    row("T1", "c1", "2024-01-05", "later reply"),
    row("T1", "c1", "2024-01-02", "zeta first", secret="x"),
    row("T1", "c1", "2024-01-02", "alpha first"),
    row("T1", "c1", "2024-01-01", "staff hello", role="staff"),
]
out = prepare(rows, TE, DE)
check("tie+staff", out["train"], [{"id": "T1", "customer": "c1", "text": "alpha first", "label": "a"}])
check("exact keys", set(out["train"][0]), {"id", "customer", "text", "label"})

# Unusable first event is not replaced by a later reply.
for bad in (dict(text="   "), dict(label=None), dict(status="disputed")):
    kw = dict(text="hi", label="a", status="agreed")
    kw.update(bad)
    rows = [row("T2", "c2", "2024-01-01", kw["text"], label=kw["label"], status=kw["status"]),
            row("T2", "c2", "2024-01-03", "good reply")]
    check(f"no replace {bad}", ids(prepare(rows, TE, DE)), {"train": [], "dev": [], "confirm": []})

# Label availability: train needs label < TE; dev < DE; confirm anything. No migration.
rows = [
    row("A", "ca", "2024-01-10", "a", label_time="2024-02-01"),  # train, label too late
    row("B", "cb", "2024-01-10", "b", label_time="2024-01-31"),  # train ok
    row("C", "cc", "2024-02-10", "c", label_time="2024-03-01"),  # dev, too late
    row("D", "cd", "2024-02-10", "d", label_time="2024-02-28"),  # dev ok
    row("E", "ce", "2024-03-01", "e", label_time="2025-01-01"),  # confirm ok
    row("F", "cf", "2024-02-01", "f", label_time="2024-02-01"),  # boundary -> dev ok
]
check("availability", ids(prepare(rows, TE, DE)), {"train": ["B"], "dev": ["D", "F"], "confirm": ["E"]})

# Late-label ticket excluded before grouping: does not block its customer's dev ticket.
rows = [
    row("G1", "cg", "2024-01-10", "g1", label_time="2024-05-01"),
    row("G2", "cg", "2024-02-10", "g2"),
]
check("ineligible no bind", ids(prepare(rows, TE, DE)), {"train": [], "dev": ["G2"], "confirm": []})

# Transitive binding: train(c1,"x") ~ dev(c1,"Y  z") ~ confirm(c9,"y z") -> only train survives.
rows = [
    row("H1", "c1", "2024-01-10", "x"),
    row("H2", "c1", "2024-02-10", "Y  z"),
    row("H3", "c9", "2024-03-10", "  y\tZ "),
    row("H4", "c9", "2024-03-11", "other"),  # same component via c9
    row("H5", "c1", "2024-01-11", "x2"),  # same role, kept separately
    row("H6", "c7", "2024-02-11", "free"),  # unrelated dev
]
out = prepare(rows, TE, DE)
check("transitive", ids(out), {"train": ["H1", "H5"], "dev": ["H6"], "confirm": []})

# Component whose earliest role is dev drops its confirm members; original text preserved.
rows = [
    row("K2", "k", "2024-02-10", "  Hello  World "),
    row("K1", "z", "2024-02-11", "hello world"),
    row("K3", "q", "2024-04-01", "HELLO WORLD"),
]
out = prepare(rows, TE, DE)
check("dev group", ids(out), {"train": [], "dev": ["K1", "K2"], "confirm": []})
check("original text", out["dev"][1]["text"], "  Hello  World ")

# CLI round trip.
payload = json.dumps({"rows": rows, "train_end": TE, "dev_end": DE})
proc = subprocess.run([sys.executable, "solution.py"], input=payload, capture_output=True,
                      text=True, check=True)
check("cli", json.loads(proc.stdout), out)
print("all checks passed")
