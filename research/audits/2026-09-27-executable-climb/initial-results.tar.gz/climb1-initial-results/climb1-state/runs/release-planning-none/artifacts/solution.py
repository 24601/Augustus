"""Experiment planning: group-aware learning-curve sizes and cost-based model selection."""
import json
import sys
from fractions import Fraction


def _valid_size(s):
    return isinstance(s, int) and not isinstance(s, bool) and s > 0


def curve(rows, folds, sizes):
    ids = {}
    labels = []
    for r in rows:
        rid = r["id"]
        if rid in ids:
            raise ValueError("duplicate row id: %r" % (rid,))
        ids[rid] = r
        if r["label"] not in labels:
            labels.append(r["label"])
    labels.sort()
    wanted = sorted({s for s in sizes if _valid_size(s)})

    out = []
    for fold in folds:
        held_groups = set()
        for rid in fold:
            if rid not in ids:
                raise ValueError("unknown row id: %r" % (rid,))
            held_groups.add(ids[rid]["group"])
        available = {lab: 0 for lab in labels}
        for r in rows:
            if r["group"] not in held_groups:
                available[r["label"]] += 1
        cap = min(available.values()) if available else 0
        out.append({"available": available, "sizes": [s for s in wanted if s <= cap]})
    return out


def _exact(x):
    return Fraction(x)  # exact for ints and floats; no rounding


def _remaining_fit(c):
    fit = _exact(c["fit_cost"])
    paid = c.get("already_paid", False)
    if isinstance(paid, bool):
        return Fraction(0) if paid else fit
    # numeric amount already spent: only the unpaid remainder is a future cost
    return max(fit - _exact(paid), Fraction(0))


def select(candidates, horizon, fn_cost, fp_cost, max_latency):
    horizon = _exact(horizon)
    fn_cost = _exact(fn_cost)
    fp_cost = _exact(fp_cost)
    best = None
    for c in candidates:
        if c["latency_ms"] > max_latency:
            continue
        n = _exact(c["n"])
        err = horizon * (_exact(c["fn"]) / n * fn_cost + _exact(c["fp"]) / n * fp_cost)
        total = err + _remaining_fit(c)
        key = (total, c["name"])
        if best is None or key < best[0]:
            best = (key, c["name"], total)
    if best is None:
        return None
    total = best[2]
    return {"name": best[1], "total_cost": int(total) if total.denominator == 1 else float(total)}


def main():
    try:
        req = json.load(sys.stdin)
        args = dict(req)
        op = args.pop("op")
        if op == "curve":
            result = curve(**args)
        elif op == "select":
            result = select(**args)
        else:
            raise ValueError("unknown op: %r" % (op,))
    except (ValueError, KeyError, TypeError) as e:
        json.dump({"error": str(e)}, sys.stdout)
        sys.stdout.write("\n")
        return 1
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
