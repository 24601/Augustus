import json
import subprocess
import sys

from solution import curve, select

ROWS = [
    {"id": "a", "group": "g1", "label": "pos"},
    {"id": "b", "group": "g1", "label": "neg"},
    {"id": "c", "group": "g2", "label": "pos"},
    {"id": "d", "group": "g2", "label": "neg"},
    {"id": "e", "group": "g3", "label": "pos"},
    {"id": "f", "group": "g3", "label": "neg"},
    {"id": "g", "group": "g4", "label": "pos"},
    {"id": "h", "group": "g5", "label": "rare"},
]


def raises(fn, *a):
    try:
        fn(*a)
    except ValueError:
        return True
    return False


# group leakage: holding out "a" also removes "b" (same group)
r = curve(ROWS, [["a"], ["h"], []], [3, 1, 1, 2, 0, -1, True, 2.0, 1.5, "2"])
assert r[0] == {"available": {"neg": 2, "pos": 3, "rare": 1}, "sizes": [1]}, r[0]
# rare class fully held out -> zero count kept, no size achievable
assert r[1] == {"available": {"neg": 3, "pos": 4, "rare": 0}, "sizes": []}, r[1]
assert r[2] == {"available": {"neg": 3, "pos": 4, "rare": 1}, "sizes": [1]}, r[2]
# without the rare class, size boundary equals min class count
r = curve(ROWS[:7], [["g"], ["a", "c"]], [2, 3, 4])
assert r[0]["sizes"] == [2, 3] and r[0]["available"] == {"neg": 3, "pos": 3}, r
assert r[1]["sizes"] == [] and r[1]["available"] == {"neg": 1, "pos": 2}, r  # 2 not ok: neg=1
assert curve(ROWS, [], [1]) == []
assert curve([], [[]], [1]) == [{"available": {}, "sizes": []}]
assert raises(curve, ROWS, [["zz"]], [1])
assert raises(curve, ROWS + [ROWS[0]], [[]], [1])

# select
C = [
    # errors: 1000 * (1/3*30 + 1/3*3) = 11000; fit 5 paid -> 11000
    {"name": "b", "n": 3, "fn": 1, "fp": 1, "latency_ms": 50, "fit_cost": 5, "already_paid": True},
    # same error, unpaid fit 0 -> tie at 11000; lexicographic 'a' wins
    {"name": "a", "n": 3, "fn": 1, "fp": 1, "latency_ms": 50, "fit_cost": 0, "already_paid": False},
    # zero errors but too slow
    {"name": "fast_but_slow", "n": 10, "fn": 0, "fp": 0, "latency_ms": 51, "fit_cost": 0, "already_paid": False},
]
assert select(C, 1000, 30, 3, 50) == {"name": "a", "total_cost": 11000}
assert select(C, 1000, 30, 3, 51) == {"name": "fast_but_slow", "total_cost": 0}
assert select(C, 1000, 30, 3, 49) is None
assert select([], 1, 1, 1, 1) is None
# sunk cost: paid expensive fit not counted again
S = [
    {"name": "old", "n": 100, "fn": 5, "fp": 0, "latency_ms": 1, "fit_cost": 10**6, "already_paid": True},
    {"name": "new", "n": 100, "fn": 4, "fp": 0, "latency_ms": 1, "fit_cost": 50, "already_paid": False},
]
# old: 1000*0.05*10=500; new: 1000*0.04*10+50=450
assert select(S, 1000, 10, 0, 5) == {"name": "new", "total_cost": 450}
assert select(S, 100, 10, 0, 5) == {"name": "old", "total_cost": 50}  # 50 vs 40+50
# fractional rate kept exact: 1/3 * 1 * 1 -> 0.333..., no early rounding
R = [{"name": "x", "n": 3, "fn": 1, "fp": 0, "latency_ms": 0, "fit_cost": 0, "already_paid": False}]
assert select(R, 1, 1, 1, 0) == {"name": "x", "total_cost": 1 / 3}
# exact tie that floats would break: 0.1+0.2 vs 0.3 style
T = [
    {"name": "z", "n": 7, "fn": 1, "fp": 0, "latency_ms": 0, "fit_cost": 0, "already_paid": False},
    {"name": "y", "n": 14, "fn": 2, "fp": 0, "latency_ms": 0, "fit_cost": 0, "already_paid": False},
]
assert select(T, 3, 1, 0, 0)["name"] == "y"

# CLI
def cli(payload):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(payload),
                       capture_output=True, text=True)
    return p.returncode, json.loads(p.stdout)

rc, out = cli({"op": "select", "candidates": S, "horizon": 1000, "fn_cost": 10, "fp_cost": 0, "max_latency": 5})
assert rc == 0 and out == {"name": "new", "total_cost": 450}, out
rc, out = cli({"op": "select", "candidates": S, "horizon": 1, "fn_cost": 1, "fp_cost": 1, "max_latency": 0})
assert rc == 0 and out is None
rc, out = cli({"op": "curve", "rows": ROWS, "folds": [["a"]], "sizes": [1, 2]})
assert rc == 0 and out == [{"available": {"neg": 2, "pos": 3, "rare": 1}, "sizes": [1]}], out
rc, out = cli({"op": "curve", "rows": ROWS, "folds": [["nope"]], "sizes": [1]})
assert rc == 1 and "error" in out
print("all checks passed")
