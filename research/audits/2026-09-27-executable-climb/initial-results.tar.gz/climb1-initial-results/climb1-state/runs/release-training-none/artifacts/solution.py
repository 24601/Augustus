"""Tiny soft-target logistic classifier: fit, export, load, predict (stdlib only).

Artifact schema (JSON object, version "soft-logistic-v1"):
  format       "soft-logistic-v1"
  w, b         finite numbers; raw logit = w*x + b
  temperature  finite positive number; calibrated logit = (w*x + b) / temperature
  fn_cost      finite positive cost of a false negative
  fp_cost      finite positive cost of a false positive
Decision: p = sigmoid(calibrated logit); expected loss of "positive" is
(1-p)*fp_cost, of "negative" is p*fn_cost. Choose "positive" only when its
expected loss is strictly lower; ties go to "negative".

CLI:
  python3 solution.py fit training.json artifact.json
  python3 solution.py predict artifact.json   < JSONL {"x": number} lines
"""

import json
import math
import os
import sys

FORMAT = "soft-logistic-v1"


def _is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _finite_number(v, name):
    if not _is_number(v) or not math.isfinite(v):
        raise ValueError(f"{name} must be a finite number, got {v!r}")
    return float(v)


def _positive_number(v, name):
    v = _finite_number(v, name)
    if v <= 0:
        raise ValueError(f"{name} must be positive, got {v!r}")
    return v


def _reject_constant(c):
    raise ValueError(f"non-finite JSON constant {c} not allowed")


def _json_load(fh):
    return json.load(fh, parse_constant=_reject_constant)


def sigmoid(z):
    """Numerically stable logistic function; finite for any finite (or infinite) z."""
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)


def fit(rows, epochs, lr):
    """Full-batch gradient descent on mean BCE with soft targets.

    d(BCE)/d(logit) = p - target, so grad_w = mean((p-t)*x), grad_b = mean(p-t).
    """
    if isinstance(epochs, bool) or not isinstance(epochs, int) or epochs < 0:
        raise ValueError(f"epochs must be a non-negative integer, got {epochs!r}")
    lr = _positive_number(lr, "lr")
    data = []
    for i, row in enumerate(rows):
        try:
            x, t = row["x"], row["target"]
        except (TypeError, KeyError):
            raise ValueError(f"row {i} must be an object with 'x' and 'target'")
        x = _finite_number(x, f"row {i} x")
        t = _finite_number(t, f"row {i} target")
        if not 0.0 <= t <= 1.0:
            raise ValueError(f"row {i} target must be in [0, 1], got {t!r}")
        data.append((x, t))
    if not data:
        raise ValueError("rows must be non-empty")

    n = len(data)
    w = 0.0
    b = 0.0
    for _ in range(epochs):
        gw = 0.0
        gb = 0.0
        for x, t in data:
            err = sigmoid(w * x + b) - t
            gw += err * x
            gb += err
        # simultaneous update from the same old parameters
        w, b = w - lr * gw / n, b - lr * gb / n
    if not (math.isfinite(w) and math.isfinite(b)):
        raise ValueError("training diverged to non-finite parameters")
    return {"w": w, "b": b}


def _validate_bundle(bundle):
    if not isinstance(bundle, dict):
        raise ValueError("bundle must be a JSON object")
    for key in ("w", "b", "temperature", "fn_cost", "fp_cost"):
        if key not in bundle:
            raise KeyError(f"bundle missing required key {key!r}")
    out = {
        "format": FORMAT,
        "w": _finite_number(bundle["w"], "w"),
        "b": _finite_number(bundle["b"], "b"),
        "temperature": _positive_number(bundle["temperature"], "temperature"),
        "fn_cost": _positive_number(bundle["fn_cost"], "fn_cost"),
        "fp_cost": _positive_number(bundle["fp_cost"], "fp_cost"),
    }
    if "format" in bundle and bundle["format"] != FORMAT:
        raise ValueError(f"unsupported artifact format {bundle['format']!r}")
    return out


def export(path, model, temperature, fn_cost, fp_cost):
    if not isinstance(model, dict):
        raise ValueError("model must be a dict with 'w' and 'b'")
    bundle = _validate_bundle({
        "w": model.get("w"),
        "b": model.get("b"),
        "temperature": temperature,
        "fn_cost": fn_cost,
        "fp_cost": fp_cost,
    })
    text = json.dumps(bundle, allow_nan=False, indent=2) + "\n"
    # "x" mode: atomic refusal to overwrite an existing path
    with open(path, "x", encoding="utf-8") as fh:
        fh.write(text)
    return bundle


def load(path):
    with open(path, "r", encoding="utf-8") as fh:
        return _validate_bundle(_json_load(fh))


def predict(bundle, x):
    bundle = _validate_bundle(bundle)
    x = _finite_number(x, "x")
    z = (bundle["w"] * x + bundle["b"]) / bundle["temperature"]
    if math.isnan(z):
        raise ValueError("logit is NaN")
    p = sigmoid(z)
    loss_positive = (1.0 - p) * bundle["fp_cost"]
    loss_negative = p * bundle["fn_cost"]
    action = "positive" if loss_positive < loss_negative else "negative"
    return {"p": p, "action": action}


def _cli_fit(training_path, artifact_path):
    if os.path.lexists(artifact_path):
        raise FileExistsError(f"refusing to overwrite existing {artifact_path}")
    with open(training_path, "r", encoding="utf-8") as fh:
        cfg = _json_load(fh)
    if not isinstance(cfg, dict):
        raise ValueError("training file must contain a JSON object")
    for key in ("rows", "epochs", "lr", "temperature", "fn_cost", "fp_cost"):
        if key not in cfg:
            raise KeyError(f"training file missing {key!r}")
    if not isinstance(cfg["rows"], list):
        raise ValueError("rows must be a list")
    # validate policy before spending time training
    _validate_bundle({"w": 0, "b": 0, "temperature": cfg["temperature"],
                      "fn_cost": cfg["fn_cost"], "fp_cost": cfg["fp_cost"]})
    model = fit(cfg["rows"], cfg["epochs"], cfg["lr"])
    export(artifact_path, model, cfg["temperature"], cfg["fn_cost"], cfg["fp_cost"])
    print(json.dumps(model))


def _cli_predict(artifact_path):
    bundle = load(artifact_path)
    for lineno, line in enumerate(sys.stdin, 1):
        if not line.strip():
            continue
        obj = json.loads(line, parse_constant=_reject_constant)
        if not isinstance(obj, dict) or "x" not in obj:
            raise ValueError(f"line {lineno}: expected an object with 'x'")
        sys.stdout.write(json.dumps(predict(bundle, obj["x"]), allow_nan=False) + "\n")


def main(argv):
    try:
        if len(argv) == 3 and argv[0] == "fit":
            _cli_fit(argv[1], argv[2])
        elif len(argv) == 2 and argv[0] == "predict":
            _cli_predict(argv[1])
        else:
            print(__doc__, file=sys.stderr)
            return 2
    except (ValueError, KeyError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
