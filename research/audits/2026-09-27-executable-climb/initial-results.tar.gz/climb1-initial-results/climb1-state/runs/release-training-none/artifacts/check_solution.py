"""Checks for solution.py: fitting math, export/load validation, prediction, fresh-process CLI."""

import json
import math
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import solution as S  # noqa: E402

failures = []


def check(cond, msg):
    print(("ok   " if cond else "FAIL ") + msg)
    if not cond:
        failures.append(msg)


def raises(fn, excs=(ValueError, KeyError)):
    try:
        fn()
    except excs:
        return True
    except Exception as e:  # wrong type
        print("   unexpected", type(e).__name__, e)
        return False
    return False


def sig(z):
    return 1 / (1 + math.exp(-z))


# --- fit: reference implementation step by step ---
rows = [{"x": -2, "target": 0.1}, {"x": 0.5, "target": 0.6}, {"x": 3, "target": 0.95}]
w = b = 0.0
for _ in range(7):
    gw = sum((sig(w * r["x"] + b) - r["target"]) * r["x"] for r in rows) / 3
    gb = sum((sig(w * r["x"] + b) - r["target"]) for r in rows) / 3
    w, b = w - 0.3 * gw, b - 0.3 * gb
m = S.fit(rows, 7, 0.3)
check(set(m) == {"w", "b"}, "fit returns exactly w,b")
check(abs(m["w"] - w) < 1e-12 and abs(m["b"] - b) < 1e-12, f"fit matches reference {m} vs {(w, b)}")
check(S.fit(rows, 0, 0.1) == {"w": 0.0, "b": 0.0}, "zero epochs -> zero init")
# one step by hand: p=0.5 everywhere
m1 = S.fit(rows, 1, 1.0)
exp_w = -sum((0.5 - r["target"]) * r["x"] for r in rows) / 3
exp_b = -sum((0.5 - r["target"]) for r in rows) / 3
check(abs(m1["w"] - exp_w) < 1e-15 and abs(m1["b"] - exp_b) < 1e-15, "single simultaneous step")
# soft target optimum: constant x=0, target 0.7 -> b -> logit(0.7), not a hard label
ms = S.fit([{"x": 0, "target": 0.7}] * 4, 5000, 1.0)
check(abs(ms["b"] - math.log(0.7 / 0.3)) < 1e-6 and ms["w"] == 0, f"soft target converges {ms}")
for bad in ([], [{"x": 1, "target": 1.5}], [{"x": float("nan"), "target": 0.5}], [{"x": True, "target": 0.5}]):
    check(raises(lambda: S.fit(bad, 3, 0.1)), f"fit rejects rows {bad}")
for e, lr in ((-1, 0.1), (3, 0), (3, -1), (3, float("inf")), (True, 0.1), (2.5, 0.1)):
    check(raises(lambda: S.fit(rows, e, lr)), f"fit rejects epochs={e} lr={lr}")

# --- export / load ---
tmp = tempfile.mkdtemp(dir=HERE)
try:
    p = os.path.join(tmp, "a.json")
    for t, fn, fp in ((0, 1, 1), (-1, 1, 1), (float("nan"), 1, 1), (float("inf"), 1, 1), (True, 1, 1),
                      (1, 0, 1), (1, 1, False), (1, "2", 1), (1, None, 1)):
        check(raises(lambda: S.export(p, m, t, fn, fp)) and not os.path.exists(p),
              f"export rejects temp={t} fn={fn} fp={fp} without writing")
    S.export(p, m, 2.0, 5.0, 1.0)
    check(raises(lambda: S.export(p, m, 1.0, 1.0, 1.0), (FileExistsError,)), "export refuses overwrite")
    bundle = S.load(p)
    check(bundle["temperature"] == 2.0 and bundle["fn_cost"] == 5.0 and bundle["fp_cost"] == 1.0,
          "load round-trips policy")
    raw = json.load(open(p))
    check(all(k in raw for k in ("temperature", "fn_cost", "fp_cost")), "top-level policy keys")
    for key, val in (("temperature", None), ("fn_cost", 0), ("fp_cost", -3), ("temperature", True),
                     ("fn_cost", "1")):
        q = os.path.join(tmp, f"bad_{key}_{val}.json")
        d = dict(raw)
        d[key] = val
        json.dump(d, open(q, "w"))
        check(raises(lambda: S.load(q)), f"load rejects {key}={val!r}")
        d.pop(key)
        q2 = q + ".missing"
        json.dump(d, open(q2, "w"))
        check(raises(lambda: S.load(q2)), f"load rejects missing {key}")
    q = os.path.join(tmp, "nan.json")
    open(q, "w").write('{"w":1,"b":0,"temperature":NaN,"fn_cost":1,"fp_cost":1}')
    check(raises(lambda: S.load(q)), "load rejects NaN temperature")
    check(raises(lambda: S.load(os.path.join(tmp, "nope.json")), (OSError,)), "load missing file")

    # --- predict ---
    B = {"w": 1.0, "b": 0.0, "temperature": 1.0, "fn_cost": 1.0, "fp_cost": 1.0}
    r = S.predict(B, 0)
    check(r == {"p": 0.5, "action": "negative"}, f"exact tie -> negative {r}")
    check(S.predict(B, 0.01)["action"] == "positive", "slightly above tie -> positive")
    # temperature is applied: w=4,x=1,T=2 -> sigmoid(2)
    r = S.predict({**B, "w": 4.0, "temperature": 2.0}, 1)
    check(abs(r["p"] - sig(2)) < 1e-15, "temperature scales logit")
    # costs: fn=4, fp=1 -> positive iff p > 0.2
    Bc = {**B, "fn_cost": 4.0, "fp_cost": 1.0}
    check(S.predict(Bc, math.log(0.2 / 0.8) + 0.01)["action"] == "positive", "fn-heavy threshold 0.2 above")
    check(S.predict(Bc, math.log(0.2 / 0.8) - 0.01)["action"] == "negative", "fn-heavy threshold 0.2 below")
    Bf = {**B, "fn_cost": 1.0, "fp_cost": 4.0}
    check(S.predict(Bf, 1.0)["action"] == "negative", "fp-heavy: p=0.73 < 0.8 -> negative")
    check(S.predict(Bf, 1.5)["action"] == "positive", "fp-heavy: p=0.82 > 0.8 -> positive")
    for x in (1e308, -1e308, 1e5, -1e5, 800, -800):
        r = S.predict({**B, "w": 1e10, "temperature": 1e-10}, x)
        check(math.isfinite(r["p"]) and 0 <= r["p"] <= 1 and set(r) == {"p", "action"}, f"finite p at x={x}: {r}")
    check(S.predict(B, -1000)["action"] == "negative" and S.predict(B, 1000)["action"] == "positive",
          "extremes pick sensible actions")
    check(raises(lambda: S.predict(B, float("nan"))), "predict rejects NaN x")

    # --- CLI in fresh process, training file removed ---
    work = os.path.join(tmp, "cli")
    serve = os.path.join(tmp, "serve")
    os.makedirs(work)
    os.makedirs(serve)
    train = os.path.join(work, "training.json")
    art = os.path.join(work, "artifact.json")
    json.dump({"rows": rows, "epochs": 7, "lr": 0.3, "temperature": 1.5, "fn_cost": 3, "fp_cost": 1}, open(train, "w"))
    res = subprocess.run([sys.executable, os.path.join(HERE, "solution.py"), "fit", train, art],
                         capture_output=True, text=True)
    check(res.returncode == 0, f"cli fit ok {res.stderr}")
    res2 = subprocess.run([sys.executable, os.path.join(HERE, "solution.py"), "fit", train, art],
                          capture_output=True, text=True)
    check(res2.returncode != 0, "cli fit refuses overwrite")
    os.remove(train)
    shutil.copy(os.path.join(HERE, "solution.py"), serve)
    shutil.move(art, os.path.join(serve, "artifact.json"))
    shutil.rmtree(work)
    xs = [-3, 0, 0.5, 2, 1e308, -1e308]
    stdin = "".join(json.dumps({"x": x}) + "\n" for x in xs)
    res = subprocess.run([sys.executable, "solution.py", "predict", "artifact.json"], input=stdin,
                         capture_output=True, text=True, cwd=serve, env={"PATH": os.environ.get("PATH", "")})
    lines = res.stdout.splitlines()
    check(res.returncode == 0 and len(lines) == len(xs), f"cli predict {res.stderr}")
    local = {**m, "temperature": 1.5, "fn_cost": 3, "fp_cost": 1}
    for x, line in zip(xs, lines):
        got = json.loads(line)
        check(got == S.predict(local, x), f"cli x={x} -> {got}")
    bad_train = os.path.join(tmp, "bad_training.json")
    json.dump({"rows": rows, "epochs": 7, "lr": 0.3, "temperature": 0, "fn_cost": 3, "fp_cost": 1},
              open(bad_train, "w"))
    bad_art = os.path.join(tmp, "bad_art.json")
    res = subprocess.run([sys.executable, os.path.join(HERE, "solution.py"), "fit", bad_train, bad_art],
                         capture_output=True, text=True)
    check(res.returncode != 0 and not os.path.exists(bad_art), "cli fit rejects temperature=0, no artifact")
finally:
    shutil.rmtree(tmp)

print(f"\n{len(failures)} failure(s)")
sys.exit(1 if failures else 0)
