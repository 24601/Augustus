"""Checks for solution.py: hand-calculated fits, policy boundaries, export/load
failure paths, and fresh-process CLI serving without the training file."""
import json
import math
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import solution as S  # noqa: E402

WORK = os.path.join(HERE, "check_work")
fails = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        fails.append(msg)


def raises(fn, excs=(ValueError,)):
    try:
        fn()
    except excs:
        return True
    return False


def ref_fit(rows, epochs, lr):
    w = b = 0.0
    for _ in range(epochs):
        ps = [1 / (1 + math.exp(-(w * r["x"] + b))) for r in rows]
        gw = sum((p - r["target"]) * r["x"] for p, r in zip(ps, rows)) / len(rows)
        gb = sum(p - r["target"] for p, r in zip(ps, rows)) / len(rows)
        w, b = w - lr * gw, b - lr * gb
    return w, b


shutil.rmtree(WORK, ignore_errors=True)
os.makedirs(WORK)

# --- fit ---
m = S.fit([{"x": 1, "target": 0.8}, {"x": 2, "target": 0.3}], 1, 0.5)
check(set(m) == {"w", "b"}, "fit returns exactly w,b")
check(abs(m["w"] + 0.025) < 1e-15 and abs(m["b"] - 0.025) < 1e-15,
      f"one-step hand calc w=-0.025 b=0.025 got {m}")
check(S.fit([{"x": 1, "target": 1}], 0, 0.1) == {"w": 0.0, "b": 0.0}, "zero epochs -> zeros")
rows = [{"x": x / 3, "target": t} for x, t in zip(range(-6, 7), [0.1, 0.15, 0.2, 0.3, 0.3, 0.45, 0.5, 0.55, 0.6, 0.75, 0.8, 0.8, 0.9])]
m = S.fit(rows, 200, 0.7)
rw, rb = ref_fit(rows, 200, 0.7)
check(abs(m["w"] - rw) < 1e-12 and abs(m["b"] - rb) < 1e-12, "matches reference simultaneous-update GD")
m = S.fit([{"x": 0, "target": 0.7}] * 4, 5000, 1.0)
check(abs(m["b"] - math.log(0.7 / 0.3)) < 1e-9 and m["w"] == 0.0,
      "soft target 0.7 converges to logit(0.7), not hard label")
check(raises(lambda: S.fit([], 1, 0.1)), "empty rows rejected")
check(raises(lambda: S.fit([{"x": 1, "target": 1.2}], 1, 0.1)), "target >1 rejected")
check(raises(lambda: S.fit([{"x": float("nan"), "target": 0.5}], 1, 0.1)), "NaN x rejected")
check(raises(lambda: S.fit([{"x": True, "target": 0.5}], 1, 0.1)), "bool x rejected")
check(raises(lambda: S.fit([{"x": 1, "target": 0.5}], 1, 0)), "lr 0 rejected")
check(raises(lambda: S.fit([{"x": 1, "target": 0.5}], 1.5, 0.1)), "non-int epochs rejected")

# --- export validation ---
model = {"w": 2.0, "b": -1.0}
for bad in [0, -1, float("inf"), float("nan"), True, "1", None]:
    for pos in range(3):
        args = [1.0, 1.0, 1.0]
        args[pos] = bad
        p = os.path.join(WORK, "bad.json")
        ok = raises(lambda: S.export(p, model, *args))
        check(ok and not os.path.exists(p), f"export rejects arg{pos}={bad!r} without creating file")
art = os.path.join(WORK, "a.json")
S.export(art, model, 2.0, 3.0, 1.0)
before = open(art).read()
check(raises(lambda: S.export(art, model, 1.0, 1.0, 1.0), (FileExistsError,)) and open(art).read() == before,
      "export refuses overwrite and leaves artifact intact")
b = S.load(art)
check(all(k in json.loads(before) for k in ("temperature", "fn_cost", "fp_cost")), "top-level policy keys present")

# --- load validation ---
for key, val in [("temperature", None), ("fn_cost", None), ("fp_cost", None), ("temperature", 0),
                 ("fp_cost", -2), ("fn_cost", True), ("temperature", "2")]:
    d = json.loads(before)
    if val is None:
        del d[key]
    else:
        d[key] = val
    p = os.path.join(WORK, f"load_{key}_{val}.json")
    with open(p, "w") as f:
        json.dump(d, f)
    check(raises(lambda: S.load(p), (ValueError, KeyError)), f"load rejects {key}={val!r}")
p = os.path.join(WORK, "nan.json")
with open(p, "w") as f:
    f.write(before.replace('"temperature": 2.0', '"temperature": NaN'))
check(raises(lambda: S.load(p), (ValueError, KeyError)), "load rejects NaN temperature")

# --- predict ---
r = S.predict(b, 0.5)  # logit 0 -> p .5; fn=3 fp=1 -> positive
check(set(r) == {"p", "action"} and r["p"] == 0.5 and r["action"] == "positive", f"p=.5 fn3 fp1 positive {r}")
check(abs(S.predict(b, 1.5)["p"] - 1 / (1 + math.exp(-1.0))) < 1e-15, "temperature divides logit")
tie = {"w": 0.0, "b": 0.0, "temperature": 1.0, "fn_cost": 1.0, "fp_cost": 1.0}
check(S.predict(tie, 7)["action"] == "negative", "exact tie -> negative")
tie2 = dict(tie, fn_cost=3.0, b=math.log(1 / 3))  # threshold p = fp/(fp+fn) = 0.25
p = S.predict(tie2, 0)["p"]
exp_action = "positive" if (1 - p) * 1.0 < p * 3.0 else "negative"
check(S.predict(tie2, 0)["action"] == exp_action, f"near-threshold consistent with expected loss p={p!r}")
check(S.predict(dict(tie2, b=math.log(1 / 3) + 1e-9), 0)["action"] == "positive", "just above threshold positive")
check(S.predict(dict(tie2, b=math.log(1 / 3) - 1e-9), 0)["action"] == "negative", "just below threshold negative")
for x in [1e300, -1e300, 1e6, -1e6, 1e308]:
    r = S.predict(b, x)
    check(math.isfinite(r["p"]) and 0 <= r["p"] <= 1, f"finite p for x={x}: {r}")
check(S.predict(b, -1e6)["action"] == "negative" and S.predict(b, 1e6)["action"] == "positive", "extremes act sensibly")
check(raises(lambda: S.predict(b, float("nan"))), "predict rejects NaN x")

# --- CLI fit + fresh-process serve ---
train = os.path.join(WORK, "training.json")
with open(train, "w") as f:
    json.dump({"rows": rows, "epochs": 300, "lr": 0.5, "temperature": 1.5, "fn_cost": 4, "fp_cost": 1}, f)
cli_art = os.path.join(WORK, "artifact.json")
proc = subprocess.run([sys.executable, os.path.join(HERE, "solution.py"), "fit", train, cli_art],
                      capture_output=True, text=True)
check(proc.returncode == 0 and os.path.exists(cli_art), f"CLI fit ok: {proc.stderr}")
proc2 = subprocess.run([sys.executable, os.path.join(HERE, "solution.py"), "fit", train, cli_art],
                       capture_output=True, text=True)
check(proc2.returncode != 0, "CLI fit refuses existing artifact")
os.remove(train)
serve = os.path.join(WORK, "serve")
os.makedirs(serve)
shutil.copy(os.path.join(HERE, "solution.py"), serve)
shutil.copy(cli_art, serve)
xs = [-2, -0.5, 0, 0.5, 2, 1e300, -1e300]
stdin = "".join(json.dumps({"x": x}) + "\n" for x in xs)
proc = subprocess.run([sys.executable, "solution.py", "predict", "artifact.json"], cwd=serve,
                      input=stdin, capture_output=True, text=True, env={"PATH": os.environ.get("PATH", "")})
lines = proc.stdout.splitlines()
check(proc.returncode == 0 and len(lines) == len(xs), f"fresh serve one line per input rc={proc.returncode} {proc.stderr}")
bundle = S.load(cli_art)
for x, line in zip(xs, lines):
    got = json.loads(line)
    check(got == S.predict(bundle, x), f"fresh-process x={x} -> {got}")
fm = S.fit(rows, 300, 0.5)
check(bundle["w"] == fm["w"] and bundle["b"] == fm["b"], "artifact params equal in-process fit")
proc = subprocess.run([sys.executable, "solution.py", "predict", "artifact.json"], cwd=serve,
                      input='{"x": "a"}\n{"x": 1}\n', capture_output=True, text=True)
out = proc.stdout.splitlines()
check(len(out) == 2 and "error" in json.loads(out[0]) and "p" in json.loads(out[1]) and proc.returncode == 1,
      "invalid input line reported, others still served")

print(f"\n{len(fails)} failures")
sys.exit(1 if fails else 0)
