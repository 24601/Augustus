"""Tiny soft-target logistic classifier: fit, export, load, predict (stdlib only).

Artifact schema (JSON, version 1):
  {
    "format": "soft-logistic-v1",
    "w": float, "b": float,            # raw logistic parameters
    "temperature": float > 0,          # calibrated logit = (w*x + b) / temperature
    "fn_cost": float > 0,              # cost of predicting negative when event is true
    "fp_cost": float > 0,              # cost of predicting positive when event is false
    "tie_action": "negative"
  }
p is the calibrated probability of the positive event. Action minimizes expected
loss: positive costs (1-p)*fp_cost, negative costs p*fn_cost; exact ties -> negative.

CLI:
  python3 solution.py fit training.json artifact.json
  python3 solution.py predict artifact.json < inputs.jsonl > predictions.jsonl
"""
import json
import math
import sys

FORMAT = "soft-logistic-v1"


def _is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _finite(v, name):
    if not _is_number(v) or not math.isfinite(v):
        raise ValueError(f"{name} must be a finite number, got {v!r}")
    return float(v)


def _positive(v, name):
    v = _finite(v, name)
    if v <= 0:
        raise ValueError(f"{name} must be positive, got {v!r}")
    return v


def sigmoid(z):
    """Numerically stable logistic; finite for any finite z, exact limits for +-inf."""
    if math.isnan(z):
        raise ValueError("logit is NaN")
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)


def fit(rows, epochs, lr):
    """Full-batch gradient descent on mean binary cross entropy with soft targets."""
    if isinstance(epochs, bool) or not isinstance(epochs, int) or epochs < 0:
        raise ValueError(f"epochs must be a non-negative integer, got {epochs!r}")
    lr = _positive(lr, "lr")
    data = []
    for i, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f"row {i} must be an object")
        x = _finite(row.get("x"), f"rows[{i}].x")
        t = _finite(row.get("target"), f"rows[{i}].target")
        if not 0.0 <= t <= 1.0:
            raise ValueError(f"rows[{i}].target must be in [0,1], got {t!r}")
        data.append((x, t))
    if not data:
        raise ValueError("rows must be non-empty")
    n = len(data)
    w = 0.0
    b = 0.0
    for _ in range(epochs):
        gw = 0.0
        gb = 0.0
        for x, t in data:
            r = sigmoid(w * x + b) - t  # d(BCE)/d(logit)
            gw += r * x
            gb += r
        w, b = w - lr * gw / n, b - lr * gb / n
        if not (math.isfinite(w) and math.isfinite(b)):
            raise ValueError("training diverged to non-finite parameters")
    return {"w": w, "b": b}


def _validate_bundle(bundle):
    if not isinstance(bundle, dict):
        raise ValueError("artifact must be a JSON object")
    for key in ("temperature", "fn_cost", "fp_cost", "w", "b"):
        if key not in bundle:
            raise KeyError(f"artifact missing required key {key!r}")
    if bundle.get("format", FORMAT) != FORMAT:
        raise ValueError(f"unsupported artifact format {bundle.get('format')!r}")
    return {
        "format": FORMAT,
        "w": _finite(bundle["w"], "w"),
        "b": _finite(bundle["b"], "b"),
        "temperature": _positive(bundle["temperature"], "temperature"),
        "fn_cost": _positive(bundle["fn_cost"], "fn_cost"),
        "fp_cost": _positive(bundle["fp_cost"], "fp_cost"),
        "tie_action": "negative",
    }


def export(path, model, temperature, fn_cost, fp_cost):
    """Write a self-contained artifact; never overwrites an existing path."""
    if not isinstance(model, dict):
        raise ValueError("model must be an object with w and b")
    bundle = _validate_bundle({
        "format": FORMAT,
        "w": model.get("w"),
        "b": model.get("b"),
        "temperature": temperature,
        "fn_cost": fn_cost,
        "fp_cost": fp_cost,
    })
    text = json.dumps(bundle, allow_nan=False, indent=2) + "\n"
    with open(path, "x", encoding="utf-8") as f:  # "x" refuses to overwrite
        f.write(text)
    return bundle


def _reject_constant(name):
    raise ValueError(f"non-finite JSON constant {name} not allowed")


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f, parse_constant=_reject_constant)
    return _validate_bundle(raw)


def predict(bundle, x):
    x = _finite(x, "x")
    z = (bundle["w"] * x + bundle["b"]) / bundle["temperature"]
    p = sigmoid(z)
    loss_pos = (1.0 - p) * bundle["fp_cost"]
    loss_neg = p * bundle["fn_cost"]
    action = "positive" if loss_pos < loss_neg else "negative"
    return {"p": p, "action": action}


def _cli_fit(training_path, artifact_path):
    with open(training_path, "r", encoding="utf-8") as f:
        spec = json.load(f, parse_constant=_reject_constant)
    if not isinstance(spec, dict):
        raise ValueError("training file must be a JSON object")
    for key in ("rows", "epochs", "lr", "temperature", "fn_cost", "fp_cost"):
        if key not in spec:
            raise KeyError(f"training file missing {key!r}")
    # Validate serving policy before spending time on the fit.
    for key in ("temperature", "fn_cost", "fp_cost"):
        _positive(spec[key], key)
    model = fit(spec["rows"], spec["epochs"], spec["lr"])
    export(artifact_path, model, spec["temperature"], spec["fn_cost"], spec["fp_cost"])
    print(json.dumps(model))


def _cli_predict(artifact_path):
    bundle = load(artifact_path)
    failures = 0
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            obj = json.loads(line, parse_constant=_reject_constant)
            if not isinstance(obj, dict) or "x" not in obj:
                raise ValueError('input must be an object {"x": number}')
            out = predict(bundle, obj["x"])
        except ValueError as e:
            failures += 1
            out = {"error": str(e)}
        sys.stdout.write(json.dumps(out) + "\n")
    sys.stdout.flush()
    return 1 if failures else 0


def main(argv):
    if len(argv) == 3 and argv[0] == "fit":
        _cli_fit(argv[1], argv[2])
        return 0
    if len(argv) == 2 and argv[0] == "predict":
        return _cli_predict(argv[1])
    sys.stderr.write(__doc__.split("CLI:", 1)[1])
    return 2


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except (ValueError, KeyError, OSError) as e:
        sys.stderr.write(f"error: {e}\n")
        sys.exit(1)
