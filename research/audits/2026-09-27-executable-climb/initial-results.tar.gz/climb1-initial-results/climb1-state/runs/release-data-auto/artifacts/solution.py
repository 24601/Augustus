"""Build a leakage-safe first-message routing dataset."""
import json
import sys


def _norm(text):
    return " ".join(text.casefold().split())


def _id_key(tid):
    # Keep numeric IDs in numeric order, strings lexicographic; never mix-compare.
    if isinstance(tid, bool):
        return (2, str(tid))
    if isinstance(tid, (int, float)):
        return (0, tid, "")
    return (1, str(tid))


def prepare(rows, train_end, dev_end):
    # 1. First user event per ticket (earliest time, then smallest text).
    first = {}
    for row in rows:
        if row.get("role") != "user":
            continue
        tid = row.get("ticket")
        time = row.get("time")
        if tid is None or time is None:
            continue
        text = row.get("text")
        text = text if isinstance(text, str) else ""
        key = (time, text)
        if tid not in first or key < first[tid][0]:
            first[tid] = (key, row, text)

    # 2. Usability, provisional role, and label availability.
    eligible = []  # (tid, customer, text, label, role_index)
    for tid, ((time, _), row, text) in first.items():
        if not text.strip():
            continue
        label = row.get("label")
        if label is None or row.get("label_status") != "agreed":
            continue
        label_time = row.get("label_time")
        if time < train_end:
            role = 0
            if label_time is None or not label_time < train_end:
                continue
        elif time < dev_end:
            role = 1
            if label_time is None or not label_time < dev_end:
                continue
        else:
            role = 2
        eligible.append((tid, row.get("customer"), text, label, role))

    # 3. Union-find over shared customer or normalized text.
    parent = list(range(len(eligible)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    seen = {}
    for i, (_, customer, text, _, _) in enumerate(eligible):
        keys = [("t", _norm(text))]
        if customer is not None:
            keys.append(("c", json.dumps(customer, sort_keys=True)))
        for k in keys:
            if k in seen:
                a, b = find(i), find(seen[k])
                if a != b:
                    parent[a] = b
            else:
                seen[k] = i

    earliest = {}
    for i, ex in enumerate(eligible):
        r = find(i)
        earliest[r] = min(earliest.get(r, 3), ex[4])

    # 4. Emit only tickets in their component's earliest role.
    names = ("train", "dev", "confirm")
    out = {n: [] for n in names}
    for i, (tid, customer, text, label, role) in enumerate(eligible):
        if role == earliest[find(i)]:
            out[names[role]].append(
                {"id": tid, "customer": customer, "text": text, "label": label}
            )
    for n in names:
        out[n].sort(key=lambda e: _id_key(e["id"]))
    return out


def main():
    args = json.load(sys.stdin)
    result = prepare(args["rows"], args["train_end"], args["dev_end"])
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
