import json
import subprocess
import sys

from solution import prepare


def r(ticket, customer, time, text, label="a", label_time=None, status="agreed",
      role="user", **extra):
    row = {"ticket": ticket, "customer": customer, "time": time, "role": role,
           "text": text, "label": label,
           "label_time": label_time or time, "label_status": status}
    row.update(extra)
    return row


TE, DE = "2024-02-01", "2024-03-01"


def ids(out):
    return {k: [e["id"] for e in v] for k, v in out.items()}


def test_first_event_and_rejections():
    rows = [
        r("T1", "c1", "2024-01-05", "later reply", "x"),
        r("T1", "c1", "2024-01-02", "  ", "x"),          # unusable first -> reject
        r("T2", "c2", "2024-01-03", "b text", "L2"),
        r("T2", "c2", "2024-01-03", "a text", "L2a"),     # tie: smaller text wins
        r("T2", "c2", "2024-01-01", "staff hi", role="staff"),
        r("T3", "c3", "2024-01-03", "null label", label=None),
        r("T4", "c4", "2024-01-03", "disputed", status="disputed"),
        r("T5", "c5", "2024-01-03", "  keep  me ", resolution="leak"),
    ]
    out = prepare(rows, TE, DE)
    assert ids(out) == {"train": ["T2", "T5"], "dev": [], "confirm": []}, out
    t2 = out["train"][0]
    assert t2 == {"id": "T2", "customer": "c2", "text": "a text", "label": "L2a"}
    assert out["train"][1]["text"] == "  keep  me "
    assert set(out["train"][1]) == {"id", "customer", "text", "label"}


def test_label_availability():
    rows = [
        r("A", "a", "2024-01-10", "t a", label_time=TE),           # not < TE
        r("B", "b", "2024-01-10", "t b", label_time="2024-01-31"),
        r("C", "c", "2024-02-10", "t c", label_time=DE),           # not < DE
        r("D", "d", "2024-02-10", "t d", label_time="2024-02-28"),
        r("E", "e", "2024-03-10", "t e", label_time="2025-01-01"),  # confirm ok
        r("F", "f", TE, "t f", label_time="2024-02-02"),            # dev boundary
        r("G", "g", DE, "t g"),                                     # confirm boundary
    ]
    out = prepare(rows, TE, DE)
    assert ids(out) == {"train": ["B"], "dev": ["D", "F"], "confirm": ["E", "G"]}, out


def test_components():
    rows = [
        # Component 1: train X links dev Y via customer; Y links confirm Z via text.
        r("X", "cx", "2024-01-05", "hello"),
        r("Y", "cx", "2024-02-05", "Refund   PLEASE"),
        r("Z", "cz", "2024-03-05", "refund\tplease"),
        # Same-role members remain separate.
        r("X2", "cx", "2024-01-06", "other"),
        # Excluded (unavailable label) train ticket must not bind dev ticket.
        r("P", "cp", "2024-01-05", "p", label_time="2024-05-01"),
        r("Q", "cp", "2024-02-05", "q"),
        # Dev + confirm by text only.
        r("M", "m1", "2024-02-07", "Dup"),
        r("N", "m2", "2024-04-07", " dup "),
    ]
    out = prepare(rows, TE, DE)
    assert ids(out) == {"train": ["X", "X2"], "dev": ["M", "Q"], "confirm": []}, out


def test_cli():
    payload = {"rows": [r(2, "c", "2024-01-01", "hi"), r(10, "d", "2024-01-01", "yo")],
               "train_end": TE, "dev_end": DE}
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(payload),
                       capture_output=True, text=True, check=True)
    out = json.loads(p.stdout)
    assert [e["id"] for e in out["train"]] == [2, 10], out


for name, fn in list(globals().items()):
    if name.startswith("test_"):
        fn()
        print("ok", name)
