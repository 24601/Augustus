"""Exact experiment planning: learning-curve feasibility and deployment selection.

CLI: read one JSON object from stdin with ``op`` ("curve" or "select") plus the
named function arguments; write the JSON result to stdout.
"""
import json
import math
import sys
from fractions import Fraction


def _is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def curve(rows, folds, sizes):
    ids = {}
    labels = []
    for row in rows:
        row_id = row["id"]
        if row_id in ids:
            raise ValueError("duplicate row id: %r" % (row_id,))
        ids[row_id] = row
        if row["label"] not in labels:
            labels.append(row["label"])
    labels.sort()

    requested = sorted({s for s in sizes if _is_int(s) and s > 0})

    report = []
    for fold in folds:
        held_groups = set()
        for row_id in fold:
            if row_id not in ids:
                raise ValueError("unknown row id: %r" % (row_id,))
            held_groups.add(ids[row_id]["group"])
        available = {label: 0 for label in labels}
        for row in rows:
            if row["group"] not in held_groups:
                available[row["label"]] += 1
        # With no classes at all there is nothing to train on.
        limit = min(available.values()) if available else 0
        report.append({
            "available": available,
            "sizes": [s for s in requested if s <= limit],
        })
    return report


def _exact(value):
    if isinstance(value, bool):
        return Fraction(int(value))
    return Fraction(value)


def _future_fit_cost(candidate):
    fit = _exact(candidate["fit_cost"])
    paid = candidate.get("already_paid", False)
    if paid is None or isinstance(paid, bool):
        return Fraction(0) if paid else fit
    # Numeric already_paid: only the unpaid remainder is still owed.
    return max(fit - _exact(paid), Fraction(0))


def select(candidates, horizon, fn_cost, fp_cost, max_latency):
    horizon = _exact(horizon)
    fn_cost = _exact(fn_cost)
    fp_cost = _exact(fp_cost)
    best = None
    for c in candidates:
        if max_latency is not None and _exact(c["latency_ms"]) > _exact(max_latency):
            continue
        n = _exact(c["n"])
        error_cost = horizon * (_exact(c["fn"]) * fn_cost + _exact(c["fp"]) * fp_cost) / n
        total = error_cost + _future_fit_cost(c)
        key = (total, c["name"])
        if best is None or key < best:
            best = key
    if best is None:
        return None
    total, name = best
    out = int(total) if total.denominator == 1 else float(total)
    if isinstance(out, float) and not math.isfinite(out):
        raise ValueError("total cost is not finite")
    return {"name": name, "total_cost": out}


def main():
    try:
        payload = json.load(sys.stdin)
        op = payload.get("op")
        args = {k: v for k, v in payload.items() if k != "op"}
        if op == "curve":
            result = curve(args["rows"], args["folds"], args["sizes"])
        elif op == "select":
            result = select(
                args["candidates"],
                args["horizon"],
                args["fn_cost"],
                args["fp_cost"],
                args.get("max_latency"),
            )
        else:
            raise ValueError("unknown op: %r" % (op,))
    except (ValueError, KeyError, TypeError) as exc:
        json.dump({"error": "%s: %s" % (type(exc).__name__, exc)}, sys.stdout)
        sys.stdout.write("\n")
        return 1
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
