"""Boundary checks for solution.py (direct calls + CLI via subprocess)."""
import json
import subprocess
import sys

from solution import curve, select

ROWS = [
    {"id": "a1", "group": "g1", "label": "pos"},
    {"id": "a2", "group": "g1", "label": "neg"},
    {"id": "b1", "group": "g2", "label": "pos"},
    {"id": "b2", "group": "g2", "label": "neg"},
    {"id": "c1", "group": "g3", "label": "pos"},
    {"id": "c2", "group": "g3", "label": "neg"},
    {"id": "d1", "group": "g4", "label": "neg"},
    {"id": "e1", "group": "g5", "label": "rare"},
]


def expect_error(fn, *args):
    try:
        fn(*args)
    except ValueError:
        return
    raise AssertionError("expected ValueError")


# Group leakage: holding out a1 excludes a2 too.
out = curve(ROWS, [["a1"]], [1, 2, 3])
assert out == [{"available": {"neg": 3, "pos": 2, "rare": 1}, "sizes": [1]}], out

# Holding out the only 'rare' row yields zero for that label and no sizes.
out = curve(ROWS, [["e1"]], [1, 2])
assert out[0]["available"]["rare"] == 0 and out[0]["sizes"] == [], out

# Empty fold: whole pool; sizes deduped, sorted, bool/float/non-positive dropped.
out = curve(ROWS, [[]], [3, 1, 1, True, 1.0, 0, -2, "2", None, 2])
assert out == [{"available": {"neg": 4, "pos": 3, "rare": 1}, "sizes": [1]}], out

# Without the rare class, larger sizes become achievable; exact boundary.
rows2 = [r for r in ROWS if r["label"] != "rare"]
out = curve(rows2, [["d1"], ["a1", "b2"], []], [2, 3, 4])
assert out[0] == {"available": {"neg": 3, "pos": 3}, "sizes": [2, 3]}, out
assert out[1] == {"available": {"neg": 2, "pos": 1}, "sizes": []}, out
assert out[2] == {"available": {"neg": 4, "pos": 3}, "sizes": [2, 3]}, out

# Repeated IDs within a fold are fine; unknown / duplicate row IDs rejected.
assert curve(rows2, [["a1", "a1"]], [1])[0]["sizes"] == [1]
expect_error(curve, ROWS, [["zz"]], [1])
expect_error(curve, ROWS + [{"id": "a1", "group": "gx", "label": "pos"}], [], [1])
assert curve(ROWS, [], [1]) == []

# --- select ---
base = {"n": 100, "latency_ms": 10, "fit_cost": 0, "already_paid": False}
C = [
    dict(base, name="cheap_fit", fn=10, fp=10, fit_cost=50),
    dict(base, name="sunk", fn=10, fp=10, fit_cost=500, already_paid=True),
    dict(base, name="slow", fn=0, fp=0, latency_ms=100),
]
# horizon 1000: errors = 1000*(0.1*5+0.1*1) = 600; sunk fit not charged.
r = select(C, 1000, 5, 1, 50)
assert r == {"name": "sunk", "total_cost": 600}, r
# Latency exactly at the limit is feasible.
r = select(C, 1000, 5, 1, 100)
assert r == {"name": "slow", "total_cost": 0}, r
# None feasible -> None.
assert select(C, 1000, 5, 1, 5) is None
assert select([], 1, 1, 1, 10) is None
# Ties broken lexicographically.
T = [dict(base, name="b", fn=1, fp=0), dict(base, name="a", fn=0, fp=1)]
assert select(T, 10, 3, 3, 10)["name"] == "a"
# Fractional rates preserved: 1/3 rate * horizon 3 * cost 1 = 1 exactly.
r = select([dict(base, name="x", n=3, fn=1, fp=0)], 3, 1, 0, 10)
assert r == {"name": "x", "total_cost": 1}, r
# Non-integer money is not rounded.
r = select([dict(base, name="x", n=3, fn=1, fp=0)], 1, 1, 0, 10)
assert abs(r["total_cost"] - 1 / 3) < 1e-15, r
r = select([dict(base, name="x", fn=1, fp=0, fit_cost=0.25)], 1, 0.5, 0, 10)
assert r["total_cost"] == 0.255, r
# Horizon 0: only future fit cost matters.
H = [dict(base, name="a", fn=50, fp=50, fit_cost=10), dict(base, name="b", fn=0, fp=0, fit_cost=20)]
assert select(H, 0, 9, 9, 10) == {"name": "a", "total_cost": 10}

# --- CLI ---
def cli(payload):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(payload),
                       capture_output=True, text=True)
    return p.returncode, json.loads(p.stdout)

code, res = cli({"op": "select", "candidates": C, "horizon": 1000, "fn_cost": 5,
                 "fp_cost": 1, "max_latency": 50})
assert code == 0 and res == {"name": "sunk", "total_cost": 600}, res
code, res = cli({"op": "select", "candidates": C, "horizon": 1, "fn_cost": 1,
                 "fp_cost": 1, "max_latency": 1})
assert code == 0 and res is None, res
code, res = cli({"op": "curve", "rows": ROWS, "folds": [["a1"]], "sizes": [1, 2]})
assert code == 0 and res == [{"available": {"neg": 3, "pos": 2, "rare": 1}, "sizes": [1]}], res
code, res = cli({"op": "curve", "rows": ROWS, "folds": [["nope"]], "sizes": [1]})
assert code == 1 and "error" in res, res
code, res = cli({"op": "bogus"})
assert code == 1 and "error" in res, res

print("all checks passed")
