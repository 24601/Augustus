"""Exact experiment-planning helpers: learning-curve sizes and cost-based model selection.

CLI: JSON on stdin with "op" ("curve" | "select") plus named arguments; JSON result on stdout.
"""
import json
import sys
from fractions import Fraction


def _is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def curve(rows, folds, sizes):
    by_id = {}
    labels = []
    for row in rows:
        rid = row["id"]
        if rid in by_id:
            raise ValueError(f"duplicate row id: {rid!r}")
        by_id[rid] = row
        if row["label"] not in labels:
            labels.append(row["label"])

    requested = sorted({s for s in sizes if _is_int(s) and s > 0})

    report = []
    for fold in folds:
        unknown = [rid for rid in fold if rid not in by_id]
        if unknown:
            raise ValueError(f"unknown row id(s) in fold: {unknown!r}")
        held_groups = {by_id[rid]["group"] for rid in fold}
        available = {label: 0 for label in labels}
        for row in rows:
            if row["group"] not in held_groups:
                available[row["label"]] += 1
        # A size is achievable only if every class can supply it without oversampling.
        limit = min(available.values()) if available else 0
        report.append({"available": available, "sizes": [s for s in requested if s <= limit]})
    return report


def select(candidates, horizon, fn_cost, fp_cost, max_latency):
    horizon, fn_cost, fp_cost = Fraction(horizon), Fraction(fn_cost), Fraction(fp_cost)
    best = None
    for cand in candidates:
        if max_latency is not None and cand["latency_ms"] > max_latency:
            continue
        n = Fraction(cand["n"])
        error_rate_cost = (Fraction(cand["fn"]) * fn_cost + Fraction(cand["fp"]) * fp_cost) / n
        fit = Fraction(0) if cand["already_paid"] else Fraction(cand["fit_cost"])
        total = horizon * error_rate_cost + fit
        key = (total, cand["name"])
        if best is None or key < best:
            best = key
    if best is None:
        return None
    return {"name": best[1], "total_cost": float(best[0])}


OPS = {"curve": curve, "select": select}


def main():
    payload = json.load(sys.stdin)
    args = dict(payload)
    op = args.pop("op", None)
    if op not in OPS:
        print(json.dumps({"error": f"unknown op: {op!r}"}))
        return 2
    try:
        result = OPS[op](**args)
    except ValueError as exc:
        print(json.dumps({"error": str(exc)}))
        return 1
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    sys.exit(main())
