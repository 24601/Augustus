"""Hand-calculated boundary checks for solution.py (functions and CLI)."""
import json
import subprocess
import sys

from solution import curve, select

ROWS = [
    {"id": "a1", "group": "g1", "label": "pos"},
    {"id": "a2", "group": "g1", "label": "neg"},
    {"id": "b1", "group": "g2", "label": "pos"},
    {"id": "b2", "group": "g2", "label": "pos"},
    {"id": "c1", "group": "g3", "label": "neg"},
    {"id": "c2", "group": "g3", "label": "neg"},
    {"id": "d1", "group": "g4", "label": "rare"},
]


def expect_raises(fn, *args):
    try:
        fn(*args)
    except ValueError:
        return
    raise AssertionError("expected ValueError")


# Group leakage: holding out a1 also removes a2 (same group g1).
out = curve(ROWS, [["a1"]], [1, 2, 3])
assert out == [{"available": {"pos": 2, "neg": 2, "rare": 1}, "sizes": [1]}], out

# Zero-count label must appear and block all sizes; order preserved across folds.
out = curve(ROWS, [["d1"], ["b1", "c1"], []], [2, 1, 1, 0, -3, True, 2.0, 1.5, "2", None, 99])
assert out[0] == {"available": {"pos": 3, "neg": 3, "rare": 0}, "sizes": []}, out
assert out[1] == {"available": {"pos": 1, "neg": 1, "rare": 1}, "sizes": [1]}, out
assert out[2] == {"available": {"pos": 3, "neg": 3, "rare": 1}, "sizes": [1]}, out

# Exact boundary: size equal to smallest class count is achievable, +1 is not.
rows2 = [{"id": f"r{i}", "group": f"g{i}", "label": "x" if i < 3 else "y"} for i in range(7)]
out = curve(rows2, [["r0"]], [2, 3, 4])
assert out == [{"available": {"x": 2, "y": 4}, "sizes": [2]}], out

# Errors: duplicate ids, unknown held-out ids.
expect_raises(curve, ROWS + [{"id": "a1", "group": "g9", "label": "pos"}], [], [1])
expect_raises(curve, ROWS, [["a1"], ["zzz"]], [1])
assert curve(ROWS, [], [1]) == []

C = [
    {"name": "b", "n": 3, "fn": 1, "fp": 0, "latency_ms": 10, "fit_cost": 50, "already_paid": True},
    {"name": "a", "n": 3, "fn": 0, "fp": 1, "latency_ms": 10, "fit_cost": 0, "already_paid": False},
    {"name": "fast_bad", "n": 3, "fn": 3, "fp": 0, "latency_ms": 1, "fit_cost": 0, "already_paid": False},
    {"name": "slow", "n": 3, "fn": 0, "fp": 0, "latency_ms": 11, "fit_cost": 0, "already_paid": False},
]
# b: 300 * (1/3)*1 + 0 (sunk) = 100; a: 300*(1/3)*1 + 0 = 100 -> tie, "a" wins lexicographically.
# slow is perfect but latency 11 > 10; latency == max is allowed.
assert select(C, 300, 1, 1, 10) == {"name": "a", "total_cost": 100.0}
# Fractional rates must not be rounded: 1/3 * 1 * 1 = 0.333...
r = select(C[:1], 1, 1, 1, 10)
assert r == {"name": "b", "total_cost": 1 / 3}, r
# Unpaid fit cost is charged: b not paid -> 150 vs a 100.
unpaid = [dict(C[0], already_paid=False, name="aa")] + C[1:2]
assert select(unpaid, 300, 1, 1, 10) == {"name": "a", "total_cost": 100.0}
# Unequal costs flip the choice: FN expensive favors a (fp=1).
assert select(C[:2], 300, 10, 1, 10)["name"] == "a"
assert select(C[:2], 300, 1, 10, 10) == {"name": "b", "total_cost": 100.0}
# Zero horizon: only future fit cost matters.
assert select(unpaid, 0, 1, 1, 10) == {"name": "a", "total_cost": 0.0}
# None feasible.
assert select(C, 300, 1, 1, 0) is None
assert select([], 1, 1, 1, 10) is None


def cli(payload):
    proc = subprocess.run([sys.executable, "solution.py"], input=json.dumps(payload),
                          capture_output=True, text=True)
    return proc.returncode, json.loads(proc.stdout)


assert cli({"op": "select", "candidates": C, "horizon": 300, "fn_cost": 1, "fp_cost": 1,
            "max_latency": 10}) == (0, {"name": "a", "total_cost": 100.0})
assert cli({"op": "select", "candidates": C, "horizon": 1, "fn_cost": 1, "fp_cost": 1,
            "max_latency": 0}) == (0, None)
assert cli({"op": "curve", "rows": ROWS, "folds": [["a1"]], "sizes": [1, 2]}) == (
    0, [{"available": {"pos": 2, "neg": 2, "rare": 1}, "sizes": [1]}])
code, body = cli({"op": "curve", "rows": ROWS, "folds": [["nope"]], "sizes": [1]})
assert code == 1 and "error" in body
code, body = cli({"op": "bogus"})
assert code == 2 and "error" in body

print("all checks passed")
