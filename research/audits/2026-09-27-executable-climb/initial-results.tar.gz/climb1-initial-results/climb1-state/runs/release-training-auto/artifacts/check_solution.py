"""Checks for solution.py: fitting math, export/load policy, prediction, fresh-process CLI."""
import json
import math
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import solution as S  # noqa: E402

WORK = os.path.join(HERE, "check_work")
shutil.rmtree(WORK, ignore_errors=True)
os.makedirs(WORK)
failures = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        failures.append(msg)


def raises(fn, excs=(ValueError,)):
    try:
        fn()
    except excs:
        return True
    except Exception as e:  # wrong type
        print("   unexpected", type(e).__name__, e)
        return False
    return False


# --- fit: one step by hand. At w=b=0, p=0.5 for all rows.
rows = [{"x": 1.0, "target": 0.9}, {"x": -2.0, "target": 0.2}, {"x": 3.0, "target": 0.6}]
m = S.fit(rows, 1, 0.5)
gw = ((0.5 - 0.9) * 1 + (0.5 - 0.2) * -2 + (0.5 - 0.6) * 3) / 3
gb = ((0.5 - 0.9) + (0.5 - 0.2) + (0.5 - 0.6)) / 3
check(set(m) == {"w", "b"}, "fit returns exactly w,b")
check(abs(m["w"] + 0.5 * gw) < 1e-15 and abs(m["b"] + 0.5 * gb) < 1e-15, "one-step gradient matches hand calc")

# Two steps: second step must use old w,b simultaneously.
def ref(rows, epochs, lr):
    w = b = 0.0
    for _ in range(epochs):
        ps = [1 / (1 + math.exp(-(w * r["x"] + b))) for r in rows]
        dw = sum((p - r["target"]) * r["x"] for p, r in zip(ps, rows)) / len(rows)
        db = sum(p - r["target"] for p, r in zip(ps, rows)) / len(rows)
        w, b = w - lr * dw, b - lr * db
    return w, b

w2, b2 = ref(rows, 7, 0.3)
m7 = S.fit(rows, 7, 0.3)
check(abs(m7["w"] - w2) < 1e-12 and abs(m7["b"] - b2) < 1e-12, "7 epochs match simultaneous-update reference")
check(S.fit(rows, 0, 0.1) == {"w": 0.0, "b": 0.0}, "0 epochs -> zero init")

# Soft targets: constant x=0 target 0.7 -> b -> logit(0.7), not a hard-label fit.
m = S.fit([{"x": 0, "target": 0.7}] * 4, 5000, 1.0)
check(abs(m["b"] - math.log(0.7 / 0.3)) < 1e-6 and m["w"] == 0.0, "soft target converges to logit(0.7)")
check(raises(lambda: S.fit(rows, 1, 0)), "lr=0 rejected")
check(raises(lambda: S.fit([{"x": 1, "target": 1.5}], 1, 0.1)), "target>1 rejected")
check(raises(lambda: S.fit([{"x": float("nan"), "target": 0.5}], 1, 0.1)), "nan x rejected")

# --- export validation
model = {"w": 2.0, "b": -1.0}
for bad in [0, -1, float("inf"), float("nan"), True, "1", None]:
    for pos in range(3):
        args = [1.0, 1.0, 1.0]
        args[pos] = bad
        p = os.path.join(WORK, "bad.json")
        ok = raises(lambda: S.export(p, model, *args))
        check(ok and not os.path.exists(p), f"export rejects {['temperature','fn_cost','fp_cost'][pos]}={bad!r} without creating file")

art = os.path.join(WORK, "a.json")
S.export(art, model, 2.0, 3.0, 1.0)
before = open(art).read()
check(raises(lambda: S.export(art, model, 1.0, 1.0, 1.0), (FileExistsError,)) and open(art).read() == before,
      "export refuses overwrite")
b = S.load(art)
check(all(k in b for k in ("temperature", "fn_cost", "fp_cost")), "bundle has top-level policy keys")

# --- load rejects missing/invalid policy
for key in ("temperature", "fn_cost", "fp_cost"):
    for mutate in ("delete", 0, -2, True, "3", None):
        d = dict(b)
        if mutate == "delete":
            del d[key]
        else:
            d[key] = mutate
        p = os.path.join(WORK, f"bad_{key}_{mutate}.json")
        with open(p, "w") as f:
            json.dump(d, f)
        check(raises(lambda: S.load(p), (ValueError, KeyError)), f"load rejects {key} {mutate!r}")
p = os.path.join(WORK, "bad_inf.json")
with open(p, "w") as f:
    f.write(open(art).read().replace('"temperature": 2.0', '"temperature": Infinity'))
check(raises(lambda: S.load(p), (ValueError, KeyError)), "load rejects Infinity temperature")

# --- predict
r = S.predict(b, 0.5)  # logit (1-1)/2 = 0 -> p=0.5; pos cost 0.5*1, neg cost 0.5*3 -> positive
check(set(r) == {"p", "action"} and r["p"] == 0.5 and r["action"] == "positive", "cost-sensitive action at p=0.5")
check(abs(S.predict(b, 1.5)["p"] - 1 / (1 + math.exp(-1.0))) < 1e-15, "temperature applied to logit")
tie = {"format": S.FORMAT, "w": 0.0, "b": 0.0, "temperature": 1.0, "fn_cost": 2.0, "fp_cost": 2.0}
check(S.predict(tie, 5)["action"] == "negative", "exact tie -> negative")
# threshold fp/(fp+fn) = 0.75 with fn=1, fp=3: p=0.75 exactly is a tie
tie2 = dict(tie, b=math.log(3.0), fn_cost=1.0, fp_cost=3.0)
pp = S.predict(tie2, 0)["p"]
print("   p at log(3):", pp)
check(S.predict(dict(tie2, b=math.log(3.0) + 1e-6), 0)["action"] == "positive", "just above threshold -> positive")
check(S.predict(dict(tie2, b=math.log(3.0) - 1e-6), 0)["action"] == "negative", "just below threshold -> negative")
for x in (1e300, -1e300, 1e308, -1e308):
    big = dict(tie, w=1e10, temperature=1e-5)
    r = S.predict(big, x)
    check(math.isfinite(r["p"]) and 0 <= r["p"] <= 1, f"finite p for huge logit x={x}")
big = dict(tie, b=-800.0)
check(S.predict(big, 0)["p"] >= 0 and S.predict(dict(tie, b=800.0), 0)["p"] == 1.0, "no overflow at +-800")

# --- CLI, fresh process, training file removed, isolated dir with only solution.py + artifact
train_dir = os.path.join(WORK, "train")
serve_dir = os.path.join(WORK, "serve")
os.makedirs(train_dir)
os.makedirs(serve_dir)
shutil.copy(os.path.join(HERE, "solution.py"), train_dir)
tj = os.path.join(train_dir, "training.json")
with open(tj, "w") as f:
    json.dump({"rows": rows, "epochs": 200, "lr": 0.1, "temperature": 1.5, "fn_cost": 4.0, "fp_cost": 1.0}, f)
cp = subprocess.run([sys.executable, "solution.py", "fit", "training.json", "artifact.json"],
                    cwd=train_dir, capture_output=True, text=True)
check(cp.returncode == 0, f"CLI fit ok ({cp.stderr.strip()})")
cp2 = subprocess.run([sys.executable, "solution.py", "fit", "training.json", "artifact.json"],
                     cwd=train_dir, capture_output=True, text=True)
check(cp2.returncode != 0, "CLI fit refuses overwrite")
os.remove(tj)
shutil.copy(os.path.join(train_dir, "solution.py"), serve_dir)
shutil.copy(os.path.join(train_dir, "artifact.json"), serve_dir)
shutil.rmtree(train_dir)
check(sorted(os.listdir(serve_dir)) == ["artifact.json", "solution.py"], "serve dir has only solution.py + artifact")
xs = [-3, 0, 0.5, 2, 1e308, -1e308]
inp = "".join(json.dumps({"x": x}) + "\n" for x in xs)
cp = subprocess.run([sys.executable, "solution.py", "predict", "artifact.json"], cwd=serve_dir,
                    input=inp, capture_output=True, text=True)
lines = cp.stdout.splitlines()
check(cp.returncode == 0 and len(lines) == len(xs), f"CLI predict one line per input ({cp.stderr.strip()})")
wr, br = ref(rows, 200, 0.1)
for x, line in zip(xs, lines):
    got = json.loads(line)
    z = (wr * x + br) / 1.5
    exp = S.sigmoid(z)
    act = "positive" if exp * 4.0 > (1 - exp) * 1.0 else "negative"
    check(set(got) == {"p", "action"} and abs(got["p"] - exp) < 1e-12 and got["action"] == act,
          f"CLI x={x}: {got}")
cp = subprocess.run([sys.executable, "solution.py", "predict", "artifact.json"], cwd=serve_dir,
                    input='{"x": NaN}\n', capture_output=True, text=True)
check(cp.returncode != 0, "CLI predict rejects NaN input")

print()
print("FAILURES:", len(failures))
sys.exit(1 if failures else 0)
