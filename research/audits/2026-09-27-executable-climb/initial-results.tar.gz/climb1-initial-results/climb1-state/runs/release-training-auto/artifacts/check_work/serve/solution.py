#!/usr/bin/env python3
"""Tiny soft-target logistic classifier: fit, export, load, predict (stdlib only).

Artifact schema (JSON object, format "soft-logistic-v1"):
    {
      "format": "soft-logistic-v1",
      "w": float, "b": float,          # raw logit = w*x + b
      "temperature": float > 0,        # calibrated logit = (w*x + b) / temperature
      "fn_cost": float > 0,            # cost of predicting negative when truth is positive
      "fp_cost": float > 0,            # cost of predicting positive when truth is negative
      "decision": "positive iff p*fn_cost > (1-p)*fp_cost; ties -> negative"
    }

CLI:
    python3 solution.py fit training.json artifact.json
    python3 solution.py predict artifact.json < inputs.jsonl > predictions.jsonl
"""

import json
import math
import sys

FORMAT = "soft-logistic-v1"
DECISION_RULE = "positive iff p*fn_cost > (1-p)*fp_cost; ties -> negative"


def _is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _finite(v, name):
    if not _is_number(v) or not math.isfinite(v):
        raise ValueError(f"{name} must be a finite number, got {v!r}")
    return float(v)


def _positive(v, name):
    v = _finite(v, name)
    if v <= 0:
        raise ValueError(f"{name} must be positive, got {v!r}")
    return v


def sigmoid(z):
    """Numerically stable logistic; finite for any finite (or infinite) z."""
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)


def fit(rows, epochs, lr):
    """Full-batch gradient descent on mean BCE with soft targets. Returns {"w", "b"}."""
    if isinstance(epochs, bool) or not isinstance(epochs, int) or epochs < 0:
        raise ValueError(f"epochs must be a non-negative integer, got {epochs!r}")
    lr = _positive(lr, "lr")
    rows = list(rows)
    if not rows:
        raise ValueError("rows must be non-empty")
    data = []
    for i, row in enumerate(rows):
        try:
            x, t = row["x"], row["target"]
        except (TypeError, KeyError):
            raise ValueError(f"row {i} must be an object with 'x' and 'target'")
        x = _finite(x, f"rows[{i}].x")
        t = _finite(t, f"rows[{i}].target")
        if not 0.0 <= t <= 1.0:
            raise ValueError(f"rows[{i}].target must be in [0, 1], got {t!r}")
        data.append((x, t))

    n = len(data)
    w = 0.0
    b = 0.0
    for _ in range(epochs):
        gw = 0.0
        gb = 0.0
        for x, t in data:
            r = sigmoid(w * x + b) - t  # d(BCE)/d(logit)
            gw += r * x
            gb += r
        w, b = w - lr * gw / n, b - lr * gb / n
        if not (math.isfinite(w) and math.isfinite(b)):
            raise ValueError("training diverged to non-finite parameters")
    return {"w": w, "b": b}


def _validate_bundle(bundle):
    if not isinstance(bundle, dict):
        raise ValueError("artifact must be a JSON object")
    if bundle.get("format") != FORMAT:
        raise ValueError(f"unsupported artifact format {bundle.get('format')!r}")
    for key in ("w", "b", "temperature", "fn_cost", "fp_cost"):
        if key not in bundle:
            raise KeyError(f"artifact missing required key {key!r}")
    _finite(bundle["w"], "w")
    _finite(bundle["b"], "b")
    for key in ("temperature", "fn_cost", "fp_cost"):
        _positive(bundle[key], key)
    return bundle


def _reject_constant(name):
    raise ValueError(f"non-finite JSON constant {name} not allowed")


def export(path, model, temperature, fn_cost, fp_cost):
    """Write a self-contained JSON artifact; never overwrites an existing path."""
    if not isinstance(model, dict):
        raise ValueError("model must be a dict with 'w' and 'b'")
    bundle = {
        "format": FORMAT,
        "w": _finite(model.get("w"), "w"),
        "b": _finite(model.get("b"), "b"),
        "temperature": _positive(temperature, "temperature"),
        "fn_cost": _positive(fn_cost, "fn_cost"),
        "fp_cost": _positive(fp_cost, "fp_cost"),
        "decision": DECISION_RULE,
    }
    text = json.dumps(bundle, allow_nan=False, indent=2) + "\n"
    with open(path, "x", encoding="utf-8") as f:  # "x" refuses to overwrite
        f.write(text)
    return bundle


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        bundle = json.load(f, parse_constant=_reject_constant)
    return _validate_bundle(bundle)


def predict(bundle, x):
    """Return {"p": calibrated probability, "action": "positive"|"negative"}."""
    x = _finite(x, "x")
    z = (bundle["w"] * x + bundle["b"]) / bundle["temperature"]
    if math.isnan(z):
        raise ValueError(f"logit is undefined for x={x!r}")
    p = sigmoid(z)
    # Expected loss: act positive -> (1-p)*fp_cost; act negative -> p*fn_cost.
    positive = p * bundle["fn_cost"] > (1.0 - p) * bundle["fp_cost"]
    return {"p": p, "action": "positive" if positive else "negative"}


def _cmd_fit(training_path, artifact_path):
    with open(training_path, "r", encoding="utf-8") as f:
        cfg = json.load(f, parse_constant=_reject_constant)
    if not isinstance(cfg, dict):
        raise ValueError("training file must be a JSON object")
    for key in ("rows", "epochs", "lr", "temperature", "fn_cost", "fp_cost"):
        if key not in cfg:
            raise KeyError(f"training file missing {key!r}")
    # Validate policy before spending time on training.
    for key in ("temperature", "fn_cost", "fp_cost"):
        _positive(cfg[key], key)
    model = fit(cfg["rows"], cfg["epochs"], cfg["lr"])
    export(artifact_path, model, cfg["temperature"], cfg["fn_cost"], cfg["fp_cost"])


def _cmd_predict(artifact_path, stdin, stdout):
    bundle = load(artifact_path)
    for lineno, line in enumerate(stdin, 1):
        if not line.strip():
            continue
        try:
            obj = json.loads(line, parse_constant=_reject_constant)
            if not isinstance(obj, dict) or "x" not in obj:
                raise ValueError("expected an object with 'x'")
            result = predict(bundle, obj["x"])
        except (ValueError, TypeError) as e:
            raise ValueError(f"input line {lineno}: {e}")
        stdout.write(json.dumps(result, allow_nan=False) + "\n")
        stdout.flush()


def main(argv):
    usage = ("usage: solution.py fit training.json artifact.json\n"
             "       solution.py predict artifact.json < inputs.jsonl")
    if len(argv) == 3 and argv[0] == "fit":
        run = lambda: _cmd_fit(argv[1], argv[2])
    elif len(argv) == 2 and argv[0] == "predict":
        run = lambda: _cmd_predict(argv[1], sys.stdin, sys.stdout)
    else:
        print(usage, file=sys.stderr)
        return 2
    try:
        run()
    except (ValueError, KeyError, OSError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
