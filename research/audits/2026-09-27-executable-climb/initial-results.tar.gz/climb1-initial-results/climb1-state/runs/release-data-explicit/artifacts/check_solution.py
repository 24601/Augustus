"""Representative checks for solution.prepare and its CLI."""
import json
import subprocess
import sys

from solution import prepare

TE, DE = "2026-02-01", "2026-03-01"


def r(ticket, customer, time, text, label="billing", label_time="2026-01-15",
      status="agreed", role="user", **extra):
    row = dict(ticket=ticket, customer=customer, time=time, role=role, text=text,
               label=label, label_time=label_time, label_status=status)
    row.update(extra)
    return row


def ids(out):
    return {k: [e["id"] for e in v] for k, v in out.items()}


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        check.failed = True


check.failed = False

# First user event; staff ignored; later reply can't rescue unusable first event.
rows = [
    r("t1", "c1", "2026-01-05", "later reply", label="x"),
    r("t1", "c1", "2026-01-02", "   ", label="x"),
    r("t2", "c2", "2026-01-01", "staff first", role="staff"),
    r("t2", "c2", "2026-01-03", "  Need help\n", resolution="secret"),
    r("t3", "c3", "2026-01-03", "bbb", label="b"),
    r("t3", "c3", "2026-01-03", "aaa", label="a"),
]
out = prepare(rows, TE, DE)
check("empty first event rejects ticket", "t1" not in ids(out)["train"])
check("staff ignored, original text kept",
      out["train"][0] == {"id": "t2", "customer": "c2", "text": "  Need help\n", "label": "billing"})
check("tie -> lexicographically smallest text, its label",
      [e for e in out["train"] if e["id"] == "t3"][0]["label"] == "a")
check("exact keys only", all(set(e) == {"id", "customer", "text", "label"}
                             for v in out.values() for e in v))

# Label rejection and availability.
rows = [
    r("a", "c1", "2026-01-01", "m1", label=None),
    r("b", "c2", "2026-01-01", "m2", status="disputed"),
    r("c", "c3", "2026-01-01", "m3", label_time="2026-02-01"),   # train, label at cutoff
    r("d", "c4", "2026-02-10", "m4", label_time="2026-02-28"),   # dev ok
    r("e", "c5", "2026-02-10", "m5", label_time="2026-03-01"),   # dev late
    r("f", "c6", "2026-03-01", "m6", label_time="2027-01-01"),   # confirm late ok
    r("g", "c7", "2026-01-31", "m7", label_time=None),
]
out = ids(prepare(rows, TE, DE))
check("label/status/availability", out == {"train": [], "dev": ["d"], "confirm": ["f"]})

# Excluded ticket does not bind its component; transitive grouping; same-role kept.
rows = [
    r("t01", "cA", "2026-01-01", "Hello  World"),
    r("t02", "cA", "2026-01-02", "other"),               # same role, same customer -> kept
    r("t03", "cB", "2026-02-05", "hello world", label_time="2026-02-06"),  # text dup -> drop
    r("t04", "cB", "2026-03-05", "zzz"),                 # via t03 customer -> drop
    r("t05", "cC", "2026-02-05", "unique", label_time="2026-03-05"),  # dev late -> excluded
    r("t06", "cC", "2026-03-05", "fresh"),               # cC only via excluded t05 -> kept
    r("t07", "cD", "2026-02-10", "dd", label_time="2026-02-11"),
    r("t08", "cD", "2026-03-10", "ee"),                  # later role of cD -> drop
    r("t09", "cE", "2026-03-10", "DD"),                  # links to t07 text -> drop
]
out = ids(prepare(rows, TE, DE))
check("components", out == {"train": ["t01", "t02"], "dev": ["t07"], "confirm": ["t06"]})

# CLI round trip.
payload = json.dumps({"rows": rows, "train_end": TE, "dev_end": DE})
proc = subprocess.run([sys.executable, "solution.py"], input=payload,
                      capture_output=True, text=True, check=True)
check("CLI matches prepare", ids(json.loads(proc.stdout)) == out)

sys.exit(1 if check.failed else 0)
