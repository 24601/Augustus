"""Build train/dev/confirm first-message datasets from a mixed ticket export."""
import json
import sys

ROLES = ("train", "dev", "confirm")


def _norm(text):
    return " ".join(text.casefold().split())


def _first_user_rows(rows):
    chosen = {}
    for row in rows:
        if row.get("role") != "user":
            continue
        key = (row.get("time"), row.get("text") or "")
        ticket = row.get("ticket")
        if ticket not in chosen or key < chosen[ticket][0]:
            chosen[ticket] = (key, row)
    return {ticket: row for ticket, (_, row) in chosen.items()}


def _role(time, train_end, dev_end):
    if time < train_end:
        return 0
    if time < dev_end:
        return 1
    return 2


def _label_available(role, label_time, train_end, dev_end):
    if role == 2:
        return True
    if not isinstance(label_time, str):
        return False
    return label_time < (train_end if role == 0 else dev_end)


def _sort_by_id(examples):
    try:
        return sorted(examples, key=lambda e: e["id"])
    except TypeError:
        return sorted(examples, key=lambda e: (type(e["id"]).__name__, str(e["id"])))


def prepare(rows, train_end, dev_end):
    eligible = []
    for ticket, row in _first_user_rows(rows).items():
        text = row.get("text")
        if not isinstance(text, str) or not text.strip():
            continue
        if row.get("label") is None or row.get("label_status") != "agreed":
            continue
        role = _role(row["time"], train_end, dev_end)
        if not _label_available(role, row.get("label_time"), train_end, dev_end):
            continue
        eligible.append((ticket, row, role))

    parent = list(range(len(eligible)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    first_seen = {}
    for i, (_, row, _) in enumerate(eligible):
        keys = [("text", _norm(row["text"]))]
        if row.get("customer") is not None:
            keys.append(("customer", json.dumps(row["customer"], sort_keys=True)))
        for key in keys:
            if key in first_seen:
                a, b = find(i), find(first_seen[key])
                if a != b:
                    parent[a] = b
            else:
                first_seen[key] = i

    earliest = {}
    for i, (_, _, role) in enumerate(eligible):
        root = find(i)
        earliest[root] = min(earliest.get(root, role), role)

    out = {name: [] for name in ROLES}
    for i, (ticket, row, role) in enumerate(eligible):
        if role != earliest[find(i)]:
            continue
        out[ROLES[role]].append({
            "id": ticket,
            "customer": row.get("customer"),
            "text": row["text"],
            "label": row["label"],
        })
    return {name: _sort_by_id(examples) for name, examples in out.items()}


def main():
    args = json.load(sys.stdin)
    result = prepare(args["rows"], args["train_end"], args["dev_end"])
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
