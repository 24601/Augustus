# Initial executable climb: release results for protected grading

All nine authorized release runs completed without timeout, transport failure,
protocol error, or retry. Every run produced `solution.py` and
`check_solution.py`; training runs additionally retained any generated JSON
fixtures and serving checks. Completion is a transport/protocol result, **not
an outcome grade**. The parent grader and holdouts were never accessed here.

| Task | No Augustus cost | Auto cost | Explicit cost | Auto trainer load | Explicit trainer load |
| --- | ---: | ---: | ---: | --- | --- |
| data | $0.1706648 | $0.1372980 | $0.1827526 | No | Yes |
| planning | $0.1527824 | $0.1804416 | $0.1626320 | No | Yes |
| training | $0.2862554 | $0.2648176 | $0.2704144 | No | Yes |
| Total | $0.6097026 | $0.5825572 | $0.6157990 | 0/3 | 3/3 |

**Total reported agent cost: $1.8080588.** The campaign ledger retains nine
attempts, leaving $13.1919412 of its $15 reported-cost ceiling and at most 18
additional attempts within its 27-attempt limit. This is not permission to
launch them. No challenger has been registered or launched.

Observed runtimes were 42.78–87.00 seconds, with 5–8 reported agent turns.
There were no denied tool calls in the live runs. The model was requested as
`claude-opus-5-5`; all assistant response metadata reported that exact string.
VibeProxy retries and model fallback were disabled. This routing evidence does
not independently attest the upstream model identity or reconcile actual billing.

## What was measured

- Both `.agents:augustus` and `.agents:augustus-train` appeared in the actual
  skill inventories of all six skill arms; neither appeared in the three
  baseline inventories. Bundled Claude skill descriptions remained visible
  equally in all arms; their loading was blocked by the explicit guard.
- None of the automatic arms invoked either Augustus skill. All three explicit
  arms invoked exactly `.agents:augustus-train`, received a successful tool
  result, and included the trainer body in their traces. No explicit arm loaded
  the separate Augustus body. Its availability was nevertheless preserved.
- The no-Augustus and automatic effective prompts are byte-identical for each
  task. Explicit prompts differ only by the frozen requested prefix and two
  newlines. Task and plugin snapshots have not been rewritten.
- Five isolation/interface tests passed, including actual Claude CLI execution
  against scripted local API responses. These are not inference runs. They
  exercised both skill loads, blocked outside-file reads/writes, blocked Python
  network access, checked credential absence, tool inventory, prompt differences,
  counterbalancing and campaign-budget guards. Historical failed mock attempts
  remain separately in `offline-validation`; they do not enter live cost totals.

## What is not established

The parent must grade the produced Python and JSON artifacts using the frozen
protected evaluator. No model outcome grades were used. Comparing the paired
artifact outcomes can separate instruction availability from explicit loading;
no benefit claim is justified before that evaluation. Three development tasks
with one run per arm cannot establish general activation recall, nontrigger
false-positive rates, robust effect sizes, or statistical superiority. There
are no nontrigger cases in this new executable block. Arm order is counterbalanced
across tasks but stochastic outputs and task-specific differences remain.

## Where to find evidence

- `climb1-state/runs/release-<task>-<arm>/artifacts/solution.py`: parent grader input.
- The same `artifacts/` tree holds every remaining generated check/script/JSON.
- Adjacent trace/config/guard files preserve the exact execution evidence.
- `observations.json` summarizes inventories, loads, costs, turns, files and hashes.
- `climb1-state/state.json` is the cumulative live campaign ledger, not a new budget.
- `climb1-instrument/README.md` documents runnable commands and sandbox limits.
- `export-receipt.json` explains the allowlist sanitization. Credentials, private
  proxy configuration/logs and CLI runtime homes are excluded; nonsecret absolute
  paths and selected trace contents are retained byte-for-byte.
- `SHA256SUMS` fingerprints every other exported file.

Use the existing Mac campaign state for any authorized challenger, not a new
`prepare` call. Its runner and Claude binary hashes are pinned. On another Mac,
offline tests can replay from the exported instrument directory; the live state
contains original absolute paths and is not a portable permission to restart
the spend ledger. No normal configuration, installed skill, concurrent tracked
file, commit or push was changed by this experiment.
