# First climb: executable three-arm instrument

This is an experiment runner, not a grader. The parent owns protected evaluation
and candidate selection. No evaluator, repository audit, hidden test, or holdout
task is copied into any agent fixture. The only task source is the approved
archive with SHA-256
`c4af63c6a05af3da5fe4ca8dfa9e09316d6f13c193e8852ccc7d6270d57f0e72`.

The parent supplied the frozen grader fingerprint
`491e1a263290ed4379b4f44f634e550b1b815a6e24f7229112c8a32de4b4cabc`;
the grader itself was not transferred or read here. The parent subsequently
authorized the initial nine runs after isolation validation. Challengers do not
launch automatically when registered.

## Fixed treatment

Model: `claude-opus-5-5`, effort medium, pinned Claude Code 2.1.282 binary.
The CLI binary and runner are hashed in the campaign state. All arms use the
same tools, limits, task bytes and common environment instructions.

| Task | First | Second | Third |
| --- | --- | --- | --- |
| data | none | auto | explicit |
| planning | auto | explicit | none |
| training | explicit | none | auto |

- **none:** no Augustus plugin path; neither skill is available or permitted.
- **auto:** both released Augustus skills are available, with no load request.
- **explicit:** same plugin and task as auto, with exactly this prefix:

  `Before implementing, load augustus-train and apply its relevant guidance.`

Both Augustus and Augustus Train are allowed in the skill arms. Common environment
instructions do not name either skill. Auto and none effective prompts are
byte-identical per task. The explicit intervention is only the fixed prefix and
two separating newlines. Explicit runs must actually load the trainer body;
attempts and text mentions are not counted as successful loads.

Claude's bundled built-in skill descriptions remain visible in all three arms.
They are identical across arms and their Skill calls are denied by the guard.
Thus the baseline means **no Augustus**, not removal of every bundled Claude
description. The actual skill inventories are preserved in each init trace.

The release snapshot was checked against v0.8.1 at
[4ba9d211](https://github.com/24601/Augustus/commit/4ba9d2111d29ea03247c22b3de90bfa8dde1b261).
Its canonical sorted file-hash-map fingerprint is
`26b125cf8cd856d9146c705af86641a532b2b9d486841026568382b6f6ec68d4`.
Candidate registration snapshots the supplied skills-only directory without
editing installed skills. Links, hooks/config outside skills, forked skills and
shell preprocessing are rejected. Each snapshot is rechecked before launch.

## Supported interface and evidence inspected

Before implementing, inspected installed `claude --help`, `plugin eval --help`,
and the installed binary's option/schema definitions. Actual offline CLI tests
then exercised these contracts:

- `--tools` sets the built-in tool inventory; Task/Agent/TaskStop and web tools
  are explicitly disallowed. No nested-agent tool was exposed in the smoke runs.
- `--restricted` ignores user/project/local settings, confines file tools to
  working/additional directories, and still honors explicit `--settings`.
- `--setting-sources ''`, isolated HOME/config/temp, disabled CLAUDE.md discovery
  and strict empty MCP config avoid normal configuration and memory loading.
- `--plugin-dir` loads the two skills only for that process. Baseline omits it.
- A command `PreToolUse` hook returns `hookSpecificOutput` with
  `hookEventName: PreToolUse`, `permissionDecision`, and, for Bash,
  `updatedInput`. The real CLI applied the hook's command rewrite and denials.
- `--max-turns 20` is a supported hidden print-mode option in this binary.
  `--max-budget-usd` and `--output-format stream-json --verbose` are supported.
- **Do not add `--bare`: it disables command hooks.** Do not use `--safe-mode`
  because it disables the plugin treatment. Direct CLI runs were chosen over
  eval's automatic two-arm execution to control the three-arm order and avoid
  outcome judges entirely.

## Enforcement and limits

- Campaign: concurrency one under a file lock, at most **27 attempts**, release
  plus at most **two challenger variants**, and **$15 aggregate reported agent
  cost**. These limits share one persistent state file; never create a fresh
  state to reset the spend. No paid judges run.
- Per run: at most **20 agent turns / 180 seconds**. The remaining dollar budget
  is also passed to Claude. Launch checks can overshoot by the in-flight run;
  reported list-price cost is not independently reconciled billing.
- A starting attempt is persisted before launch. Missing cost, timeout, transport
  failure, or protocol failure stops automatic continuation. Attempts are retained
  and never silently retried or assigned zero cost. Artifact correctness failures
  remain for the parent to grade; a generated program is not called correct by
  this runner.
- Only Read, Glob, Grep, Write, Edit, Bash, Skill are exposed. File paths are
  resolved to reject traversal and symlink escapes. Writes stay inside the
  fixture; TASK.md and configuration/plugin paths are protected. Skill reads
  are allowed only from the selected read-only snapshot.
- Bash accepts `python3 relative_script.py [arguments...]`. The hook rewrites
  that to a fixed Python launcher; arguments are shell-quoted rather than
  interpreted as operators. Use a generated Python check script for JSON stdin,
  multiple commands, or fresh-process serving checks.
- Untrusted Python runs under macOS Seatbelt: default deny, no network (including
  loopback/VibeProxy), no outside writes, only fixture and read-only system/runtime
  reads, no site-packages, and a credential-free environment. Each Python command
  has 60-second CPU/wall bounds and a 16 MiB per-file bound. Background descendants
  are terminated when the command completes. Metadata and root-directory listing
  remain readable for system loading; this is not an information-theoretic
  concealment boundary.
- The agent process needs loopback API access; only its Python tools are under
  that no-network OS profile. File-tool and Skill boundaries are enforced by the
  explicit hook plus restricted CLI. Smoke tests establish the exercised cases,
  not a proof against all hostile OS/kernel/CLI behavior.

The live runner starts a temporary instance of VibeProxy's bundled backend with
retries and model fallback disabled, using a permission-restricted temporary
local snapshot of the existing Claude proxy credential. No auth files are
exported. Normal app/Claude settings are untouched. Only the exact model is
accepted in the catalog and agent response metadata; those names still do not
independently attest the backend model. The temporary service and auth snapshot
are removed on exit.

## Runnable interface

From this directory on the Mac:

```sh
# Offline checks: actual CLI uses a scripted loopback API, not a model/provider.
python3 -m unittest -v test_instrument test_cli

# Create once, before inference. This does not start a proxy or model call.
python3 instrument.py prepare \
  --tasks tasks.tar.gz \
  --release ../081-vibeproxy-results/release-agents \
  --state ../climb1-state

# Authorized initial release block: nine runs, no graders.
python3 instrument.py run --state ../climb1-state \
  --variant release --authorize-inference

# Inspect the shared spend/attempt ledger; no inference.
python3 instrument.py status --state ../climb1-state

# Only after the parent supplies a challenger snapshot, with both skills:
python3 instrument.py add-candidate --state ../climb1-state \
  --name challenger1 --plugin /absolute/path/to/candidate/.agents

# Requires the parent's corresponding launch decision; not automatic:
python3 instrument.py run --state ../climb1-state \
  --variant challenger1 --authorize-inference
```

Python's standard library implements the runner except for the already-installed
PyYAML used to read the existing VibeProxy config at live launch. No package
installation is performed. `test_cli.py` uses the previously verified release
snapshot in the sibling results directory. The test traces are labelled mock and
must never be mixed with paid experiment results or cost denominators.

## Collected result shape

`state.json` contains ordered attempts, requested model, hashes, cost, duration,
timeout/error/protocol status and exact successful skill loads. Each
`runs/<variant>-<task>-<arm>/` retains:

- `artifacts/solution.py`, every remaining generated check/script/JSON file, and
  immutable TASK.md. Symlinks are listed but never followed into outside data.
- `artifact-manifest.json` with file SHA-256s and excluded symlinks.
- Full `trace.jsonl`, `stderr.log`, and `guard-events.jsonl`, including failures.
- Actual `settings.json`, `guard.json`, `sandbox.sb`, effective `prompt.txt`,
  and `execution.json` with the command and nonsecret client environment.

No outcome score is computed here. The parent grades the frozen produced files
against its protected evaluator. Deleted intermediate files may still be visible
in Write/Edit events, but the artifact directory represents the final fixture.
