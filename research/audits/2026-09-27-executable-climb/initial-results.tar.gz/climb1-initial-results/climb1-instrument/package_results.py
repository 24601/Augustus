"""Export allowlisted experiment evidence, never private runtime homes or auth."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'climb1-state'
DEST = HERE.parent / 'climb1-initial-results'
ARCHIVE = HERE.parents[3] / 'climb1-initial-results.tar.gz'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    state = json.loads((SOURCE / 'state.json').read_text())
    assert len(state['records']) == 9
    assert all(r['status'] != 'running' for r in state['records'])
    assert not DEST.exists(), 'Do not overwrite a published evidence export.'
    assert not ARCHIVE.exists()
    DEST.mkdir()
    target_state = DEST / 'climb1-state'
    shutil.copytree(SOURCE, target_state, ignore=shutil.ignore_patterns('lock'))
    target_instrument = DEST / 'climb1-instrument'
    target_instrument.mkdir()
    for name in ['instrument.py', 'test_instrument.py', 'test_cli.py',
                 'README.md', 'RESULTS.md', 'validation.txt', 'tasks.tar.gz', 'package_results.py']:
        shutil.copyfile(HERE / name, target_instrument / name)
    # Preserve the historical test dependency layout for offline replay.
    shutil.copytree(SOURCE / 'plugins/release/.agents',
                    DEST / '081-vibeproxy-results/release-agents')
    offline = DEST / 'offline-validation'
    offline.mkdir()
    for runtime in sorted((HERE / 'selftest').glob('mock-*')):
        target = offline / runtime.name
        target.mkdir()
        for name in ['trace.jsonl', 'stderr.log', 'guard-events.jsonl',
                     'offline-observation.json', 'settings.json', 'guard.json',
                     'sandbox.sb', 'prompt.txt', 'execution.json']:
            if (runtime / name).exists():
                shutil.copyfile(runtime / name, target / name)
        if (runtime / 'fixture').exists():
            shutil.copytree(runtime / 'fixture', target / 'fixture')
    observations = []
    for record in state['records']:
        run = SOURCE / 'runs' / record['id']
        rows = [json.loads(line) for line in (run / 'trace.jsonl').read_text().splitlines()]
        init = next(row for row in rows if row.get('subtype') == 'init')
        result = next(row for row in reversed(rows) if row.get('type') == 'result')
        manifest = json.loads((run / 'artifact-manifest.json').read_text())
        for name, expected in manifest['files'].items():
            assert sha(run / 'artifacts' / name) == expected
        guards = [json.loads(line) for line in (run / 'guard-events.jsonl').read_text().splitlines()]
        observations.append({**record, 'turns': result.get('num_turns'),
            'availableSkills': init.get('skills'), 'tools': init.get('tools'),
            'responseModels': sorted({row['message']['model'] for row in rows if row.get('type') == 'assistant'}),
            'generatedFiles': [name for name in manifest['files'] if name != 'TASK.md'],
            'solutionSha256': manifest['files'].get('solution.py'),
            'deniedTools': [g['tool'] for g in guards if g['decision']['permissionDecision'] == 'deny']})
    for task in state['tasks']:
        none = (SOURCE / 'runs' / f'release-{task}-none' / 'prompt.txt').read_bytes()
        auto = (SOURCE / 'runs' / f'release-{task}-auto' / 'prompt.txt').read_bytes()
        explicit = (SOURCE / 'runs' / f'release-{task}-explicit' / 'prompt.txt').read_bytes()
        assert none == auto
        assert explicit == b'Before implementing, load augustus-train and apply its relevant guidance.\n\n' + auto
    summary = {'reportedCostUsd': sum(r['cost'] for r in state['records']),
        'parentGraderSha256': '491e1a263290ed4379b4f44f634e550b1b815a6e24f7229112c8a32de4b4cabc',
        'parentGraderRead': False, 'outcomeGrading': 'Not performed; parent owns protected evaluator.',
        'records': observations}
    (DEST / 'observations.json').write_text(json.dumps(summary, indent=2) + '\n')
    # Config is the actual nonsecret CLI config. Runtime homes, auth, proxy logs
    # and private proxy configuration are not on the export allowlist.
    patterns = [rb'sk-ant-[A-Za-z0-9_-]{20,}', rb'sk-[A-Za-z0-9]{32,}',
                rb'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}']
    for path in DEST.rglob('*'):
        if path.is_file():
            data = path.read_bytes()
            assert not any(re.search(pattern, data) for pattern in patterns), f'Secret-shaped bytes in {path.name}'
    receipt = {
        'authExported': False, 'runtimeHomesExported': False,
        'privateProxyConfigAndLogsExported': False,
        'credentialShapeScan': 'passed',
        'pathPolicy': 'Local absolute paths retained for exact config/trace provenance; these are not credentials.',
        'tracePolicy': 'Selected traces copied byte-for-byte; no model content rewritten.',
        'offlinePolicy': 'offline-validation contains only scripted API tests, not inference; excluded from live costs/results.',
    }
    (DEST / 'export-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    files = sorted(p for p in DEST.rglob('*') if p.is_file())
    (DEST / 'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(DEST)}\n' for p in files))
    with tarfile.open(ARCHIVE, 'w:gz') as archive:
        archive.add(DEST, arcname=DEST.name)
    print(json.dumps({'archive': str(ARCHIVE), 'sha256': sha(ARCHIVE),
                      'reportedCostUsd': summary['reportedCostUsd'],
                      'runs': len(observations)}, indent=2))


if __name__ == '__main__':
    main()
