import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import unittest


SPEC = importlib.util.find_spec('instrument')
if SPEC:
    import instrument as m


class InstrumentTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(SPEC, 'The replayable instrument has not been implemented')

    def test_counterbalance_and_prompt_intervention(self):
        orders = [m.arm_order(i) for i in range(3)]
        self.assertEqual(orders, [
            ['none', 'auto', 'explicit'], ['auto', 'explicit', 'none'],
            ['explicit', 'none', 'auto'],
        ])
        task = '# A contract\nPreserve these bytes.\n'
        self.assertEqual(m.prompt_for(task, 'none'), m.prompt_for(task, 'auto'))
        self.assertIn(task, m.prompt_for(task, 'auto'))
        self.assertEqual(m.prompt_for(task, 'explicit'),
                         'Before implementing, load augustus-train and apply its relevant guidance.\n\n'
                         + m.prompt_for(task, 'auto'))

    def test_budget_boundaries_and_unknown_cost_fail_closed(self):
        self.assertTrue(m.can_launch([{'status': 'done', 'cost': 14.99}]))
        self.assertFalse(m.can_launch([{'status': 'done', 'cost': 15.0}]))
        self.assertFalse(m.can_launch([{'status': 'running', 'cost': None}]))
        self.assertFalse(m.can_launch([{'status': 'done', 'cost': None}]))
        self.assertFalse(m.can_launch([{'status': 'done', 'cost': 0.1}] * 27))
        self.assertFalse(m.can_launch([{'status': 'done', 'cost': float('nan')}]))
        self.assertFalse(m.can_launch([{'status': 'failed', 'cost': 0.0}]))

    def test_guard_paths_skills_and_shell_rewrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            fixture, plugin = root / 'fixture', root / '.agents'
            fixture.mkdir(); plugin.mkdir()
            (fixture / 'TASK.md').write_text('contract')
            (fixture / 'probe.py').write_text('print(1)')
            (fixture / 'escape').symlink_to(root)
            spec = m.guard_spec(fixture, plugin, root)
            allow = lambda tool, values: m.guard_decision(spec, tool, values)['permissionDecision']
            self.assertEqual(allow('Write', {'file_path': str(fixture/'solution.py')}), 'allow')
            for path in [root/'outside.py', fixture/'TASK.md', fixture/'escape'/'outside.py', fixture/'.claude/settings.json', plugin/'SKILL.md']:
                self.assertEqual(allow('Write', {'file_path': str(path)}), 'deny', str(path))
            self.assertEqual(allow('Read', {'file_path': str(plugin/'SKILL.md')}), 'allow')
            self.assertEqual(allow('Glob', {'pattern': '../../*'}), 'deny')
            self.assertEqual(allow('Skill', {'skill': '.agents:augustus-train'}), 'allow')
            self.assertEqual(allow('Skill', {'skill': 'debug'}), 'deny')
            self.assertEqual(allow('Task', {}), 'deny')
            self.assertEqual(allow('Bash', {'command': 'curl https://example.com'}), 'deny')
            self.assertEqual(allow('Bash', {'command': 'python3 -c "print(1)"'}), 'deny')
            decision = m.guard_decision(spec, 'Bash', {'command': 'python3 probe.py "x; touch /tmp/escape"'})
            self.assertEqual(decision['permissionDecision'], 'allow')
            self.assertIn('python-sandbox', decision['updatedInput']['command'])
            no_plugin = m.guard_spec(fixture, None, root)
            self.assertEqual(m.guard_decision(no_plugin, 'Skill', {'skill': 'augustus-train'})['permissionDecision'], 'deny')

    def test_real_python_sandbox_denies_network_and_external_effects(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            fixture = root/'fixture'; fixture.mkdir()
            (fixture/'TASK.md').write_text('immutable')
            sentinel = root/'secret.txt'; sentinel.write_text('NOT_VISIBLE')
            with socket.socket() as listener:
                listener.bind(('127.0.0.1', 0)); listener.listen()
                port = listener.getsockname()[1]
                (fixture/'probe.py').write_text(
                    'import json,os,socket,pathlib\n'
                    'results={}\n'
                    'def check(name,action):\n'
                    ' try: action(); results[name]="ALLOWED"\n'
                    ' except (OSError,PermissionError): results[name]="DENIED"\n'
                    f'check("read",lambda:pathlib.Path({str(sentinel)!r}).read_text())\n'
                    f'check("write",lambda:pathlib.Path({str(root/"outside")!r}).write_text("bad"))\n'
                    'check("contract",lambda:pathlib.Path("TASK.md").write_text("bad"))\n'
                    f'check("network",lambda:socket.create_connection(("127.0.0.1",{port}),timeout=1))\n'
                    'results["credential"]=os.environ.get("ANTHROPIC_AUTH_TOKEN")\n'
                    'pathlib.Path("output.json").write_text(json.dumps(results))\n'
                    'print(json.dumps(results))\n'
                )
                spec = m.guard_spec(fixture, None, root)
                (root/'guard.json').write_text(json.dumps(spec))
                result = subprocess.run([sys.executable, str(Path(m.__file__).resolve()),
                                         'python-sandbox', '--spec', str(root/'guard.json'),
                                         'probe.py'], text=True, capture_output=True,
                                        env={**os.environ, 'ANTHROPIC_AUTH_TOKEN':'must-not-inherit'})
            self.assertEqual(result.returncode, 0, result.stderr)
            observed = json.loads((fixture/'output.json').read_text())
            self.assertEqual(observed, dict(read='DENIED',write='DENIED',contract='DENIED',network='DENIED',credential=None))
            self.assertFalse((root/'outside').exists())
            self.assertEqual((fixture/'TASK.md').read_text(), 'immutable')


if __name__ == '__main__':
    unittest.main()
