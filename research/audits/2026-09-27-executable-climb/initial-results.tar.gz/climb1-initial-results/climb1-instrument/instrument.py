"""Bounded three-arm artifact experiment. No inference in prepare/status/guard/tests."""
import argparse
import contextlib
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import resource
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.request

MODEL = 'claude-opus-5-5'
RELEASE = '4ba9d2111d29ea03247c22b3de90bfa8dde1b261'
TASK_SHA = 'c4af63c6a05af3da5fe4ca8dfa9e09316d6f13c193e8852ccc7d6270d57f0e72'
TOOLS = ['Read', 'Glob', 'Grep', 'Write', 'Edit', 'Bash', 'Skill']
EXPLICIT = 'Before implementing, load augustus-train and apply its relevant guidance.'
HERE = Path(__file__).resolve().parent
SELF = Path(__file__).resolve()
CLAUDE = Path.home()/'.local/share/claude/versions/2.1.282'
PROXY = Path('/Applications/VibeProxy.app/Contents/Resources/cli-proxy-api-plus')
COMMON = '''
Execution environment: the working directory is your disposable fixture.
TASK.md is the immutable task contract. Use Read/Glob/Grep and Write/Edit here.
Bash accepts only `python3 relative_script.py [arguments...]`, not shell syntax,
interpreter flags, -c, -m, pipes, redirection, installs, or network commands.
Write a Python check script when stdin, subprocesses, or multiple steps are needed.
Python scripts run in a stdlib-only OS sandbox with no network, no credentials,
and no reads or writes outside this fixture except read-only system libraries.
Do not use nested agents, network tools, account actions, or package installs.
Deliver solution.py
and retain your generated checks here. There is no visible evaluator to find.
'''


def dump(path, data):
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def arm_order(task_index):
    arms = ['none', 'auto', 'explicit']
    offset = task_index % 3
    return arms[offset:] + arms[:offset]


def prompt_for(contract, arm):
    base = contract + '\n' + COMMON
    return EXPLICIT + '\n\n' + base if arm == 'explicit' else base


def can_launch(records):
    return (len(records) < 27
            and all(r.get('status') == 'done' and isinstance(r.get('cost'), (int, float))
                    and math.isfinite(r['cost']) and r['cost'] >= 0 for r in records)
            and sum(r['cost'] for r in records) < 15)


def within(path, root):
    return path == root or root in path.parents


def guard_spec(fixture, plugin, runtime):
    return {'fixture': str(Path(fixture).resolve()),
            'plugin': str(Path(plugin).resolve()) if plugin else None,
            'runtime': str(Path(runtime).resolve()), 'instrument': str(SELF),
            'python': str(Path(sys.executable).resolve())}


def guard_decision(spec, tool, values):
    denied = {'permissionDecision': 'deny', 'permissionDecisionReason': 'Outside the experiment tool/fixture contract.'}
    allowed = {'permissionDecision': 'allow'}
    root = Path(spec['fixture'])
    plugin = Path(spec['plugin']) if spec.get('plugin') else None
    try:
        if tool == 'Skill':
            names = {'augustus', 'augustus-train', '.agents:augustus', '.agents:augustus-train'}
            return allowed if plugin and values.get('skill') in names else denied
        if tool in ['Read', 'Write', 'Edit', 'Glob', 'Grep']:
            key = 'path' if tool in ['Glob', 'Grep'] else 'file_path'
            raw = values.get(key) or (str(root) if tool in ['Glob', 'Grep'] else '')
            if not raw:
                return denied
            path = Path(raw)
            path = (root/path).resolve() if not path.is_absolute() else path.resolve()
            if tool in ['Write', 'Edit']:
                if not within(path, root) or path == root/'TASK.md':
                    return denied
                if any(part in {'.claude', '.agents', '.git'} for part in path.relative_to(root).parts):
                    return denied
            elif not (within(path, root) or plugin and within(path, plugin)):
                return denied
            if tool in ['Glob', 'Grep']:
                pattern = values.get('pattern' if tool == 'Glob' else 'glob', '')
                if pattern.startswith('/') or '..' in pattern.split('/'):
                    return denied
            return allowed
        if tool == 'Bash':
            words = shlex.split(values.get('command', ''))
            if len(words) < 2 or words[0] != 'python3' or not words[1].endswith('.py'):
                return denied
            script = Path(words[1])
            if script.is_absolute() or '..' in script.parts:
                return denied
            resolved = (root/script).resolve()
            if not within(resolved, root) or not resolved.is_file():
                return denied
            # Shell operators become quoted arguments, never shell operations.
            command = shlex.join([spec['python'], spec['instrument'], 'python-sandbox',
                                  '--spec', str(Path(spec['runtime'])/'guard.json'), *words[1:]])
            return {**allowed, 'updatedInput': {'command': command, 'timeout': 65000,
                                              'run_in_background': False}}
    except (ValueError, TypeError, OSError):
        return denied
    return denied


def sandbox_profile(fixture):
    root = str(Path(fixture).resolve())
    quote = json.dumps
    reads = ['/System/Library', '/System/Cryptexes', '/System/Volumes/Preboot/Cryptexes',
             '/usr/lib', '/usr/share', '/usr/bin', '/bin',
             '/Library/Apple', '/opt/homebrew']
    return '\n'.join([
        '(version 1)', '(deny default)', '(allow process-exec)', '(allow process-fork)',
        '(allow signal (target self))', '(allow sysctl-read)', '(allow file-read-metadata)',
        '(allow file-read* (literal "/"))',  # macOS 27 dyld opens the root directory.
        '(allow file-read* ' + ' '.join('(subpath '+quote(p)+')' for p in reads+[root]) + ')',
        '(allow file-read* (literal "/dev/null") (literal "/dev/urandom") (literal "/dev/random"))',
        '(allow file-write* (subpath '+quote(root)+') (literal "/dev/null"))',
        '(deny file-write* (literal '+quote(root+'/TASK.md')+'))',
        '(deny file-write* (regex '+quote(re.escape(root)+r'/.*\.(claude|agents|git)(/|$)')+'))',
        '(deny file-read* (regex ".*/(site-packages|dist-packages)(/|$)"))',
        '(deny network*)',
    ]) + '\n'


def python_sandbox(spec, words):
    root = Path(spec['fixture'])
    decision = guard_decision(spec, 'Bash', {'command': shlex.join(['python3', *words])})
    if decision['permissionDecision'] != 'allow':
        raise ValueError('Rejected Python command')
    (root/'tmp').mkdir(exist_ok=True)
    env = {'PATH': '/usr/bin:/bin', 'HOME': str(root), 'TMPDIR': str(root/'tmp'),
           'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1', 'LANG': 'en_US.UTF-8'}
    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    resource.setrlimit(resource.RLIMIT_FSIZE, (16*1024*1024, 16*1024*1024))
    process = subprocess.Popen(['/usr/bin/sandbox-exec', '-p', sandbox_profile(root),
                                spec['python'], '-S', '-B', *words],
                               cwd=root, env=env, start_new_session=True)
    try:
        return process.wait(timeout=60)
    except subprocess.TimeoutExpired:
        return 124
    finally:
        # Also terminate background descendants after the foreground script exits.
        try: os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        process.wait()


def snapshot_plugin(source, destination):
    source = Path(source).resolve()
    if not (source/'skills/augustus/SKILL.md').is_file() or not (source/'skills/augustus-train/SKILL.md').is_file():
        raise ValueError('Expected .agents skills-directory layout containing both skills')
    for p in source.rglob('*'):
        if p.is_symlink() or (p.is_file() and not p.is_relative_to(source/'skills')):
            raise ValueError('Plugins must be plain skills-only snapshots, without links/hooks/config')
        if p.name == 'SKILL.md':
            text = p.read_text()
            if re.search(r'(?m)^context:\s*fork|!`', text):
                raise ValueError('Forked skills and shell preprocessing are not permitted')
    shutil.copytree(source, destination)
    return {str(p.relative_to(destination)): sha(p) for p in destination.rglob('*') if p.is_file()}


def verify_state(state):
    for task, digest in state['tasks'].items():
        if sha(Path(state['root'])/'tasks'/task/'prompt.md') != digest:
            raise ValueError('Task bytes changed after preparation')
    for variant, hashes in state['variants'].items():
        base = Path(state['root'])/'plugins'/variant/'.agents'
        actual = {str(p.relative_to(base)): sha(p) for p in base.rglob('*') if p.is_file()}
        if actual != hashes:
            raise ValueError('Plugin bytes changed after preparation')
    if sha(SELF) != state['instrumentSha256'] or sha(CLAUDE) != state['claudeSha256']:
        raise ValueError('Instrument or pinned CLI changed; prepare a reviewed revision, do not silently reset budget')


def prepare(args):
    root = Path(args.state).resolve()
    if root.exists():
        raise ValueError('State already exists; never reset an existing campaign ledger')
    archive = Path(args.tasks)
    if sha(archive) != TASK_SHA:
        raise ValueError('Task archive fingerprint mismatch')
    root.mkdir(parents=True, mode=0o700)
    with tarfile.open(archive) as t:
        files = [m for m in t.getmembers() if m.isfile()]
        expected = {f'tasks/{task}/prompt.md' for task in ['data','planning','training']}
        if {m.name for m in files} != expected or any(m.issym() or m.islnk() for m in t.getmembers()):
            raise ValueError('Only the three public task contracts may enter the campaign')
        for m in files:
            p = root/m.name; p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(t.extractfile(m).read())
    plugin = root/'plugins/release/.agents'
    plugin.parent.mkdir(parents=True)
    hashes = snapshot_plugin(args.release, plugin)
    state = {'schema': 1, 'root': str(root), 'release': RELEASE,
             'tasksArchiveSha256': TASK_SHA,
             'tasks': {task: sha(root/'tasks'/task/'prompt.md') for task in ['data','planning','training']},
             'variants': {'release': hashes}, 'records': [],
             'instrumentSha256': sha(SELF), 'claudeSha256': sha(CLAUDE),
             'model': MODEL, 'costCeiling': 15, 'maxRuns': 27, 'maxTurns': 20, 'timeoutSeconds': 180}
    dump(root/'state.json', state)
    print(json.dumps({'prepared': str(root), 'inferenceStarted': False, 'schedule': schedule(state,'release')}, indent=2))


def schedule(state, variant):
    return [{'id': f'{variant}-{task}-{arm}', 'task': task, 'arm': arm, 'variant': variant}
            for i, task in enumerate(state['tasks']) for arm in arm_order(i)]


def add_candidate(args, state):
    if not re.fullmatch(r'[a-z][a-z0-9-]{0,30}', args.name) or args.name in state['variants']:
        raise ValueError('Choose a new simple candidate name')
    if len(state['variants']) >= 3:
        raise ValueError('At most two challenger variants are authorized')
    dest = Path(state['root'])/'plugins'/args.name/'.agents'
    dest.parent.mkdir(parents=True)
    state['variants'][args.name] = snapshot_plugin(args.plugin, dest)
    dump(Path(state['root'])/'state.json', state)


def settings_for(spec):
    command = shlex.join([spec['python'], spec['instrument'], 'guard', '--spec', str(Path(spec['runtime'])/'guard.json')])
    return {'hooks': {'PreToolUse': [{'matcher': '*', 'hooks': [{'type': 'command', 'command': command, 'timeout': 5}]}]},
            'disableAgentView': True, 'disableRemoteControl': True, 'disableWorkflows': True,
            'enableArtifact': False, 'permissions': {'defaultMode': 'dontAsk'}}


def launch_command(runtime, plugin, remaining):
    command = [str(CLAUDE), '-p', '--model', MODEL, '--effort', 'medium',
               '--output-format', 'stream-json', '--verbose', '--max-turns', '20',
               '--max-budget-usd', str(remaining), '--no-session-persistence',
               '--restricted', '--setting-sources', '', '--settings', str(runtime/'settings.json'),
               '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}',
               '--tools', ','.join(TOOLS), '--permission-mode', 'dontAsk', '--permission-prompts', 'none',
               '--disallowedTools', 'Task,Agent,TaskStop,WebFetch,WebSearch']
    if plugin:
        command += ['--plugin-dir', str(plugin), '--add-dir', str(plugin)]
    return command


def run_environment(runtime, endpoint):
    # Construct rather than inherit: no host credentials, skill directories or hooks.
    home = runtime/'home'; home.mkdir(exist_ok=True)
    config = runtime/'config'; config.mkdir(exist_ok=True)
    temp = runtime/'tmp'; temp.mkdir(exist_ok=True)
    return {'PATH': '/usr/bin:/bin:/opt/homebrew/bin', 'HOME': str(home), 'TMPDIR': str(temp),
            'CLAUDE_CONFIG_DIR': str(config), 'CLAUDE_CODE_MANAGED_SETTINGS_PATH': str(config),
            'ANTHROPIC_BASE_URL': endpoint, 'ANTHROPIC_AUTH_TOKEN': 'local-vibeproxy-placeholder',
            'CLAUDE_CODE_DISABLE_CLAUDE_MDS': '1', 'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC': '1',
            'CLAUDE_CODE_DISABLE_AGENT_VIEW': '1', 'CLAUDE_CODE_DISABLE_WORKFLOWS': '1',
            'ENABLE_CLAUDEAI_MCP_SERVERS': 'false', 'DISABLE_AUTOUPDATER': '1', 'LANG': 'en_US.UTF-8'}


def execute_one(runtime, plugin, prompt, endpoint, remaining):
    runtime = Path(runtime).resolve(); fixture = runtime/'fixture'; fixture.mkdir()
    spec = guard_spec(fixture, plugin, runtime)
    dump(runtime/'guard.json', spec); dump(runtime/'settings.json', settings_for(spec))
    (runtime/'sandbox.sb').write_text(sandbox_profile(fixture))
    (fixture/'TASK.md').write_text(prompt['contract'])
    (runtime/'prompt.txt').write_text(prompt['effective'])
    command = launch_command(runtime, plugin, remaining)
    env = run_environment(runtime, endpoint)
    dump(runtime/'execution.json', {'command': command, 'environment': env, 'timeoutSeconds': 180})
    start = time.monotonic(); timed_out = False
    with (runtime/'trace.jsonl').open('w') as output, (runtime/'stderr.log').open('w') as errors:
        process = subprocess.Popen(command, cwd=fixture, env=env, stdin=subprocess.PIPE,
                                   stdout=output, stderr=errors, text=True, start_new_session=True)
        try:
            process.communicate(prompt['effective'], timeout=180)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL); process.wait()
    rows = []
    for line in (runtime/'trace.jsonl').read_text().splitlines():
        try: rows.append(json.loads(line))
        except json.JSONDecodeError: pass
    result = next((r for r in reversed(rows) if r.get('type') == 'result'), None)
    cost = result.get('total_cost_usd') if result else None
    status = 'done' if not timed_out and process.returncode == 0 and result and result.get('subtype') == 'success' else 'failed'
    protocol_errors = []
    init = next((r for r in rows if r.get('subtype') == 'init'), {})
    if init.get('model') != MODEL or set(init.get('tools', [])) - set(TOOLS):
        protocol_errors.append('model-or-tools-inventory')
    skills = set(init.get('skills', []))
    expected = {'.agents:augustus', '.agents:augustus-train'}
    if (plugin and not expected <= skills) or (not plugin and expected & skills):
        protocol_errors.append('plugin-inventory')
    if init.get('mcp_servers'):
        protocol_errors.append('mcp-inventory')
    calls = []
    replies = {}
    loaded = set()
    for row in rows:
        if row.get('type') == 'assistant' and row.get('message', {}).get('model') != MODEL:
            protocol_errors.append('response-model')
        content = row.get('message', {}).get('content', [])
        if not isinstance(content, list): continue
        for block in content:
            if block.get('type') == 'tool_use' and block.get('name') == 'Skill':
                calls.append({'id': block['id'], 'skill': block['input'].get('skill')})
            if block.get('type') == 'tool_result':
                replies[block['tool_use_id']] = block
            if block.get('type') == 'text':
                for name in ['augustus', 'augustus-train']:
                    if re.match(r'Base directory for this skill: [^\n]*/skills/'+name+r'\n', block['text']):
                        loaded.add(name)
    for call in calls:
        reply = replies.get(call['id'], {})
        call['successfulLoad'] = bool(reply and not reply.get('is_error')
                                      and call['skill'].rsplit(':',1)[-1] in loaded)
    if prompt['effective'].startswith(EXPLICIT+'\n\n') and 'augustus-train' not in loaded:
        protocol_errors.append('explicit-trainer-not-loaded')
    if protocol_errors:
        status = 'failed'
    return {'status': status, 'cost': cost, 'exitCode': process.returncode,
            'timedOut': timed_out, 'durationSeconds': time.monotonic()-start,
            'resultSubtype': result.get('subtype') if result else None,
            'skillCalls': calls, 'loadedContent': sorted(loaded),
            'protocolErrors': sorted(set(protocol_errors))}


@contextlib.contextmanager
def local_proxy():
    # Existing installed dependency; never install a package for the experiment.
    import yaml
    normal = yaml.safe_load((Path.home()/'.cli-proxy-api/merged-config.yaml').read_text())
    with tempfile.TemporaryDirectory(prefix='augclimb-proxy-') as directory:
        root = Path(directory)
        auth = root/'auth'; auth.mkdir(mode=0o700)
        auth_source = Path(os.path.expanduser(normal['auth-dir']))
        matches = list(auth_source.glob('claude-*.json'))
        if not matches:
            raise ValueError('No existing approved Claude proxy credential available')
        for p in matches:
            target = auth/p.name; shutil.copyfile(p, target); target.chmod(0o600)
        with socket.socket() as s:
            s.bind(('127.0.0.1',0)); port = s.getsockname()[1]
        config = {'host':'127.0.0.1','port':port,'auth-dir':str(auth),
                  'proxy-url':normal.get('proxy-url',''),'request-retry':0,'request-timeout':180,
                  'quota-exceeded':{'switch-project':False,'switch-preview-model':False},
                  'debug':False,'logging-to-file':False}
        (root/'config.yaml').write_text(yaml.safe_dump(config))
        endpoint = f'http://127.0.0.1:{port}'
        with (root/'private.log').open('w') as log:
            process = subprocess.Popen([str(PROXY),'-config',str(root/'config.yaml'),'-local-model'],stdout=log,stderr=subprocess.STDOUT)
            try:
                for _ in range(50):
                    if process.poll() is not None:
                        raise ValueError('Temporary VibeProxy backend exited before readiness')
                    try:
                        with urllib.request.urlopen(endpoint+'/v1/models',timeout=2) as r:
                            catalog = json.load(r)
                        break
                    except OSError: time.sleep(.2)
                else: raise ValueError('Proxy readiness timed out')
                if MODEL not in {row['id'] for row in catalog['data']}:
                    raise ValueError('Exact model missing; no substitution authorized')
                yield endpoint, {'backend':str(PROXY),'model':MODEL,'requestRetry':0,
                                 'modelFallback':False,'credential':'existing server-side auth, temporary local snapshot',
                                 'catalog':catalog,'identityLimit':'Proxy response names are not backend attestation.'}
            finally:
                process.terminate()
                try: process.wait(timeout=5)
                except subprocess.TimeoutExpired: process.kill(); process.wait()


def collect(runtime, dest):
    dest.mkdir(parents=True)
    for name in ['guard.json','settings.json','sandbox.sb','prompt.txt','execution.json','trace.jsonl','stderr.log','guard-events.jsonl']:
        p = runtime/name
        if p.exists(): shutil.copyfile(p,dest/name)
    fixture = runtime/'fixture'; artifacts = dest/'artifacts'; artifacts.mkdir()
    skipped = []; hashes = {}
    for p in sorted(fixture.rglob('*')):
        rel = p.relative_to(fixture)
        if p.is_symlink():
            skipped.append(str(rel)); continue
        if p.is_file():
            q = artifacts/rel; q.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,q)
            hashes[str(rel)] = sha(q)
    dump(dest/'artifact-manifest.json', {'files':hashes,'excludedSymlinks':skipped})


def run_variant(args, state):
    if not args.authorize_inference:
        raise ValueError('Launch authorization is required; prepare does not authorize inference')
    if args.variant not in state['variants']:
        raise ValueError('Unknown variant')
    verify_state(state)
    if not can_launch(state['records']):
        raise ValueError('Campaign blocked by budget/run limit or incomplete/failed attempt; no automatic retries')
    root = Path(state['root'])
    pending = [r for r in schedule(state,args.variant) if r['id'] not in {r['id'] for r in state['records']}]
    if not pending:
        print('Variant already completed; no reruns'); return
    with local_proxy() as (endpoint,routing):
        dump(root/f'routing-{args.variant}.json',routing)
        for planned in pending:
            if not can_launch(state['records']): break
            remaining = 15-sum(r['cost'] for r in state['records'])
            record = {**planned,'status':'running','cost':None}
            state['records'].append(record); dump(root/'state.json',state)
            runtime = Path(tempfile.mkdtemp(prefix='augclimb-run-')).resolve()
            plugin = root/'plugins'/args.variant/'.agents' if planned['arm']!='none' else None
            contract = (root/'tasks'/planned['task']/'prompt.md').read_text()
            try:
                observed = execute_one(runtime,plugin,{'contract':contract,'effective':prompt_for(contract,planned['arm'])},endpoint,remaining)
                record.update(observed)
            except Exception as exc:
                record.update(status='failed',cost=None,error=type(exc).__name__)
            finally:
                collect(runtime,root/'runs'/planned['id'])
                record['runtime'] = str(runtime)
                dump(root/'state.json',state)
            print(json.dumps(record),flush=True)
            if record['status']!='done': break


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='op',required=True)
    p = sub.add_parser('prepare'); p.add_argument('--tasks',required=True); p.add_argument('--release',required=True); p.add_argument('--state',required=True)
    p = sub.add_parser('add-candidate'); p.add_argument('--state',required=True); p.add_argument('--name',required=True); p.add_argument('--plugin',required=True)
    p = sub.add_parser('run'); p.add_argument('--state',required=True); p.add_argument('--variant',required=True); p.add_argument('--authorize-inference',action='store_true')
    p = sub.add_parser('status'); p.add_argument('--state',required=True)
    for op in ['guard','python-sandbox']:
        p = sub.add_parser(op); p.add_argument('--spec',required=True)
        if op=='python-sandbox': p.add_argument('words',nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.op=='guard':
        spec = json.loads(Path(args.spec).read_text()); event = json.load(sys.stdin)
        decision = guard_decision(spec,event.get('tool_name'),event.get('tool_input',{}))
        with (Path(spec['runtime'])/'guard-events.jsonl').open('a') as f:
            f.write(json.dumps({'tool':event.get('tool_name'),'input':event.get('tool_input',{}),'decision':decision})+'\n')
        print(json.dumps({'hookSpecificOutput':{'hookEventName':'PreToolUse',**decision}})); return
    if args.op=='python-sandbox':
        raise SystemExit(python_sandbox(json.loads(Path(args.spec).read_text()),args.words))
    if args.op=='prepare': prepare(args); return
    root = Path(args.state).resolve()
    with (root/'lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        state = json.loads((root/'state.json').read_text())
        if args.op=='status': print(json.dumps(state,indent=2)); return
        verify_state(state)
        if args.op=='add-candidate': add_candidate(args,state)
        elif args.op=='run': run_variant(args,state)


if __name__=='__main__':
    main()
