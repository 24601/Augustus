"""Actual Claude CLI against scripted loopback responses: zero model inference."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import tempfile
import threading
import unittest

import instrument as m


class LocalCLIIsolationTest(unittest.TestCase):
    def test_actual_cli_hooks_tools_and_three_arm_loading(self):
        evidence = m.HERE/'selftest'
        evidence.mkdir(exist_ok=True)
        release = m.HERE.parent/'081-vibeproxy-results/release-agents'
        plugin = evidence/'.agents'
        if not plugin.exists():
            m.snapshot_plugin(release, plugin)
        for arm in ['none','auto','explicit']:
            runtime = Path(tempfile.mkdtemp(prefix=f'mock-{arm}-',dir=evidence)).resolve()
            outside = runtime/'forbidden.txt'; outside.write_text('HIDDEN_SENTINEL')
            probe = (
                'import json,pathlib,socket,os\n'
                'results={}\n'
                'def test(name,fn):\n'
                ' try: fn(); results[name]="ALLOWED"\n'
                ' except OSError: results[name]="DENIED"\n'
                f'test("read",lambda:pathlib.Path({str(outside)!r}).read_text())\n'
                f'test("write",lambda:pathlib.Path({str(runtime/"escaped.txt")!r}).write_text("bad"))\n'
                'test("network",lambda:socket.create_connection(("127.0.0.1",8317),timeout=1))\n'
                'results["credential"]=os.environ.get("ANTHROPIC_AUTH_TOKEN")\n'
                'pathlib.Path("checks.json").write_text(json.dumps(results))\n'
                'print(json.dumps(results))\n'
            )
            actions = []
            if arm != 'none':
                actions += [('Skill', {'skill': '.agents:augustus'}),
                            ('Skill', {'skill': '.agents:augustus-train'})]
            actions += [
                ('Write', {'file_path':str(runtime/'fixture/solution.py'),'content':probe}),
                ('Bash', {'command':'python3 solution.py','description':'Run fixture checks'}),
                ('Read', {'file_path':str(outside)}),
                ('Write', {'file_path':str(runtime/'escaped-via-tool.txt'),'content':'bad'}),
            ]
            requests = []

            class Handler(BaseHTTPRequestHandler):
                def log_message(self,*args): pass
                def do_HEAD(self):
                    self.send_response(404); self.end_headers()
                def do_POST(self):
                    body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                    if 'count_tokens' in self.path:
                        data = b'{"input_tokens":1}'
                        self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(data);return
                    index = len(requests)
                    requests.append({'model':body.get('model'),'tools':[x['name'] for x in body.get('tools',[])]})
                    if index < len(actions):
                        name,values = actions[index]
                        block = {'type':'tool_use','id':f'toolu_mock_{index}','name':name,'input':values}
                        reason = 'tool_use'
                    else:
                        block = {'type':'text','text':'Offline scripted interface check complete. No inference occurred.'}
                        reason = 'end_turn'
                    message = {'id':f'msg_mock_{index}','type':'message','role':'assistant',
                               'model':m.MODEL,'content':[block],'stop_reason':reason,'stop_sequence':None,
                               'usage':{'input_tokens':1,'output_tokens':1}}
                    if not body.get('stream'):
                        self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps(message).encode());return
                    self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
                    def emit(kind,data):
                        self.wfile.write(('event: '+kind+'\ndata: '+json.dumps({'type':kind,**data})+'\n\n').encode());self.wfile.flush()
                    emit('message_start',{'message':{**message,'content':[],'stop_reason':None}})
                    if block['type']=='tool_use':
                        emit('content_block_start',{'index':0,'content_block':{**block,'input':{}}})
                        emit('content_block_delta',{'index':0,'delta':{'type':'input_json_delta','partial_json':json.dumps(block['input'])}})
                    else:
                        emit('content_block_start',{'index':0,'content_block':{'type':'text','text':''}})
                        emit('content_block_delta',{'index':0,'delta':{'type':'text_delta','text':block['text']}})
                    emit('content_block_stop',{'index':0})
                    emit('message_delta',{'delta':{'stop_reason':reason,'stop_sequence':None},'usage':{'output_tokens':1}})
                    emit('message_stop',{})

            server = ThreadingHTTPServer(('127.0.0.1',0),Handler)
            thread = threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            try:
                observed = m.execute_one(runtime, plugin if arm!='none' else None,
                                         {'contract':'Offline interface fixture.','effective':m.prompt_for('Offline interface fixture.',arm)},
                                         f'http://127.0.0.1:{server.server_port}',15)
            finally:
                server.shutdown();server.server_close();thread.join()
            m.dump(runtime/'offline-observation.json',{'notInference':True,'result':observed,'requests':requests})
            self.assertEqual(observed['status'],'done',(observed,(runtime/'stderr.log').read_text()))
            self.assertEqual(len(requests),len(actions)+1)
            self.assertTrue(all(set(x['tools'])<=set(m.TOOLS) for x in requests))
            self.assertFalse((runtime/'escaped.txt').exists())
            self.assertFalse((runtime/'escaped-via-tool.txt').exists())
            self.assertEqual(json.loads((runtime/'fixture/checks.json').read_text()),
                             {'read':'DENIED','write':'DENIED','network':'DENIED','credential':None})
            events = [json.loads(x) for x in (runtime/'guard-events.jsonl').read_text().splitlines()]
            self.assertTrue(any(x['tool']=='Read' and x['decision']['permissionDecision']=='deny' for x in events))
            if arm!='none':
                trace = (runtime/'trace.jsonl').read_text()
                self.assertIn('Base directory for this skill:',trace)
                self.assertIn('# Augustus Train',trace)
                self.assertEqual(sum(x['tool']=='Skill' and x['decision']['permissionDecision']=='allow' for x in events),2)


if __name__=='__main__': unittest.main()
