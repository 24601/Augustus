# A reusable policy without fitting a model

A field team selects one operating mode before learning which environmental
scenario will occur. Its engineering table specifies exact integer loss units,
not probabilities. Build a reusable minimax-regret policy artifact, then apply
it to a current subset of permitted modes. There is no training step.

Implement:

* `compile_policy(spec: dict) -> dict`
* `decide(artifact: dict, allowed: list[str], max_regret: int) -> dict`
* `solve(request: dict) -> dict`, used by the CLI.

`spec` has `policy_id` (nonempty string), `scenarios` (nonempty unique strings),
and `modes` (nonempty list of objects with unique nonempty `name` strings and
`losses`, an equally long list of nonnegative integers). Each losses position
corresponds to the same position in scenarios. Names/scenarios may be unsorted.
At most 8 modes and 8 scenarios. These inputs are valid; reject nothing beyond
the explicitly stated serving case below.

The artifact MUST be exactly this JSON-compatible object, without extra keys:

```
{"schema": 1, "policy_id": <id>, "scenarios": <sorted scenario names>,
 "modes": [{"name": <name>, "losses": <losses in sorted scenario order>}, ...]}
```

Modes are sorted lexicographically by name. Never mutate inputs, retain aliases
to their lists, or depend on module-global state. The artifact must still work
after a JSON serialization/reload in a fresh process. No reference to the
original input is available then.

For `decide`, `allowed` is a possibly empty list of unique mode names. If ANY
name is absent from the artifact, return `{"status":"defer","reason":"unknown_mode"}`.
This takes precedence over other outcomes. If it is empty, return
`{"status":"defer","reason":"no_mode"}`.

Otherwise use ONLY allowed modes for BOTH selecting a mode and computing each
scenario's best achievable loss. For mode a, scenario s:

`regret(a,s) = loss(a,s) - min(loss(b,s) for b in allowed)`.

A mode's worst regret is the maximum across scenarios. Select the mode with
minimum worst regret; break ties by lower maximum original loss, then
lexicographically smaller mode name. `max_regret` is a nonnegative integer.
Accept equality at the limit. If the selected mode's worst regret exceeds it,
return `{"status":"defer","reason":"regret_limit"}`. Otherwise return exactly
`{"status":"act","mode":<name>,"worst_regret":<integer>}`.

`solve` accepts one of two forms:

* `{"op":"compile","spec":...}` returns the artifact directly.
* `{"op":"decide","artifact":...,"allowed":...,"max_regret":...}` returns
  the decision directly.

All artifact inputs have the specified valid schema. Arbitrary malformed input
handling is out of scope. Do not use expected loss: scenario probabilities
were never supplied. This is deterministic policy execution, not a prediction.

`input.json` is a public compile example. You can inspect its artifact with the
CLI, then send a separate decide request using that artifact.
