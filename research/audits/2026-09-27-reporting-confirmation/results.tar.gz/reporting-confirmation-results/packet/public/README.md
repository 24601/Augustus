# Protected confirmation tasks

Each task is independent. Implement `solution.py` in that task's directory,
using Python 3.11+ and the standard library only. No network, dependencies,
model training, or files outside the task directory are needed. Each task has
a budget of 20 agent turns and 180 seconds. The prompt and examples are the
entire contract; hidden tests check the same contract, not extra requirements.
Inputs are small. Do not change the task prompt or input examples.

Each module must support both the specified callable and `python3 solution.py`.
The CLI reads one JSON object from stdin, writes exactly one JSON object plus
a newline to stdout, and exits zero. Imports must have no input/output effects.
Only explicitly described invalid cases need handling.
