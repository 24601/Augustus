# Serve a complete, identified distribution or defer

A service receives an unordered batch of predictor replies for queued cases.
Its downstream actions have different losses at different severity levels.
The model's output is an ORDINAL categorical distribution, not a calibrated
probability of action success. Build a pure, offline adapter that aligns each
distribution by level name, applies an explicit loss policy, and defers cases
whose evidence is unusable. No model fitting or network calls are needed.

Implement `solve(request: dict) -> dict`, and the standard JSON stdin/stdout CLI.

Request fields:

* `now`: nonnegative integer seconds.
* `model_version`: nonempty string identifying the required model revision.
* `levels`: unique nonempty severity names, 2–5 entries in policy order.
* `actions`: 1–5 objects with unique nonempty `name` and a `losses` list of
  integers from 0 through 10000 aligned to `levels`.
* `cases`: 0–10 objects with unique `id` strings and `ttl` nonnegative integer
  seconds. Return decisions in this order.
* `replies`: 0–20 objects; arrival order has no significance. Each has `id`,
  `model_version`, `observed_at` (integer seconds), `levels` (list of strings),
  and `weights` (list). A weight is an arbitrary unit of nonnegative mass,
  not necessarily normalized. JSON values may include bool/null/string as
  intentionally invalid weights, but no NaN/Infinity. Numeric weights are
  integers or finite floats, all multiples of 0.125 with absolute values at
  most 10000.

Policy and case fields are valid. Replies deliberately may be unusable.
Process each case independently, with this exact precedence:

1. Zero replies with its ID: defer reason `missing`.
2. More than one reply with its ID: defer reason `duplicate`, EVEN IF just one
   has the right version. Do not pick a latest reply. Replies for unknown case
   IDs are ignored entirely.
3. Unique reply's version differs from request: defer reason `version`.
4. `observed_at > now` OR `now - observed_at > ttl`: defer reason `freshness`.
   Exactly the TTL boundary is valid.
5. Defer reason `distribution` unless reply levels are a permutation of ALL
   policy levels exactly once, len(weights) equals len(reply levels), every
   weight has type int or float (not bool), every weight is nonnegative, and
   their sum is positive. Do not impute missing levels or renormalize a partial
   distribution. Zero weights for explicitly included levels are valid.
6. For a usable distribution, normalize by total mass, align by level name,
   and minimize expected action loss. Ties go to lexicographically smaller
   action name, regardless of action order. Inputs avoid near ties: costs
   are either exactly equal or differ by at least 1e-7. Never substitute the
   mean severity for the whole distribution.

Return exactly `{"decisions":[...]}`. Each deferred entry is
`{"id":<case id>,"status":"defer","reason":<reason>}`. Each acted entry is
`{"id":<case id>,"status":"act","action":<name>,"expected_loss":<number>}`.
Expected loss must be accurate to absolute error 1e-9. Do not mutate the request.
No other keys, external effects, or persistence are needed. Inputs are small,
so a simple direct implementation is sufficient.

`input.json` illustrates a valid request. Add your own checks for unusable
evidence and meaningful policy differences, not just JSON shape.
