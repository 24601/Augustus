import json
import sys


def solve(request):
    decisions = []
    for case in request['cases']:
        matches = [r for r in request['replies'] if r['id'] == case['id']]
        reason = None
        if not matches:
            reason = 'missing'
        elif len(matches) > 1:
            reason = 'duplicate'
        else:
            reply = matches[0]
            if reply['model_version'] != request['model_version']:
                reason = 'version'
            elif not 0 <= request['now'] - reply['observed_at'] <= case['ttl']:
                reason = 'freshness'
            elif (sorted(reply['levels']) != sorted(request['levels'])
                  or len(reply['weights']) != len(reply['levels'])
                  or any(type(w) not in (int, float) or w < 0 for w in reply['weights'])
                  or sum(reply['weights']) <= 0):
                reason = 'distribution'
        decision = {'id': case['id']}
        if reason:
            decision.update(status='defer', reason=reason)
        else:
            mass = dict(zip(reply['levels'], reply['weights']))
            total = sum(mass.values())
            loss, action = min(
                (sum(mass[level] * cost for level, cost in zip(request['levels'], a['losses'])) / total,
                 a['name']) for a in request['actions'])
            decision.update(status='act', action=action, expected_loss=loss)
        decisions.append(decision)
    return {'decisions': decisions}


if __name__ == '__main__':
    print(json.dumps(solve(json.load(sys.stdin))))
