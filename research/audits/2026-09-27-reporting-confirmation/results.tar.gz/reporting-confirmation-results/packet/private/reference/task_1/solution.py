import json
import sys


def compile_policy(spec):
    order = sorted(range(len(spec['scenarios'])), key=spec['scenarios'].__getitem__)
    return {'schema': 1, 'policy_id': spec['policy_id'],
            'scenarios': [spec['scenarios'][i] for i in order],
            'modes': [{'name': m['name'], 'losses': [m['losses'][i] for i in order]}
                      for m in sorted(spec['modes'], key=lambda m: m['name'])]}


def decide(artifact, allowed, max_regret):
    modes = {m['name']: m['losses'] for m in artifact['modes']}
    if any(a not in modes for a in allowed):
        return {'status': 'defer', 'reason': 'unknown_mode'}
    if not allowed:
        return {'status': 'defer', 'reason': 'no_mode'}
    best = [min(modes[a][s] for a in allowed) for s in range(len(artifact['scenarios']))]
    ranked = [(max(v - b for v, b in zip(modes[a], best)), max(modes[a]), a)
              for a in allowed]
    regret, _, name = min(ranked)
    if regret > max_regret:
        return {'status': 'defer', 'reason': 'regret_limit'}
    return {'status': 'act', 'mode': name, 'worst_regret': regret}


def solve(request):
    if request['op'] == 'compile':
        return compile_policy(request['spec'])
    return decide(request['artifact'], request['allowed'], request['max_regret'])


if __name__ == '__main__':
    print(json.dumps(solve(json.load(sys.stdin))))
