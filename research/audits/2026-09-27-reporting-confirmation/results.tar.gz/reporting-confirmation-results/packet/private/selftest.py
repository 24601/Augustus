"""Validate references and plausible semantic mutants; never reveal inputs."""
import json
from pathlib import Path
import tempfile
import grade

ROOT = Path(__file__).resolve().parent
MUTATIONS = [
    ('task_1', 'global_comparator', 'min(modes[a][s] for a in allowed)',
     'min(modes[a][s] for a in modes)'),
    ('task_1', 'exclusive_cap', 'if regret > max_regret:', 'if regret >= max_regret:'),
    ('task_1', 'missing_second_tie_break', 'max(modes[a]), a)', '0, a)'),
    ('task_1', 'scenario_misalignment', "[m['losses'][i] for i in order]", "list(m['losses'])"),
    ('task_2', 'positional_weights', "mass = dict(zip(reply['levels'], reply['weights']))",
     "mass = dict(zip(request['levels'], reply['weights']))"),
    ('task_2', 'stale_boundary', "<= case['ttl']", "< case['ttl']"),
    ('task_2', 'boolean_mass', 'type(w) not in (int, float)', 'not isinstance(w, (int, float))'),
    ('task_2', 'deduplicate_latest', "matches = [r for r in request['replies'] if r['id'] == case['id']]",
     "matches = sorted([r for r in request['replies'] if r['id'] == case['id']], key=lambda r: r['observed_at'])[-1:]"),
]


def anchor_oracles():
    spec = grade.spec_for([[0, 0], [8, 8], [6, 10]])
    artifact = {'schema': 1, 'policy_id': 'private-policy', 'scenarios': ['a', 'z'],
                'modes': [{'name': 'alpha', 'losses': [8, 8]},
                          {'name': 'middle', 'losses': [10, 6]},
                          {'name': 'zeta', 'losses': [0, 0]}]}
    anchors = [(grade.artifact_oracle(spec), artifact),
               (grade.decision_oracle(artifact, ['alpha', 'middle'], 2),
                {'status': 'act', 'mode': 'alpha', 'worst_regret': 2}),
               (grade.decision_oracle(artifact, ['alpha', 'middle'], 1),
                {'status': 'defer', 'reason': 'regret_limit'}),
               (grade.decision_oracle(artifact, ['middle'], 0),
                {'status': 'act', 'mode': 'middle', 'worst_regret': 0})]
    req = grade.base_request()
    anchors.append((grade.serving_oracle(req), {'decisions': [
        {'id': 'item', 'status': 'act', 'action': 'visit', 'expected_loss': 4.0}]}))
    req['replies'][0]['weights'] = [0, 0, 10]
    anchors.append((grade.serving_oracle(req), {'decisions': [
        {'id': 'item', 'status': 'act', 'action': 'wait', 'expected_loss': 0.0}]}))
    req['replies'][0]['weights'] = [0.125, 0.5, 1.375]
    anchors.append((grade.serving_oracle(req), {'decisions': [
        {'id': 'item', 'status': 'act', 'action': 'wait', 'expected_loss': 0.625}]}))
    for actual, expected in anchors:
        grade.equal(actual, expected)
    return len(anchors)


def main():
    report = {'oracle_anchors_passed': anchor_oracles(), 'reference': {}, 'mutants': []}
    for task in ['task_1', 'task_2']:
        result = grade.grade(ROOT / 'reference', task)
        assert result['failed'] == 0, result
        report['reference'][task] = result
    for task, name, before, after in MUTATIONS:
        source = (ROOT / 'reference' / task / 'solution.py').read_text()
        assert source.count(before) == 1, name
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp) / task
            dest.mkdir()
            (dest / 'solution.py').write_text(source.replace(before, after))
            result = grade.grade(Path(tmp), task)
            assert result['failed'] > 0, f'surviving mutant: {name}'
            # Require rejection by an output assertion, not import/syntax/runtime failure.
            assert any(f['check'].startswith('call-') and f['error'].startswith('AssertionError:')
                       for f in result['failures']), name
            report['mutants'].append({'task': task, 'name': name, 'passed': result['passed'],
                                      'failed': result['failed'], 'rejected': True})
    (ROOT / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'references': {k: {'passed': v['passed'], 'failed': v['failed'],
                                        'input_cases': v['input_cases']} for k, v in report['reference'].items()},
                      'oracle_anchors_passed': report['oracle_anchors_passed'],
                      'mutants_rejected': len(report['mutants'])}, indent=2))


if __name__ == '__main__':
    main()
