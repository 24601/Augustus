"""Private deterministic grading. No imports from the known-good reference."""
import argparse
import contextlib
import copy
from fractions import Fraction
import importlib.util
import io
import json
import math
from pathlib import Path
import random
import subprocess
import sys


def artifact_oracle(spec):
    rows = []
    for mode in spec['modes']:
        paired = dict(zip(spec['scenarios'], mode['losses']))
        rows.append({'name': mode['name'], 'losses': [paired[s] for s in sorted(paired)]})
    return {'schema': 1, 'policy_id': spec['policy_id'],
            'scenarios': sorted(spec['scenarios']), 'modes': sorted(rows, key=lambda r: r['name'])}


def decision_oracle(artifact, allowed, cap):
    by_name = {m['name']: m for m in artifact['modes']}
    if set(allowed) - set(by_name):
        return {'status': 'defer', 'reason': 'unknown_mode'}
    if len(allowed) == 0:
        return {'status': 'defer', 'reason': 'no_mode'}
    # Independent pairwise regret enumeration, not per-column minima.
    ranks = {}
    for a in allowed:
        regrets = []
        for b in allowed:
            for s in range(len(artifact['scenarios'])):
                regrets.append(by_name[a]['losses'][s] - by_name[b]['losses'][s])
        ranks[a] = (max(regrets), sorted(by_name[a]['losses'])[-1], a)
    winner = sorted(allowed, key=ranks.__getitem__)[0]
    regret = ranks[winner][0]
    if regret <= cap:
        return {'status': 'act', 'mode': winner, 'worst_regret': regret}
    return {'status': 'defer', 'reason': 'regret_limit'}


def serving_oracle(req):
    index = {}
    for reply in req['replies']:
        index.setdefault(reply['id'], []).append(reply)
    result = []
    for case in req['cases']:
        entries = index.get(case['id'], [])
        reason = None
        if len(entries) != 1:
            reason = 'missing' if not entries else 'duplicate'
        else:
            r = entries[0]
            if r['model_version'] != req['model_version']:
                reason = 'version'
            elif r['observed_at'] < req['now'] - case['ttl'] or r['observed_at'] > req['now']:
                reason = 'freshness'
            else:
                valid = len(r['levels']) == len(req['levels']) == len(r['weights'])
                valid = valid and all(r['levels'].count(level) == 1 for level in req['levels'])
                valid = valid and all(type(w) in (int, float) and w >= 0 for w in r['weights'])
                if not valid or not any(r['weights']):
                    reason = 'distribution'
        if reason is not None:
            result.append({'id': case['id'], 'status': 'defer', 'reason': reason})
            continue
        # Exact rational accumulation; locate weights by name without zip.
        masses = [Fraction(r['weights'][r['levels'].index(level)]) for level in req['levels']]
        exact = {}
        for action in req['actions']:
            numerator = Fraction(0)
            for i in range(len(masses)):
                numerator += masses[i] * action['losses'][i]
            exact[action['name']] = numerator / sum(masses)
        winner = sorted(exact, key=lambda name: (exact[name], name))[0]
        result.append({'id': case['id'], 'status': 'act', 'action': winner,
                       'expected_loss': float(exact[winner])})
    return {'decisions': result}


def spec_for(matrix):
    return {'policy_id': 'private-policy', 'scenarios': ['z', 'a', 'm'][:len(matrix[0])],
            'modes': [{'name': name, 'losses': row} for name, row in zip(['zeta', 'alpha', 'middle'], matrix)]}


def task1_inputs():
    # Mean vs regret, allowed comparator, both tie-break levels, zeros/singleton.
    specs = [spec_for(m) for m in [
        [[0, 12, 0], [5, 5, 5], [9, 0, 9]],
        [[0, 0], [8, 8], [6, 10]],
        [[7, 2], [4, 5]], [[3, 3], [3, 3]], [[0]],
    ]]
    rng = random.Random(812907)
    for _ in range(48):
        n, k = rng.randint(1, 8), rng.randint(1, 8)
        scenes = [f's{i}' for i in range(k)]
        rng.shuffle(scenes)
        modes = [{'name': f'm{i}', 'losses': [rng.randrange(25) for _ in range(k)]} for i in range(n)]
        rng.shuffle(modes)
        specs.append({'policy_id': f'p{_}', 'scenarios': scenes, 'modes': modes})
    for spec in specs:
        yield {'op': 'compile', 'spec': spec}, artifact_oracle(spec)
        artifact = artifact_oracle(spec)
        names = [m['name'] for m in spec['modes']]
        subsets = [[], names[:1], names, names[1:], names + ['absent']]
        for allowed in subsets:
            unconstrained = decision_oracle(artifact, allowed, 100000)
            cap = unconstrained.get('worst_regret', 0)
            for limit in sorted({0, cap, max(0, cap - 1), cap + 1}):
                req = {'op': 'decide', 'artifact': artifact, 'allowed': allowed, 'max_regret': limit}
                yield req, decision_oracle(artifact, allowed, limit)


def base_request():
    return {'now': 40, 'model_version': 'r7', 'levels': ['low', 'mid', 'high'],
            'actions': [{'name': 'wait', 'losses': [0, 0, 10]},
                        {'name': 'visit', 'losses': [4, 4, 4]}],
            'cases': [{'id': 'item', 'ttl': 6}],
            'replies': [{'id': 'item', 'model_version': 'r7', 'observed_at': 34,
                         'levels': ['high', 'low', 'mid'], 'weights': [5, 5, 0]}]}


def task2_inputs():
    base = base_request()
    yield base
    r = copy.deepcopy(base)
    r['replies'][0]['weights'] = [0, 0, 10]  # Same ordinal mean, different tail.
    yield r
    for levels, weights in [(['low', 'high'], [9, 1]),
                            (['low', 'low', 'high'], [1, 2, 3]),
                            (['low', 'mid', 'other'], [1, 2, 3]),
                            (['low', 'mid', 'high'], [1, 2]),
                            (['low', 'mid', 'high'], [1, 2, 3, 4]),
                            ([], []), (['low', 'mid', 'high'], [0, 0, 0]),
                            (['low', 'mid', 'high'], [True, 1, 1]),
                            (['low', 'mid', 'high'], [None, 1, 1]),
                            (['low', 'mid', 'high'], ['1', 1, 1]),
                            (['low', 'mid', 'high'], [-0.125, 1, 1]),
                            (['high', 'mid', 'low'], [0.125, 0.5, 1.375])]:
        r = copy.deepcopy(base)
        r['replies'][0].update(levels=levels, weights=weights)
        yield r
    for age in [-1, 0, 5, 6, 7]:
        for version in ['r7', 'old']:
            r = copy.deepcopy(base)
            r['replies'][0].update(observed_at=r['now'] - age, model_version=version)
            yield r
    for duplicate in [False, True]:
        r = copy.deepcopy(base)
        if duplicate:
            other = copy.deepcopy(r['replies'][0])
            other.update(model_version='old', observed_at=400, weights=[None])
            r['replies'].insert(0, other)
        else:
            r['replies'] = []
        yield r
    for version, age in [('old', 400), ('r7', 400)]:
        r = copy.deepcopy(base)
        r['replies'][0].update(model_version=version, observed_at=age, weights=[None])
        yield r
    r = copy.deepcopy(base)
    r['cases'] = []
    yield r
    r = copy.deepcopy(base)
    r['actions'] = [{'name': 'z', 'losses': [1, 3, 1]}, {'name': 'a', 'losses': [1, 1, 1]}]
    yield r
    r = copy.deepcopy(base)
    r['cases'][0]['ttl'] = 0
    r['replies'][0]['observed_at'] = r['now']
    yield r
    # Independent IDs: one malformed orphan must not poison known cases.
    r = copy.deepcopy(base)
    r['cases'].insert(0, {'id': 'missing', 'ttl': 0})
    orphan = copy.deepcopy(r['replies'][0])
    orphan.update(id='orphan', model_version='old', weights=[None])
    r['replies'].insert(0, orphan)
    yield r
    rng = random.Random(481991)
    for i in range(80):
        k = rng.randint(2, 5)
        levels = [f'L{j}' for j in range(k)]
        actions = [{'name': f'A{j}', 'losses': [rng.randrange(20) for _ in levels]}
                   for j in range(rng.randint(1, 5))]
        rng.shuffle(actions)
        r = {'now': 100, 'model_version': 'v', 'levels': levels, 'actions': actions,
             'cases': [{'id': f'c{j}', 'ttl': j} for j in range(10)], 'replies': []}
        for case in r['cases']:
            ordering = rng.sample(levels, k)
            weights = [rng.randint(1, 50) / 8 for _ in ordering]
            r['replies'].append({'id': case['id'], 'model_version': 'v',
                                 'observed_at': 100 - case['ttl'], 'levels': ordering,
                                 'weights': weights})
        rng.shuffle(r['replies'])
        yield r
        # Positive rescaling and arrival/action permutation should preserve decisions.
        transformed = copy.deepcopy(r)
        transformed['actions'].reverse()
        transformed['replies'].reverse()
        for reply in transformed['replies']:
            reply['weights'] = [w * 8 for w in reply['weights']]
        yield transformed


def equal(actual, expected):
    if isinstance(expected, dict):
        assert type(actual) is dict and actual.keys() == expected.keys(), 'object keys/type'
        for key in expected:
            equal(actual[key], expected[key])
    elif isinstance(expected, list):
        assert type(actual) is list and len(actual) == len(expected), 'list shape'
        for a, b in zip(actual, expected):
            equal(a, b)
    elif isinstance(expected, float):
        assert type(actual) in (int, float) and math.isfinite(actual), 'numeric output'
        assert abs(actual - expected) <= 1e-9, 'numeric mismatch'
    else:
        assert type(actual) is type(expected) and actual == expected, 'value/type mismatch'


def load(path):
    spec = importlib.util.spec_from_file_location('candidate', path)
    module = importlib.util.module_from_spec(spec)
    out, err = io.StringIO(), io.StringIO()
    old_stdin = sys.stdin
    try:
        sys.stdin = io.StringIO('')
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            spec.loader.exec_module(module)
    finally:
        sys.stdin = old_stdin
    assert not out.getvalue() and not err.getvalue(), 'import side effect'
    return module


def cli(path, request):
    p = subprocess.run([sys.executable, '-B', str(path)], input=json.dumps(request),
                       capture_output=True, text=True, timeout=3, cwd=path.parent)
    assert p.returncode == 0, 'CLI nonzero exit'
    assert p.stdout.endswith('\n') and len(p.stdout.splitlines()) == 1, 'CLI framing'
    return json.loads(p.stdout)


def grade(root, task):
    path = Path(root).resolve() / task / 'solution.py'
    results = {'passed': 0, 'failed': 0, 'failures': []}

    def check(label, fn):
        try:
            fn()
            results['passed'] += 1
        except Exception as exc:
            results['failed'] += 1
            results['failures'].append({'check': label, 'error': type(exc).__name__ + ': ' + str(exc)[:160]})

    try:
        module = load(path)
    except Exception as exc:
        return {'passed': 0, 'failed': 1, 'failures': [{'check': 'import', 'error': type(exc).__name__}]}
    results['passed'] += 1
    pairs = list(task1_inputs()) if task == 'task_1' else [(r, serving_oracle(r)) for r in task2_inputs()]
    for i, (request, expected) in enumerate(pairs):
        def call(request=request, expected=expected):
            data = copy.deepcopy(request)
            equal(module.solve(data), expected)
            equal(data, request)
        check(f'call-{i}', call)
        if task == 'task_1':
            def direct(request=request, expected=expected):
                data = copy.deepcopy(request)
                if data['op'] == 'compile':
                    equal(module.compile_policy(data['spec']), expected)
                else:
                    equal(module.decide(data['artifact'], data['allowed'], data['max_regret']), expected)
                equal(data, request)
            check(f'direct-{i}', direct)
        if i < 32 or i % 47 == 0:
            check(f'cli-{i}', lambda r=request, e=expected: equal(cli(path, r), e))
    if task == 'task_1':
        def alias_check():
            data = spec_for([[2, 5], [8, 1]])
            snapshot = copy.deepcopy(data)
            out = module.compile_policy(data)
            equal(data, snapshot)
            out['modes'][0]['losses'][0] = 9876
            out['scenarios'][0] = 'altered'
            equal(data, snapshot)
            data = spec_for([[2, 5], [8, 1]])
            out = module.compile_policy(data)
            saved = copy.deepcopy(out)
            data['modes'][0]['losses'][0] = 9999
            data['scenarios'][0] = 'changed'
            equal(out, saved)
        check('ownership', alias_check)

        def roundtrip():
            spec = spec_for([[0, 12, 0], [5, 5, 5], [9, 0, 9]])
            artifact = cli(path, {'op': 'compile', 'spec': spec})
            equal(artifact, artifact_oracle(spec))
            req = {'op': 'decide', 'artifact': artifact, 'allowed': ['alpha', 'middle'], 'max_regret': 100}
            equal(cli(path, req), decision_oracle(artifact_oracle(spec), req['allowed'], 100))
        check('fresh-process-roundtrip', roundtrip)
    results['input_cases'] = len(pairs)
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate_root', type=Path)
    parser.add_argument('--task', choices=['task_1', 'task_2'])
    args = parser.parse_args()
    tasks = [args.task] if args.task else ['task_1', 'task_2']
    report = {task: grade(args.candidate_root, task) for task in tasks}
    print(json.dumps(report, indent=2))
    sys.exit(int(any(r['failed'] for r in report.values())))
