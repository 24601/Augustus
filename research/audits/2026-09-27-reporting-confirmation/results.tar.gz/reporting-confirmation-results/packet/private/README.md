# Private confirmation grader — never mount during implementation

Public prompts/inputs live in a separate archive. This directory contains
private test generation, independent expected-value oracles, known-good
implementations, semantic mutation recipes, and self-test results. No private
file may be supplied to an implementation agent or candidate-authoring
coordinator until finalists and their selection policy are frozen.

After freezing candidate code, place its two `solution.py` files beneath
`CANDIDATE_ROOT/task_1/` and `CANDIDATE_ROOT/task_2/`. Run in an offline,
disposable isolated environment:

```
timeout 60s python3 -B grade.py CANDIDATE_ROOT
```

Optional `--task task_1` or `--task task_2` grades one task. Exit zero means all
checks passed. All checks are required; partial counts are diagnostic, not
permission to retune against confirmation. Import errors count as failure.
Timeouts/process failure count as failure; do not treat absent reports as pass.
The grader is not an adversarial-code sandbox. The operator must provide the
isolation and freeze candidate code before revealing any grader files.

Reproduce grader validation with `python3 -B selftest.py`. This creates mutants
in disposable temporary directories and writes `validation.json`. Oracles do
not import reference code: task 1 uses exhaustive pairwise regret; task 2 uses
exact rational arithmetic. Tests cover callable/CLI parity, reload, ordering,
input ownership, exact boundaries, competing policy interpretations, invalid
evidence, and seeded small cases. Fixed seeds are private and frozen.

Budget: 20 turns/180 seconds per implementation task. References and mutants
are executable validation instruments, not agent completion-rate evidence.
This packet was created fresh for Augustus v0.8.1; it does not copy repository
scenario sets, audits, parent development tasks, or existing implementations.
No skill files are changed. No external services or dependencies are used.
