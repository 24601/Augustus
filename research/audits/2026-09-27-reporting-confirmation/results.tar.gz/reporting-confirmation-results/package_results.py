"""Allowlisted research export after all inference and frozen grading finish."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

ROOT=Path(__file__).resolve().parent
DEST=ROOT.parent/'reporting-confirmation-results'
ARCHIVE=ROOT.parents[3]/'reporting-confirmation-results.tar.gz'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    state=json.loads((ROOT/'state/state.json').read_text())
    grade=json.loads((ROOT/'grading/summary.json').read_text())
    assert len(state['records'])==len(grade['records'])==18
    assert all(r['status']!='running' for r in state['records'])
    assert not DEST.exists() and not ARCHIVE.exists(), 'Never replace an evidence export'
    DEST.mkdir()
    for directory in ['state','old','new','packet','grading']:
        shutil.copytree(ROOT/directory,DEST/directory,ignore=shutil.ignore_patterns('lock','__pycache__'))
    for name in ['README.md','RESULTS.md','reporting-confirmation-contract.md','grade_runs.py',
                 'package_results.py','observations.json','grading-console.jsonl','grading-errors.txt']:
        shutil.copyfile(ROOT/name,DEST/name)
    for name in ['confirmation-public-tasks.tar','confirmation-private-grader.tar']:
        shutil.copyfile(ROOT.parent/name,DEST/name)
    instrument=DEST/'instrument';instrument.mkdir()
    for name in ['instrument.py','test_instrument.py','test_cli.py','offline-validation.txt','preparation.json']:
        shutil.copyfile(ROOT/'instrument'/name,instrument/name)
    offline=DEST/'offline-validation';offline.mkdir()
    for runtime in sorted((ROOT/'instrument/selftest').glob('mock-*')):
        target=offline/runtime.name;target.mkdir()
        for name in ['trace.jsonl','stderr.log','guard-events.jsonl','offline-observation.json',
                     'settings.json','guard.json','sandbox.sb','prompt.txt','execution.json']:
            if (runtime/name).is_file():shutil.copyfile(runtime/name,target/name)
        if (runtime/'fixture').exists():shutil.copytree(runtime/'fixture',target/'fixture')
    patterns=[rb'sk-ant-[A-Za-z0-9_-]{20,}',rb'sk-[A-Za-z0-9]{32,}',
              rb'eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}']
    for p in DEST.rglob('*'):
        assert not p.is_symlink()
        if p.is_file():
            assert not any(re.search(pattern,p.read_bytes()) for pattern in patterns),f'Secret-shaped bytes: {p.name}'
    (DEST/'export-receipt.json').write_text(json.dumps({
        'authenticationExported':False,'runtimeHomesExported':False,
        'privateProxyConfigurationOrLogsExported':False,'credentialShapeScan':'passed',
        'traceAndSourceBytes':'unchanged','nonsecretAbsolutePaths':'retained',
        'privateEvaluationMaterial':'consumed frozen packet; explicitly authorized for independent replay',
        'offlineMockResults':'separate from inference and cost denominators'},indent=2)+'\n')
    files=sorted(p for p in DEST.rglob('*') if p.is_file())
    (DEST/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(DEST)}\n' for p in files))
    with tarfile.open(ARCHIVE,'w:gz') as out:out.add(DEST,arcname=DEST.name)
    print(json.dumps({'archive':str(ARCHIVE),'sha256':sha(ARCHIVE),'filesHashed':len(files),
                      'reportedCostUsd':sum(r['cost'] for r in state['records'])},indent=2))


if __name__=='__main__':main()
