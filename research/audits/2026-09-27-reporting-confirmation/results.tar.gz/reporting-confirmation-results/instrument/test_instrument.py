import importlib.util
import argparse
import contextlib
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import tarfile
import unittest


SPEC = importlib.util.find_spec('instrument')
if SPEC:
    import instrument as m


class InstrumentTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(SPEC, 'The replayable instrument has not been implemented')

    def test_counterbalance_and_prompt_intervention(self):
        orders = [m.arm_order(i) for i in range(3)]
        self.assertEqual(orders, [
            ['none', 'old-explicit', 'new-explicit'], ['old-explicit', 'new-explicit', 'none'],
            ['new-explicit', 'none', 'old-explicit'],
        ])
        task = '# A contract\nPreserve these bytes.\n'
        self.assertEqual(m.prompt_for(task, 'old-explicit'), m.prompt_for(task, 'new-explicit'))
        self.assertIn(task, m.prompt_for(task, 'none'))
        self.assertEqual(m.prompt_for(task, 'new-explicit'),
                         'Before implementing, load augustus-train and apply its relevant guidance.\n\n'
                         + m.prompt_for(task, 'none'))

    def test_budget_boundaries_and_unknown_cost_fail_closed(self):
        self.assertTrue(m.can_launch([{'status': 'done', 'cost': 9.99}]))
        self.assertFalse(m.can_launch([{'status': 'done', 'cost': 10.0}]))
        self.assertFalse(m.can_launch([{'status': 'running', 'cost': None}]))
        self.assertFalse(m.can_launch([{'status': 'done', 'cost': None}]))
        self.assertTrue(m.can_launch([{'status': 'done', 'cost': 0.1}] * 17))
        self.assertFalse(m.can_launch([{'status': 'done', 'cost': 0.1}] * 18))
        self.assertFalse(m.can_launch([{'status': 'done', 'cost': float('nan')}]))
        self.assertFalse(m.can_launch([{'status': 'failed', 'cost': 0.0}]))
        self.assertTrue(m.can_launch([{'status': 'budget_exhausted', 'cost': 0.1}]))

    def test_guard_paths_skills_and_shell_rewrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            fixture, plugin = root / 'fixture', root / '.agents'
            fixture.mkdir(); plugin.mkdir()
            (fixture / 'TASK.md').write_text('contract')
            (fixture / 'probe.py').write_text('print(1)')
            (fixture / 'escape').symlink_to(root)
            spec = m.guard_spec(fixture, plugin, root)
            allow = lambda tool, values: m.guard_decision(spec, tool, values)['permissionDecision']
            self.assertEqual(allow('Write', {'file_path': str(fixture/'solution.py')}), 'allow')
            for path in [root/'outside.py', fixture/'TASK.md', fixture/'input.json', fixture/'README.md', fixture/'escape'/'outside.py', fixture/'.claude/settings.json', plugin/'SKILL.md']:
                self.assertEqual(allow('Write', {'file_path': str(path)}), 'deny', str(path))
            self.assertEqual(allow('Read', {'file_path': str(plugin/'SKILL.md')}), 'allow')
            self.assertEqual(allow('Glob', {'pattern': '../../*'}), 'deny')
            self.assertEqual(allow('Skill', {'skill': '.agents:augustus-train'}), 'allow')
            self.assertEqual(allow('Skill', {'skill': 'debug'}), 'deny')
            self.assertEqual(allow('Task', {}), 'deny')
            self.assertEqual(allow('Bash', {'command': 'curl https://example.com'}), 'deny')
            self.assertEqual(allow('Bash', {'command': 'python3 -c "print(1)"'}), 'deny')
            decision = m.guard_decision(spec, 'Bash', {'command': 'python3 probe.py "x; touch /tmp/escape"'})
            self.assertEqual(decision['permissionDecision'], 'allow')
            self.assertIn('python-sandbox', decision['updatedInput']['command'])
            no_plugin = m.guard_spec(fixture, None, root)
            self.assertEqual(m.guard_decision(no_plugin, 'Skill', {'skill': 'augustus-train'})['permissionDecision'], 'deny')

    def test_prepare_data_hashes_repeats_and_frozen_release(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            archive = root/'tasks.tar.gz'
            with tarfile.open(archive, 'w:gz') as out:
                for name, content in {
                    'public/README.md': b'Callable and CLI contract',
                    'public/task_1/PROMPT.md': b'First task',
                    'public/task_1/input.json': b'[{"x":7}]\n',
                    'public/task_2/PROMPT.md': b'Independent second task',
                    'public/task_2/input.json': b'[{"y":9}]\n',
                }.items():
                    member = tarfile.TarInfo(name); member.size = len(content)
                    out.addfile(member, io.BytesIO(content))
            args = argparse.Namespace(tasks=str(archive), tasks_sha256=m.sha(archive),
                old=str(m.HERE.parent/'old/.agents'), new=str(m.HERE.parent/'new/.agents'), state=str(root/'state'))
            with contextlib.redirect_stdout(io.StringIO()): m.prepare(args)
            state = json.loads((root/'state/state.json').read_text())
            self.assertEqual(state['priorCampaignReportedCostUsd'], 6.3239766)
            self.assertEqual(state['records'], [])
            runs = m.schedule(state, 'confirmation')
            self.assertEqual(len({r['id'] for r in runs}), 18)
            self.assertEqual([r['arm'] for r in runs[:6]], ['none','old-explicit','new-explicit','old-explicit','new-explicit','none'])
            self.assertEqual([r['task'] for r in runs[:6]], ['task_1']*3+['task_2']*3)
            for task in ['task_1', 'task_2']:
                groups = [[r['arm'] for r in runs if r['task']==task and r['repeat']==repeat] for repeat in [1,2,3]]
                for position in range(3):
                    self.assertEqual({group[position] for group in groups}, {'none','old-explicit','new-explicit'})
            m.verify_state(state)
            (root/'state/tasks/task_1/input.json').write_text('[]')
            with self.assertRaisesRegex(ValueError, 'input'): m.verify_state(state)
            args.state = str(root/'bad-hash'); args.tasks_sha256 = '0'*64
            with self.assertRaisesRegex(ValueError, 'fingerprint'): m.prepare(args)

    def test_real_python_sandbox_denies_network_and_external_effects(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            fixture = root/'fixture'; fixture.mkdir()
            (fixture/'TASK.md').write_text('immutable')
            (fixture/'input.json').write_text('[7]')
            sentinel = root/'secret.txt'; sentinel.write_text('NOT_VISIBLE')
            with socket.socket() as listener:
                listener.bind(('127.0.0.1', 0)); listener.listen()
                port = listener.getsockname()[1]
                (fixture/'probe.py').write_text(
                    'import json,os,socket,pathlib\n'
                    'results={}\n'
                    'def check(name,action):\n'
                    ' try: action(); results[name]="ALLOWED"\n'
                    ' except (OSError,PermissionError): results[name]="DENIED"\n'
                    f'check("read",lambda:pathlib.Path({str(sentinel)!r}).read_text())\n'
                    f'check("write",lambda:pathlib.Path({str(root/"outside")!r}).write_text("bad"))\n'
                    'check("contract",lambda:pathlib.Path("TASK.md").write_text("bad"))\n'
                    'check("input_write",lambda:pathlib.Path("input.json").write_text("bad"))\n'
                    'check("input_unlink",lambda:pathlib.Path("input.json").unlink())\n'
                    'check("input_rename",lambda:pathlib.Path("input.json").rename("moved"))\n'
                    'check("input_create",lambda:pathlib.Path("README.md").write_text("bad"))\n'
                    'results["input_read"]=json.loads(pathlib.Path("input.json").read_text())\n'
                    f'check("network",lambda:socket.create_connection(("127.0.0.1",{port}),timeout=1))\n'
                    'results["credential"]=os.environ.get("ANTHROPIC_AUTH_TOKEN")\n'
                    'pathlib.Path("output.json").write_text(json.dumps(results))\n'
                    'print(json.dumps(results))\n'
                )
                spec = m.guard_spec(fixture, None, root)
                (root/'guard.json').write_text(json.dumps(spec))
                result = subprocess.run([sys.executable, str(Path(m.__file__).resolve()),
                                         'python-sandbox', '--spec', str(root/'guard.json'),
                                         'probe.py'], text=True, capture_output=True,
                                        env={**os.environ, 'ANTHROPIC_AUTH_TOKEN':'must-not-inherit'})
            self.assertEqual(result.returncode, 0, result.stderr)
            observed = json.loads((fixture/'output.json').read_text())
            self.assertEqual(observed, dict(read='DENIED',write='DENIED',contract='DENIED',network='DENIED',credential=None,
                input_write='DENIED',input_unlink='DENIED',input_rename='DENIED',input_create='DENIED',input_read=[7]))
            self.assertFalse((root/'outside').exists())
            self.assertEqual((fixture/'TASK.md').read_text(), 'immutable')


if __name__ == '__main__':
    unittest.main()
