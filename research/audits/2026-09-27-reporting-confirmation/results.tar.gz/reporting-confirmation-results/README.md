# Frozen reporting-repair confirmation

This separate campaign implements reporting-confirmation-contract.md, SHA-256
`619c9e6172db659c8fb5e090456e17eec8f0350625bc874f9e61d34f72fd2c46`.
It changes no skills, task bytes, grader, acceptance policy, release or prior
campaign. The protected packet is now consumed evaluation evidence.

Frozen sources:

- Old: `e34a3bf7fd2d17a787a3483d60c935d887b3d05a`.
- New: `686e5f613da0516643677af01e5b83131788d28d`.
- Public archive: `365a86e44abc921231a82eb0f321724cb6e40e4863ac739709190e9df033b0b9`.
- Private archive: `aeea3fcf1cfca89340b7d395d22c191d3e1d5b205fa1c068b2fc480bcb0c171a`.

Archives were hash-verified before extraction. Skill trees were exported directly
from the exact Git revisions without changing the concurrent checkout. Their
sorted compact file-hash-map fingerprints are pinned in instrument.py and state.

## Execution

Three conditions: none, old-explicit, new-explicit. Task order is task_1 then
task_2. Repetition orders for task_1 are none/old/new, old/new/none, new/none/old;
task_2 rotates one position later. No automatic-discovery comparison is made.
Both explicit arms have the same exact prefix:

`Before implementing, load augustus-train and apply its relevant guidance.`

Each effective prompt contains the untouched task prompt, the untouched public
README contract, and common execution-environment instructions. Only the prefix
differs between none and explicit; old/new prompts are otherwise byte-identical.
Each fixture has TASK.md (the original PROMPT.md bytes), README.md and input.json,
all protected against agent mutation. Other fixture paths remain writable.

Pinned Claude Code 2.1.282, exact `claude-opus-5-5`, medium effort, 20 CLI turns,
180-second wall timeout, concurrency one, maximum 18 attempts, $10 new reported
cost with possible in-flight overshoot. Prior campaigns' $6.3239766 is recorded
separately and not charged against this new cap. Missing cost or unresolved
infrastructure/protocol failures stop launches. A known-cost max-turns exhaustion
is retained as a failed-budget attempt, never retried; it is not silently treated
as infrastructure failure. No extra variants or model substitutions exist.

The same existing VibeProxy isolation implementation is reused: temporary local
backend, existing server-side Claude credential snapshot, retries/fallback off,
normal configuration untouched. No credential is passed into Python tools or
exported. Requested identity and observed response/model-usage names are distinct
from independent upstream attestation, which this proxy cannot provide.

## Isolation

Separate HOME/config/temp, restricted CLI, empty MCP inventory, no normal memory
or settings discovery. Only Read/Glob/Grep/Write/Edit/Bash/Skill are exposed.
File hooks restrict access to the individual fixture and its chosen read-only
skill snapshot. Both Augustus skills may load in explicit arms; neither may load
in baseline. Built-in CLI descriptions are constant across arms but their loading
is denied. No nested agents or network tools.

Bash accepts only generated `python3 relative_script.py [arguments...]`. The
trusted wrapper runs Python stdlib-only under macOS Seatbelt: no network, outside
file writes, private packet access or inherited credentials. Scripts have 60s
CPU/wall bounds. Six offline tests passed, including actual CLI skill loads and
an attempted Python read of the real private grader path, which was denied.
`instrument/offline-validation.txt` and labelled mock traces retain evidence.

Private grading is not invoked until all inference attempts have finished or a
frozen stop condition has halted the campaign. Public/private packet files are
never modified; any grading scratch space is separate. Raw CLI `num_turns` also
counts emitted tool-result user events, so the export retains that field and
separate distinct assistant-message counts rather than silently relabelling it.

## Replay interface

Executed from the instrument directory on this Mac (do not rerun inference):

```sh
python3 -m unittest -v test_instrument test_cli
python3 instrument.py prepare \
  --tasks ../../confirmation-public-tasks.tar \
  --tasks-sha256 365a86e44abc921231a82eb0f321724cb6e40e4863ac739709190e9df033b0b9 \
  --old ../old/.agents --new ../new/.agents --state ../state
python3 instrument.py run --state ../state --variant confirmation --authorize-inference
```

The state is a permanent attempt/spend ledger. Do not prepare a new state to
reset its limits. Research delivery retains source hashes, raw traces, all
generated artifacts, nonsecret actual config and deterministic grading outputs.
Runtime homes, authentication material and private proxy logs are excluded.
Parent owns independent replay and integration; no commit, push or release here.
