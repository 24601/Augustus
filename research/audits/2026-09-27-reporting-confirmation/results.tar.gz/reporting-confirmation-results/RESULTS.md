# Confirmation result: no demonstrated benefit on these tasks

The frozen same-budget comparison completed all 18 attempts. The private grader
was first used after inference ended. Both known-good references passed in the
same offline sandbox, then every submission passed all frozen acceptance checks.
Grader files, task inputs, skills and generated solutions were not changed.

| Condition | Task 1 accepted | Task 2 accepted | Trainer loads | Reported cost | Mean agent wall seconds |
| --- | ---: | ---: | ---: | ---: | ---: |
| No Augustus | 3/3 | 3/3 | 0/6 | $0.7354604 | 33.39 |
| Old explicit | 3/3 | 3/3 | 6/6 | $0.9137690 | 40.21 |
| New explicit | 3/3 | 3/3 | 6/6 | $0.9147302 | 41.19 |

**New reported inference cost: $2.5639596 / $10.** No unknown costs, retries,
extra variants, timeouts, tool denials, protocol failures or model substitutions
were observed in the 18 attempts. Previous campaigns' $6.3239766 remains separate
and unchanged; the arithmetic combined total is $8.8879362. No further inference
is authorized by the unused allowance.

## Frozen primary decision

For task 1, each submission passed 1484 checks over 717 generated input cases.
For task 2, each passed 229 checks over 192 input cases. These are diagnostic
components of each task, **not independent samples**. The experimental replication
count is three per task/condition; the two task families are reported separately.

The contract required at least two additional passes out of six, no task with
fewer passes, and no safety regression. New minus none is **0 additional passes**;
new minus old is **0 additional passes**. Both comparisons fail the improvement
threshold. No safety regression was detected by the frozen checks, but acceptance
is saturated. **Ties mean no demonstrated benefit**, not evidence of superiority
or a proof that the patch can never help.

## Mechanism and scope

Both explicit conditions successfully loaded their exact trainer body. Neither
loaded the separate Augustus body, although both skills were available. Baseline
had neither. Actual request/response/model-usage names were `claude-opus-5-5`;
effort remained medium. These proxy names are not independent model attestation.

Old/new effective prompts were byte-identical per task/repetition. Relative to
none, the only prompt intervention was the frozen explicit prefix. Every command
used `--max-turns 20`, with 4–5 distinct assistant message IDs observed and 6–9 raw
result `num_turns` counts. The latter counts emitted user/tool-result events and
is not interchangeable with model turns. All runtimes were below 180 seconds.

No tool event read or directly invoked `policy_receipt.py`. The tasks concern
minimax-regret artifact execution and complete identified distribution serving,
not population-denominator reporting or shift-direction diagnostics. Loading the
guidance is demonstrated; exercising the new helper mechanism is not. The tasks'
limited elicitation and saturated acceptance constrain conclusions about the
targeted repair. This comparison does not test automatic discovery.

## Replay and evidence

- `state/runs/<id>/artifacts/solution.py`: exact frozen submissions, with all
  generated check scripts/JSON retained alongside public input copies.
- Adjacent trace.jsonl, stderr.log, guard events, execution.json, settings.json
  and sandbox.sb: raw execution evidence and actual nonsecret configuration.
- `observations.json`: requested/observed models, exact loads, costs, wall time,
  turn counters, file hashes, inventories and prompt/input verification.
- `grading/summary.json`: all per-attempt results and known-good reference results.
- `grading/runs/<id>/`: raw grader stdout/stderr, command/env, sandbox and receipt.
- `packet/`: byte-identical frozen public and now-consumed private evaluation
  material. Original archives are included for independent hash verification.
- `grade_runs.py`: deterministic offline replay wrapper; choose a new output
  directory to preserve original grading (`--output grading-replay`). Requires
  macOS Seatbelt. No CLI/model inference occurs in this command.

For independent grading on another platform, use its offline disposable sandbox,
copy one frozen solution to `<candidate-root>/<task>/solution.py`, and run:

```sh
python3 -B packet/private/grade.py <candidate-root> --task task_1
# Or --task task_2; enforce the documented 60-second outer timeout.
```

The grader includes fixed seeds and independent oracles. The export does not
include credentials, runtime homes or private proxy logs/configuration. Raw
selected traces and nonsecret absolute paths remain unchanged. Source and
acceptance are frozen; no tuning, commit, push or release occurred. Published
0.8.1 remains unchanged; parent owns independent replay and research integration.
