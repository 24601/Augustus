import json,pathlib,socket,os
results={}
def test(name,fn):
 try: fn(); results[name]="ALLOWED"
 except OSError: results[name]="DENIED"
test("read",lambda:pathlib.Path('/Users/basitmustafa/Developer/Augustus/.amp/in/artifacts/confirmation/instrument/selftest/mock-old-explicit-9tcbqb7v/forbidden.txt').read_text())
test("private_grader",lambda:pathlib.Path('/Users/basitmustafa/Developer/Augustus/.amp/in/artifacts/confirmation/packet/private/grade.py').read_text())
test("write",lambda:pathlib.Path('/Users/basitmustafa/Developer/Augustus/.amp/in/artifacts/confirmation/instrument/selftest/mock-old-explicit-9tcbqb7v/escaped.txt').write_text("bad"))
test("input_write",lambda:pathlib.Path("input.json").write_text("bad"))
results["input_read"]=json.loads(pathlib.Path("input.json").read_text())
test("network",lambda:socket.create_connection(("127.0.0.1",8317),timeout=1))
results["credential"]=os.environ.get("ANTHROPIC_AUTH_TOKEN")
pathlib.Path("checks.json").write_text(json.dumps(results))
print(json.dumps(results))
