import copy
import json
import subprocess
import sys

from solution import compile_policy, decide, solve


def cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    assert p.stdout.endswith("\n") and p.stdout.count("\n") == 1
    return json.loads(p.stdout)


with open("input.json") as f:
    req = json.load(f)
orig = copy.deepcopy(req)
art = cli(req)
assert art == {"schema": 1, "policy_id": "field-v2",
               "scenarios": ["heat", "rain", "wind"],
               "modes": [{"name": "canvas", "losses": [3, 2, 9]},
                         {"name": "hybrid", "losses": [4, 4, 4]},
                         {"name": "steel", "losses": [8, 5, 1]}]}, art

# No mutation, no aliasing.
a2 = solve(req)
assert req == orig and a2 == art
a2["modes"][0]["losses"][0] = 99
assert req == orig
assert a2["modes"][0]["losses"] is not req["spec"]["modes"][0]["losses"]

# Decisions via fresh-process CLI using reloaded artifact (hand-computed).
def d(allowed, lim):
    return cli({"op": "decide", "artifact": art, "allowed": allowed, "max_regret": lim})

assert d(["steel", "canvas", "hybrid"], 3) == {"status": "act", "mode": "hybrid", "worst_regret": 3}
assert d(["steel", "canvas", "hybrid"], 2) == {"status": "defer", "reason": "regret_limit"}
assert d(["canvas", "steel"], 5) == {"status": "act", "mode": "steel", "worst_regret": 5}
assert d(["canvas"], 0) == {"status": "act", "mode": "canvas", "worst_regret": 0}
assert d([], 10) == {"status": "defer", "reason": "no_mode"}
assert d(["canvas", "ghost"], 10) == {"status": "defer", "reason": "unknown_mode"}

# Tie-breaks: equal worst regret -> lower max loss -> name.
spec = {"policy_id": "t", "scenarios": ["b", "a"],
        "modes": [{"name": "z", "losses": [0, 2]}, {"name": "y", "losses": [2, 0]},
                  {"name": "x", "losses": [1, 3]}]}
t = compile_policy(spec)
assert t["scenarios"] == ["a", "b"] and t["modes"][0] == {"name": "x", "losses": [3, 1]}
# y:[0,2] z:[2,0] best [0,0] both regret 2, max loss 2 -> name y
assert decide(t, ["z", "y"], 2) == {"status": "act", "mode": "y", "worst_regret": 2}
# x:[3,1], z:[2,0]: best [2,0], x regret 1, z 0 -> z
assert decide(t, ["x", "z"], 0) == {"status": "act", "mode": "z", "worst_regret": 0}
spec2 = {"policy_id": "t", "scenarios": ["s"],
         "modes": [{"name": "a", "losses": [5]}, {"name": "b", "losses": [5]}]}
assert decide(compile_policy(spec2), ["b", "a"], 0)["mode"] == "a"
print("all checks passed")
