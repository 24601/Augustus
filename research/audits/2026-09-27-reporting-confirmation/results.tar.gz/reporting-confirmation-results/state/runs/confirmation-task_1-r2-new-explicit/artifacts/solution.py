"""Minimax-regret policy artifact: compile once, decide over permitted subsets."""
import json
import sys


def compile_policy(spec: dict) -> dict:
    scenarios = list(spec["scenarios"])
    order = sorted(range(len(scenarios)), key=lambda i: scenarios[i])
    modes = []
    for mode in sorted(spec["modes"], key=lambda m: m["name"]):
        losses = mode["losses"]
        modes.append({"name": str(mode["name"]),
                      "losses": [int(losses[i]) for i in order]})
    return {"schema": 1, "policy_id": str(spec["policy_id"]),
            "scenarios": [scenarios[i] for i in order], "modes": modes}


def decide(artifact: dict, allowed: list, max_regret: int) -> dict:
    table = {m["name"]: [int(x) for x in m["losses"]] for m in artifact["modes"]}
    if any(name not in table for name in allowed):
        return {"status": "defer", "reason": "unknown_mode"}
    if not allowed:
        return {"status": "defer", "reason": "no_mode"}
    n = len(artifact["scenarios"])
    best = [min(table[b][s] for b in allowed) for s in range(n)]
    ranked = []
    for name in allowed:
        losses = table[name]
        worst = max(losses[s] - best[s] for s in range(n))
        ranked.append((worst, max(losses), name))
    worst, _, name = min(ranked)
    if worst > max_regret:
        return {"status": "defer", "reason": "regret_limit"}
    return {"status": "act", "mode": name, "worst_regret": worst}


def solve(request: dict) -> dict:
    if request["op"] == "compile":
        return compile_policy(request["spec"])
    return decide(request["artifact"], request["allowed"], request["max_regret"])


def main() -> None:
    request = json.loads(sys.stdin.read())
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
