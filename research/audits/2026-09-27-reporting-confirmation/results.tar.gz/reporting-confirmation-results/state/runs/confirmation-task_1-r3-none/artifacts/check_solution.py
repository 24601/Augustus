import copy
import json
import subprocess
import sys

import solution


def cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    assert p.stdout.endswith("\n") and p.stdout.count("\n") == 1
    return json.loads(p.stdout)


with open("input.json") as f:
    req = json.load(f)
orig = copy.deepcopy(req)
art = cli(req)
assert art == {"schema": 1, "policy_id": "field-v2", "scenarios": ["heat", "rain", "wind"],
               "modes": [{"name": "canvas", "losses": [3, 2, 9]},
                         {"name": "hybrid", "losses": [4, 4, 4]},
                         {"name": "steel", "losses": [8, 5, 1]}]}, art
a2 = solution.compile_policy(req["spec"])
assert a2 == art and req == orig
a2["modes"][0]["losses"][0] = 99
a2["scenarios"].append("x")
assert req == orig

d = lambda allowed, mr: cli({"op": "decide", "artifact": art, "allowed": allowed, "max_regret": mr})
assert d(["steel", "canvas", "hybrid"], 3) == {"status": "act", "mode": "hybrid", "worst_regret": 3}
assert d(["steel", "canvas", "hybrid"], 2) == {"status": "defer", "reason": "regret_limit"}
assert d([], 0) == {"status": "defer", "reason": "no_mode"}
assert d(["nope"], 100) == {"status": "defer", "reason": "unknown_mode"}
assert d(["hybrid", "nope"], 100) == {"status": "defer", "reason": "unknown_mode"}
assert d(["steel"], 0) == {"status": "act", "mode": "steel", "worst_regret": 0}
# canvas vs steel: best (3,2,1); canvas 8, steel 5
assert d(["canvas", "steel"], 5) == {"status": "act", "mode": "steel", "worst_regret": 5}

# tie-breaks: equal regret -> lower max loss, then name
t = solution.compile_policy({"policy_id": "t", "scenarios": ["b", "a"],
                             "modes": [{"name": "z", "losses": [0, 2]},
                                       {"name": "y", "losses": [2, 0]},
                                       {"name": "x", "losses": [2, 0]}]})
assert solution.decide(t, ["z", "y", "x"], 2) == {"status": "act", "mode": "x", "worst_regret": 2}
t2 = solution.compile_policy({"policy_id": "t", "scenarios": ["a", "b"],
                              "modes": [{"name": "a", "losses": [5, 6]},
                                        {"name": "b", "losses": [1, 7]},
                                        {"name": "c", "losses": [6, 2]}]})
# best (1,2): a=4, b=5, c=5 -> a
assert solution.decide(t2, ["a", "b", "c"], 9)["mode"] == "a"
# regret equal ties with differing max loss
t3 = solution.compile_policy({"policy_id": "t", "scenarios": ["s", "t"],
                              "modes": [{"name": "a", "losses": [3, 9]},
                                        {"name": "b", "losses": [1, 10]},
                                        {"name": "c", "losses": [3, 8]}]})
# best (1,8): a max(2,1)=2, b max(0,2)=2, c max(2,0)=2 -> max loss a9 b10 c8 -> c
assert solution.decide(t3, ["b", "a", "c"], 2)["mode"] == "c"
print("ok")
