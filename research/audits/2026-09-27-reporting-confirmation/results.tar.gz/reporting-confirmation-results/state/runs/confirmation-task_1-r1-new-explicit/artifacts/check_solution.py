"""Hand-calculated checks, including CLI and fresh-process JSON reload."""
import copy
import json
import subprocess
import sys

import solution


def cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    assert p.stdout.endswith("\n") and p.stdout.count("\n") == 1, p.stdout
    return json.loads(p.stdout)


with open("input.json") as f:
    req = json.load(f)
orig = copy.deepcopy(req)
art = cli(req)
assert req == orig
expected = {"schema": 1, "policy_id": "field-v2", "scenarios": ["heat", "rain", "wind"],
            "modes": [{"name": "canvas", "losses": [3, 2, 9]},
                      {"name": "hybrid", "losses": [4, 4, 4]},
                      {"name": "steel", "losses": [8, 5, 1]}]}
assert art == expected, art
with open("compiled_artifact.json", "w") as f:
    json.dump(art, f)

# No aliasing: mutating the artifact must not affect the spec.
a2 = solution.compile_policy(req["spec"])
a2["modes"][0]["losses"][0] = 99
a2["scenarios"].append("x")
assert req == orig

def d(allowed, mr, a=art):
    return cli({"op": "decide", "artifact": a, "allowed": allowed, "max_regret": mr})

# Full set: regrets canvas 8, steel 5, hybrid 3.
assert d(["steel", "canvas", "hybrid"], 3) == {"status": "act", "mode": "hybrid", "worst_regret": 3}
assert d(["steel", "canvas", "hybrid"], 2) == {"status": "defer", "reason": "regret_limit"}
# Subset changes the baseline: canvas vs steel -> steel 5.
assert d(["canvas", "steel"], 5) == {"status": "act", "mode": "steel", "worst_regret": 5}
assert d(["canvas"], 0) == {"status": "act", "mode": "canvas", "worst_regret": 0}
assert d([], 10) == {"status": "defer", "reason": "no_mode"}
assert d(["canvas", "ghost"], 10) == {"status": "defer", "reason": "unknown_mode"}
assert d(["ghost"], 0) == {"status": "defer", "reason": "unknown_mode"}

# Ties: equal regret -> lower max loss, then name.
t = solution.compile_policy({"policy_id": "t", "scenarios": ["y", "x"], "modes": [
    {"name": "b", "losses": [0, 2]}, {"name": "a", "losses": [2, 0]},
    {"name": "c", "losses": [1, 1]}, {"name": "d", "losses": [3, 3]}]})
# a,b regret 2 (max loss 2); c regret 1 -> c.
assert d(["a", "b", "c"], 1, t) == {"status": "act", "mode": "c", "worst_regret": 1}
assert d(["b", "a"], 2, t) == {"status": "act", "mode": "a", "worst_regret": 2}
t2 = solution.compile_policy({"policy_id": "t", "scenarios": ["x", "y"], "modes": [
    {"name": "a", "losses": [5, 5]}, {"name": "z", "losses": [3, 5]},
    {"name": "m", "losses": [2, 7]}]})
# mins [2,5]; a:3, z:1, m:2 -> z
assert d(["a", "z", "m"], 1, t2)["mode"] == "z"
# tie regret, lower max loss wins over name: p [0,4] q [4,0] r... use p=[1,3], q=[3,1]? equal.
t3 = solution.compile_policy({"policy_id": "t", "scenarios": ["x", "y"], "modes": [
    {"name": "a", "losses": [10, 12]}, {"name": "b", "losses": [12, 10]},
    {"name": "c", "losses": [2, 0]}, {"name": "d", "losses": [0, 2]}]})
# allowed a,b: mins [10,10], both regret 2, max 12 -> a
assert d(["b", "a"], 2, t3)["mode"] == "a"
# Equal regret 4; q has lower max loss (6 vs 9), so it beats earlier-named p.
t4 = solution.compile_policy({"policy_id": "t", "scenarios": ["s1", "s2", "s3"], "modes": [
    {"name": "p", "losses": [0, 4, 9]}, {"name": "q", "losses": [4, 0, 6]}]})
assert d(["p", "q"], 4, t4) == {"status": "act", "mode": "q", "worst_regret": 4}
print("ok")
