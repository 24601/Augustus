"""Minimax-regret policy: compile a reusable artifact, then decide over allowed modes."""
import json
import sys


def compile_policy(spec):
    scenarios = list(spec["scenarios"])
    order = sorted(range(len(scenarios)), key=lambda i: scenarios[i])
    modes = sorted(
        (
            {"name": str(m["name"]), "losses": [int(m["losses"][i]) for i in order]}
            for m in spec["modes"]
        ),
        key=lambda m: m["name"],
    )
    return {
        "schema": 1,
        "policy_id": spec["policy_id"],
        "scenarios": [scenarios[i] for i in order],
        "modes": modes,
    }


def decide(artifact, allowed, max_regret):
    table = {m["name"]: list(m["losses"]) for m in artifact["modes"]}
    allowed = list(allowed)
    if any(name not in table for name in allowed):
        return {"status": "defer", "reason": "unknown_mode"}
    if not allowed:
        return {"status": "defer", "reason": "no_mode"}
    n = len(artifact["scenarios"])
    best = [min(table[b][s] for b in allowed) for s in range(n)]
    ranked = []
    for name in allowed:
        losses = table[name]
        worst = max((losses[s] - best[s] for s in range(n)), default=0)
        ranked.append((worst, max(losses, default=0), name))
    worst, _, name = min(ranked)
    if worst > max_regret:
        return {"status": "defer", "reason": "regret_limit"}
    return {"status": "act", "mode": name, "worst_regret": worst}


def solve(request):
    if request["op"] == "compile":
        return compile_policy(request["spec"])
    return decide(request["artifact"], request["allowed"], request["max_regret"])


def main():
    request = json.loads(sys.stdin.read())
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
