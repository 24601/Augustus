"""Hand-calculated checks for solution.py (run: python3 check_solution.py)."""
import copy
import json
import subprocess
import sys

from solution import solve

with open("input.json") as f:
    BASE = json.load(f)


def req(**kw):
    r = copy.deepcopy(BASE)
    r.update(kw)
    return r


def reply(id="a", v="ordinal-v4", t=73, levels=("high", "low", "medium"), w=(1, 6, 3)):
    return {"id": id, "model_version": v, "observed_at": t,
            "levels": list(levels), "weights": list(w)}


def one(r, cid="a"):
    return next(d for d in solve(r)["decisions"] if d["id"] == cid)


def reason(r, cid="a"):
    d = one(r, cid)
    assert d["status"] == "defer", d
    return d["reason"]


# Example: low .6, med .3, high .1 -> leave = 0.9 + 1.2 = 2.1 > inspect 2.
# Mean severity index 0.5 would suggest "leave"; full distribution says inspect.
out = solve(BASE)
assert out == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"}]}, out

# Non-normalized weights give the same answer.
assert one(req(replies=[reply(w=(0.125, 0.75, 0.375))]))["expected_loss"] == 2.0

# Mass concentrated low -> leave, with exact expected loss.
d = one(req(replies=[reply(w=(0, 9, 1))]))
assert d["action"] == "leave" and abs(d["expected_loss"] - 0.3) < 1e-9, d

# Precedence and deferral reasons.
assert reason(req(replies=[reply(), reply(v="old")])) == "duplicate"
assert reason(req(replies=[reply(v="old"), reply(t=999)])) == "duplicate"
assert reason(req(replies=[reply(v="old", t=999)])) == "version"
assert reason(req(replies=[reply(t=81)])) == "freshness"
assert reason(req(replies=[reply(t=69)])) == "freshness"
assert one(req(replies=[reply(t=70)]))["status"] == "act"  # TTL boundary valid
assert one(req(replies=[reply(t=80)]))["status"] == "act"
assert reason(req(replies=[reply(t=999, w=(None, 1, 1))])) == "freshness"
# Unknown IDs ignored.
assert solve(req(replies=[reply(id="zzz")]))["decisions"][0]["reason"] == "missing"

bad = [
    dict(levels=("low", "medium"), w=(1, 1)),              # missing level
    dict(levels=("low", "medium", "high", "x"), w=(1, 1, 1, 1)),
    dict(levels=("low", "low", "high"), w=(1, 1, 1)),      # repeated level
    dict(w=(1, 1)),                                         # length mismatch
    dict(w=(1, True, 1)),
    dict(w=(1, None, 1)),
    dict(w=(1, "2", 1)),
    dict(w=(1, -0.125, 1)),
    dict(w=(0, 0, 0)),
    dict(w=(0.0, 0.0, 0.0)),
]
for b in bad:
    assert reason(req(replies=[reply(**b)])) == "distribution", b
# Zero weight on an included level is fine.
assert one(req(replies=[reply(w=(0, 1, 0))]))["action"] == "leave"

# Tie -> lexicographically smaller name regardless of action order.
tie = req(actions=[{"name": "zeta", "losses": [1, 1, 1]},
                   {"name": "alpha", "losses": [1, 1, 1]}],
          replies=[reply()])
assert one(tie)["action"] == "alpha"
# Exact tie that float summation might break: 0.1+0.2 vs 0.3 style.
tie2 = req(levels=["l", "m", "h"],
           actions=[{"name": "b", "losses": [3, 3, 3]},
                    {"name": "a", "losses": [0, 0, 30]}],
           replies=[reply(levels=("l", "m", "h"), w=(4, 5, 1))])
assert one(tie2)["action"] == "a", one(tie2)

# Loss policy change flips decision.
harsh = req(actions=[{"name": "inspect", "losses": [2, 2, 2]},
                     {"name": "leave", "losses": [0, 1, 5]}], replies=[reply()])
d = one(harsh)
assert d["action"] == "leave" and abs(d["expected_loss"] - 0.8) < 1e-9, d

# No mutation.
r = req(replies=[reply(w=(1, 6, 3))])
snap = copy.deepcopy(r)
solve(r)
assert r == snap

# Keys exact.
assert set(out) == {"decisions"}
assert set(out["decisions"][0]) == {"id", "status", "action", "expected_loss"}
assert set(out["decisions"][1]) == {"id", "status", "reason"}

# CLI.
p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(BASE),
                   capture_output=True, text=True)
assert p.returncode == 0 and p.stdout.endswith("\n") and p.stdout.count("\n") == 1
assert json.loads(p.stdout) == out
print("all checks passed")
