"""Offline adapter: ordinal distributions -> loss-minimizing action or deferral."""
import json
import sys
from fractions import Fraction


def _usable_distribution(reply, levels):
    """Return {level: Fraction probability} or None if evidence is unusable."""
    rlevels = reply.get("levels")
    weights = reply.get("weights")
    if not isinstance(rlevels, list) or not isinstance(weights, list):
        return None
    if not all(isinstance(x, str) for x in rlevels):
        return None
    if len(rlevels) != len(levels) or set(rlevels) != set(levels):
        return None
    if len(weights) != len(rlevels):
        return None
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            return None
        if w < 0:
            return None
    fw = [Fraction(w) for w in weights]
    total = sum(fw, Fraction(0))
    if total <= 0:
        return None
    return {lv: w / total for lv, w in zip(rlevels, fw)}


def _decide(case, replies, request):
    cid = case["id"]
    mine = [r for r in replies if isinstance(r, dict) and r.get("id") == cid]
    if not mine:
        return {"id": cid, "status": "defer", "reason": "missing"}
    if len(mine) > 1:
        return {"id": cid, "status": "defer", "reason": "duplicate"}
    reply = mine[0]
    if reply.get("model_version") != request["model_version"]:
        return {"id": cid, "status": "defer", "reason": "version"}
    obs = reply.get("observed_at")
    now = request["now"]
    if (isinstance(obs, bool) or not isinstance(obs, int)
            or obs > now or now - obs > case["ttl"]):
        return {"id": cid, "status": "defer", "reason": "freshness"}
    levels = request["levels"]
    dist = _usable_distribution(reply, levels)
    if dist is None:
        return {"id": cid, "status": "defer", "reason": "distribution"}
    best = None
    for action in request["actions"]:
        cost = sum((dist[lv] * loss for lv, loss in zip(levels, action["losses"])),
                   Fraction(0))
        key = (cost, action["name"])
        if best is None or key < best:
            best = key
    return {"id": cid, "status": "act", "action": best[1],
            "expected_loss": float(best[0])}


def solve(request: dict) -> dict:
    replies = request.get("replies", [])
    return {"decisions": [_decide(c, replies, request) for c in request["cases"]]}


def main():
    request = json.load(sys.stdin)
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
