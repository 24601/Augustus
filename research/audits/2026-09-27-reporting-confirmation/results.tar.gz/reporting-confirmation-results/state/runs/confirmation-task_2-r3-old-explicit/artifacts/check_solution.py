import copy
import json
import subprocess
import sys

from solution import solve

BASE = json.load(open("input.json"))


def req(replies, cases=None, actions=None, now=80):
    r = copy.deepcopy(BASE)
    r["replies"] = replies
    r["now"] = now
    if cases is not None:
        r["cases"] = cases
    if actions is not None:
        r["actions"] = actions
    return r


def rep(id="a", v="ordinal-v4", t=73, levels=("high", "low", "medium"), w=(1, 6, 3)):
    return {"id": id, "model_version": v, "observed_at": t, "levels": list(levels), "weights": list(w)}


def one(r):
    return solve(r)["decisions"][0]


# Example: low .6, medium .3, high .1 -> leave=2.1, inspect=2 -> inspect
out = solve(BASE)
assert out == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"}]}, out

# Request not mutated
r = copy.deepcopy(BASE); snap = copy.deepcopy(r); solve(r); assert r == snap

# Precedence and defer reasons
assert one(req([rep(), rep(v="old")]))["reason"] == "duplicate"
assert one(req([rep(v="old")]))["reason"] == "version"
assert one(req([rep(v="old", t=999)]))["reason"] == "version"
assert one(req([rep(t=81)]))["reason"] == "freshness"
assert one(req([rep(t=69)]))["reason"] == "freshness"
assert one(req([rep(t=70)]))["status"] == "act"  # exact TTL boundary
assert one(req([rep(t=69, w=(1, 1))]))["reason"] == "freshness"
assert one(req([rep(id="zzz")]))["reason"] == "missing"  # unknown ignored

# Distribution failures
bad = [
    dict(levels=("high", "low"), w=(1, 6)),              # missing level
    dict(levels=("high", "low", "low"), w=(1, 6, 3)),   # repeated
    dict(levels=("high", "low", "extreme"), w=(1, 6, 3)),
    dict(levels=("high", "low", "medium", "extreme"), w=(1, 6, 3, 0)),
    dict(w=(1, 6)),                                      # length mismatch
    dict(w=(1, 6, 3, 0)),
    dict(w=(True, 6, 3)),
    dict(w=(None, 6, 3)),
    dict(w=("1", 6, 3)),
    dict(w=(-0.125, 6, 3)),
    dict(w=(0, 0, 0)),
    dict(w=(0.0, 0, 0.0)),
]
for kw in bad:
    assert one(req([rep(**kw)]))["reason"] == "distribution", kw

# Zero weight for included level is fine; unnormalized floats; alignment by name
d = one(req([rep(w=(0, 0.375, 0.125))]))  # low .75, medium .25
assert d == {"id": "a", "status": "act", "action": "leave", "expected_loss": 0.75}, d

# Full distribution vs mean severity: mass split low/high has mean "medium"
# (leave=3 < inspect=4) but the distribution gives leave=6 > inspect=4.
acts = [{"name": "inspect", "losses": [4, 4, 4]}, {"name": "leave", "losses": [0, 3, 12]}]
d = one(req([rep(w=(1, 1, 0))], actions=acts))  # high .5, low .5 -> leave=6, inspect=4
assert d["action"] == "inspect" and d["expected_loss"] == 4.0, d

# Tie -> lexicographically smaller name regardless of order
acts = [{"name": "zeta", "losses": [1, 1, 1]}, {"name": "alpha", "losses": [1, 1, 1]}]
assert one(req([rep()], actions=acts))["action"] == "alpha"

# Different policy flips the action on the same distribution
acts = [{"name": "inspect", "losses": [5, 5, 5]}, {"name": "leave", "losses": [0, 3, 12]}]
assert one(req([rep()], actions=acts))["action"] == "leave"

# Precision
acts = [{"name": "x", "losses": [1, 2, 10000]}]
d = one(req([rep(w=(0.125, 9999.875, 0.125))], actions=acts))
exp = (0.125 * 10000 + 9999.875 * 1 + 0.125 * 2) / 10000.125
assert abs(d["expected_loss"] - exp) < 1e-9, d

# Case order preserved, empty cases
cases = [{"id": "b", "ttl": 5}, {"id": "a", "ttl": 10}]
assert [x["id"] for x in solve(req([rep()], cases=cases))["decisions"]] == ["b", "a"]
assert solve(req([], cases=[])) == {"decisions": []}

# CLI
p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(BASE),
                   capture_output=True, text=True)
assert p.returncode == 0 and p.stdout.endswith("\n") and json.loads(p.stdout) == out
print("all checks passed")
