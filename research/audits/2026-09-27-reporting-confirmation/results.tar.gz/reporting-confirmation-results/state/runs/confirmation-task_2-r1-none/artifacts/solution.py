"""Ordinal-distribution loss-policy adapter with explicit deferral reasons."""
import json
import sys
from fractions import Fraction


def _defer(case_id, reason):
    return {"id": case_id, "status": "defer", "reason": reason}


def _distribution(reply, policy_levels):
    """Return {level: Fraction probability} or None if unusable."""
    levels = reply.get("levels")
    weights = reply.get("weights")
    if not isinstance(levels, list) or not isinstance(weights, list):
        return None
    if len(levels) != len(policy_levels) or len(weights) != len(levels):
        return None
    if not all(isinstance(lv, str) for lv in levels):
        return None
    if sorted(levels) != sorted(policy_levels) or len(set(levels)) != len(levels):
        return None
    mass = {}
    for lv, w in zip(levels, weights):
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            return None
        if w != w or w in (float("inf"), float("-inf")) or w < 0:
            return None
        mass[lv] = Fraction(w)
    total = sum(mass.values())
    if total <= 0:
        return None
    return {lv: m / total for lv, m in mass.items()}


def solve(request: dict) -> dict:
    now = request["now"]
    version = request["model_version"]
    levels = list(request["levels"])
    actions = request["actions"]
    replies = request.get("replies") or []

    by_id = {}
    for reply in replies:
        if isinstance(reply, dict):
            by_id.setdefault(reply.get("id"), []).append(reply)

    decisions = []
    for case in request["cases"]:
        cid = case["id"]
        ttl = case["ttl"]
        found = by_id.get(cid, []) if isinstance(cid, str) else []
        if not found:
            decisions.append(_defer(cid, "missing"))
            continue
        if len(found) > 1:
            decisions.append(_defer(cid, "duplicate"))
            continue
        reply = found[0]
        rv = reply.get("model_version")
        if not isinstance(rv, str) or rv != version:
            decisions.append(_defer(cid, "version"))
            continue
        obs = reply.get("observed_at")
        if (isinstance(obs, bool) or not isinstance(obs, (int, float))
                or obs > now or now - obs > ttl):
            decisions.append(_defer(cid, "freshness"))
            continue
        probs = _distribution(reply, levels)
        if probs is None:
            decisions.append(_defer(cid, "distribution"))
            continue
        best = None
        for action in actions:
            cost = sum(probs[lv] * loss for lv, loss in zip(levels, action["losses"]))
            key = (cost, action["name"])
            if best is None or key < best:
                best = key
        decisions.append({"id": cid, "status": "act", "action": best[1],
                          "expected_loss": float(best[0])})
    return {"decisions": decisions}


def main():
    request = json.load(sys.stdin)
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
