import copy
import json
import subprocess
import sys

from solution import solve

with open("input.json") as f:
    base = json.load(f)

# Example: a -> probs low .6 med .3 high .1; inspect=2, leave=0.9+1.2=2.1
out = solve(copy.deepcopy(base))
assert out == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"}]}, out

# CLI
p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(base),
                   capture_output=True, text=True)
assert p.returncode == 0 and p.stdout.endswith("\n")
assert json.loads(p.stdout) == out


def rep(**kw):
    r = {"id": "a", "model_version": "ordinal-v4", "observed_at": 73,
         "levels": ["high", "low", "medium"], "weights": [1, 6, 3]}
    r.update(kw)
    return r


def run(replies, **over):
    req = copy.deepcopy(base)
    req["replies"] = replies
    req.update(over)
    snap = copy.deepcopy(req)
    res = solve(req)
    assert req == snap, "mutated"
    return res["decisions"][0]


def reason(replies, **over):
    return run(replies, **over).get("reason")


assert reason([rep(), rep(model_version="x")]) == "duplicate"
assert reason([rep(), rep()]) == "duplicate"
assert reason([rep(model_version="old")]) == "version"
assert reason([rep(model_version="old", observed_at=999)]) == "version"
assert reason([rep(observed_at=81)]) == "freshness"
assert reason([rep(observed_at=69)]) == "freshness"
assert run([rep(observed_at=70)])["status"] == "act"  # TTL boundary
assert run([rep(observed_at=80)])["status"] == "act"
assert reason([rep(observed_at=99, weights=[None, 1, 1])]) == "freshness"
bad = [
    dict(levels=["high", "low"], weights=[1, 6]),
    dict(levels=["high", "low", "low"], weights=[1, 6, 3]),
    dict(levels=["high", "low", "medium", "extra"], weights=[1, 6, 3, 0]),
    dict(levels=["high", "low", "med"], weights=[1, 6, 3]),
    dict(weights=[1, 6]),
    dict(weights=[1, 6, 3, 4]),
    dict(weights=[True, 6, 3]),
    dict(weights=[None, 6, 3]),
    dict(weights=["1", 6, 3]),
    dict(weights=[-0.125, 6, 3]),
    dict(weights=[0, 0, 0.0]),
]
for kw in bad:
    assert reason([rep(**kw)]) == "distribution", kw
# unknown ids ignored
assert run([rep(), rep(id="zzz"), rep(id="zzz")])["status"] == "act"

# Unnormalized & zero weights, alignment by name; mean-severity would differ.
# probs low .5 high .5 -> leave = 6, inspect = 2 -> inspect.
# mean severity = medium -> leave would give 3 (wrong answer if substituted).
d = run([rep(levels=["medium", "high", "low"], weights=[0, 2.5, 2.5])])
assert d == {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0}, d
# All low -> leave 0
d = run([rep(weights=[0, 0.125, 0])])
assert d["action"] == "leave" and d["expected_loss"] == 0, d

# Tie -> lexicographic name regardless of order
acts = [{"name": "zeta", "losses": [1, 1, 1]}, {"name": "alpha", "losses": [1, 1, 1]}]
assert run([rep()], actions=acts)["action"] == "alpha"
# Fractional accuracy: probs 1/3 each
acts = [{"name": "x", "losses": [0, 1, 1]}]
d = run([rep(weights=[1, 1, 1])], actions=acts)
assert abs(d["expected_loss"] - 2 / 3) < 1e-12, d
print("all checks passed")
