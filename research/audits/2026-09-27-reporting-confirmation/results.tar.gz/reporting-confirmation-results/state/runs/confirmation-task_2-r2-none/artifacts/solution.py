import json
import sys
from fractions import Fraction


def _distribution(reply, levels):
    """Return {level: Fraction probability} or None if unusable."""
    rlevels = reply.get("levels")
    weights = reply.get("weights")
    if not isinstance(rlevels, list) or not isinstance(weights, list):
        return None
    if not all(isinstance(x, str) for x in rlevels):
        return None
    if len(rlevels) != len(levels) or sorted(rlevels) != sorted(levels):
        return None
    if len(weights) != len(rlevels):
        return None
    masses = []
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            return None
        if w != w or w in (float("inf"), float("-inf")) or w < 0:
            return None
        masses.append(Fraction(w))
    total = sum(masses, Fraction(0))
    if total <= 0:
        return None
    return {lvl: m / total for lvl, m in zip(rlevels, masses)}


def solve(request: dict) -> dict:
    now = request["now"]
    version = request["model_version"]
    levels = list(request["levels"])
    actions = request["actions"]
    replies = request.get("replies") or []

    by_id = {}
    for r in replies:
        if isinstance(r, dict):
            by_id.setdefault(r.get("id"), []).append(r)

    decisions = []
    for case in request["cases"]:
        cid = case["id"]
        ttl = case["ttl"]
        matched = by_id.get(cid, []) if isinstance(cid, str) else []

        def defer(reason):
            decisions.append({"id": cid, "status": "defer", "reason": reason})

        if not matched:
            defer("missing")
            continue
        if len(matched) > 1:
            defer("duplicate")
            continue
        reply = matched[0]
        if reply.get("model_version") != version:
            defer("version")
            continue
        obs = reply.get("observed_at")
        if (
            isinstance(obs, bool)
            or not isinstance(obs, (int, float))
            or obs > now
            or now - obs > ttl
        ):
            defer("freshness")
            continue
        dist = _distribution(reply, levels)
        if dist is None:
            defer("distribution")
            continue

        best = None
        for action in actions:
            cost = sum(
                (dist[lvl] * Fraction(loss) for lvl, loss in zip(levels, action["losses"])),
                Fraction(0),
            )
            key = (cost, action["name"])
            if best is None or key < best:
                best = key
        decisions.append(
            {
                "id": cid,
                "status": "act",
                "action": best[1],
                "expected_loss": float(best[0]),
            }
        )
    return {"decisions": decisions}


def main():
    request = json.load(sys.stdin)
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
