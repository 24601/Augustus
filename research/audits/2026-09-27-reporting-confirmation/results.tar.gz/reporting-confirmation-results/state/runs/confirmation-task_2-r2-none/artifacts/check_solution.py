import copy
import json
import subprocess
import sys

from solution import solve

with open("input.json") as f:
    base = json.load(f)

# Example: a -> low .6, medium .3, high .1; inspect=2, leave=0.9+1.2=2.1 -> inspect
out = solve(copy.deepcopy(base))
assert out == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"},
]}, out

# CLI
p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(base),
                   capture_output=True, text=True)
assert p.returncode == 0 and p.stdout.endswith("\n") and json.loads(p.stdout) == out


def rep(**kw):
    r = {"id": "a", "model_version": "ordinal-v4", "observed_at": 73,
         "levels": ["high", "low", "medium"], "weights": [1, 6, 3]}
    r.update(kw)
    return r


def run(replies, **over):
    req = copy.deepcopy(base)
    req["replies"] = replies
    req.update(over)
    snap = copy.deepcopy(req)
    res = solve(req)
    assert req == snap, "mutated"
    return res["decisions"][0]


d = lambda r: {"id": "a", "status": "defer", "reason": r}
assert run([rep(), rep(model_version="x")]) == d("duplicate")
assert run([rep(model_version="x")]) == d("version")
assert run([rep(observed_at=81)]) == d("freshness")
assert run([rep(observed_at=69)]) == d("freshness")
assert run([rep(observed_at=70)])["status"] == "act"  # TTL boundary
assert run([rep(model_version="x", observed_at=0)]) == d("version")  # precedence
for bad in [
    dict(levels=["high", "low"], weights=[1, 6]),
    dict(levels=["high", "low", "low"]),
    dict(levels=["high", "low", "medium", "x"], weights=[1, 1, 1, 1]),
    dict(weights=[1, 6]),
    dict(weights=[True, 6, 3]),
    dict(weights=[None, 6, 3]),
    dict(weights=["1", 6, 3]),
    dict(weights=[-0.125, 6, 3]),
    dict(weights=[0, 0, 0.0]),
]:
    assert run([rep(**bad)]) == d("distribution"), bad
# zero weight on explicit level fine; high certain -> inspect 2 vs leave 12
assert run([rep(weights=[5, 0, 0])])["action"] == "inspect"
# low certain -> leave 0
r = run([rep(weights=[0, 2.5, 0])])
assert r["action"] == "leave" and r["expected_loss"] == 0.0, r
# mean-severity trap: low .5 high .5 -> mean ~ medium (leave=3 > 2)... distribution: leave=6 -> inspect
act = [{"name": "inspect", "losses": [2, 2, 2]}, {"name": "leave", "losses": [0, 1, 12]}]
r = run([rep(weights=[1, 1, 0])], actions=act)
assert r["action"] == "inspect" and r["expected_loss"] == 2.0, r
# tie -> lexicographic name regardless of order
act = [{"name": "zeta", "losses": [1, 1, 1]}, {"name": "alpha", "losses": [1, 1, 1]}]
assert run([rep()], actions=act)["action"] == "alpha"
# unknown-id replies ignored
assert run([rep(), rep(id="zzz")])["status"] == "act"
# non-normalized mass
r = run([rep(weights=[0.125, 0.75, 0.375])])
assert abs(r["expected_loss"] - 2.0) < 1e-12
print("all checks passed")
