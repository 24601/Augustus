"""Offline adapter: ordinal distribution replies -> loss-minimizing action or deferral."""
import json
import sys
from fractions import Fraction


def _usable_distribution(reply, policy_levels):
    """Return {level: Fraction mass} aligned by name, or None if unusable."""
    levels = reply.get("levels")
    weights = reply.get("weights")
    if not isinstance(levels, list) or not isinstance(weights, list):
        return None
    if len(levels) != len(policy_levels) or len(weights) != len(levels):
        return None
    if not all(isinstance(lv, str) for lv in levels):
        return None
    if len(set(levels)) != len(levels) or set(levels) != set(policy_levels):
        return None
    masses = {}
    for lv, w in zip(levels, weights):
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            return None
        if w != w or w in (float("inf"), float("-inf")) or w < 0:
            return None
        masses[lv] = Fraction(w)
    total = sum(masses.values(), Fraction(0))
    if total <= 0:
        return None
    return {lv: m / total for lv, m in masses.items()}


def _decide(case, request):
    cid = case["id"]
    matches = [r for r in request.get("replies", [])
               if isinstance(r, dict) and r.get("id") == cid]
    if not matches:
        return {"id": cid, "status": "defer", "reason": "missing"}
    if len(matches) > 1:
        return {"id": cid, "status": "defer", "reason": "duplicate"}
    reply = matches[0]
    if reply.get("model_version") != request["model_version"]:
        return {"id": cid, "status": "defer", "reason": "version"}
    now, observed = request["now"], reply.get("observed_at")
    if (isinstance(observed, bool) or not isinstance(observed, int)
            or observed > now or now - observed > case["ttl"]):
        return {"id": cid, "status": "defer", "reason": "freshness"}
    dist = _usable_distribution(reply, request["levels"])
    if dist is None:
        return {"id": cid, "status": "defer", "reason": "distribution"}
    best = None
    for action in request["actions"]:
        cost = sum((dist[lv] * loss for lv, loss in zip(request["levels"], action["losses"])),
                   Fraction(0))
        key = (cost, action["name"])
        if best is None or key < best:
            best = key
    cost, name = best
    return {"id": cid, "status": "act", "action": name, "expected_loss": float(cost)}


def solve(request: dict) -> dict:
    return {"decisions": [_decide(case, request) for case in request.get("cases", [])]}


def main():
    request = json.load(sys.stdin)
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
