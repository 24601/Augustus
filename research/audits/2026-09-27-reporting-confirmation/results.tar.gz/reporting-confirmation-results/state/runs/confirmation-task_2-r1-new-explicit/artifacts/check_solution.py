import copy
import json
import subprocess
import sys

from solution import solve

BASE = json.load(open("input.json"))


def req(replies, cases=None, **kw):
    r = copy.deepcopy(BASE)
    r["replies"] = replies
    if cases is not None:
        r["cases"] = cases
    r.update(kw)
    return r


def rep(id="a", v="ordinal-v4", t=73, levels=("high", "low", "medium"), w=(1, 6, 3)):
    return {"id": id, "model_version": v, "observed_at": t, "levels": list(levels), "weights": list(w)}


def one(r):
    return solve(r)["decisions"][0]


# Example: low .6 med .3 high .1 -> leave 2.1, inspect 2.0.
# The mean severity index (0.5) would favour leave; the full distribution must not.
out = solve(BASE)
assert out == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"}]}, out

# Mutation check
snap = copy.deepcopy(BASE)
solve(BASE)
assert BASE == snap

# Duplicate even with one wrong version; unknown IDs ignored
assert one(req([rep(), rep(v="old")]))["reason"] == "duplicate"
assert one(req([rep(), rep(id="zzz")]))["status"] == "act"
# Precedence: duplicate beats version; version beats freshness; freshness beats distribution
assert one(req([rep(v="x", t=999)]))["reason"] == "version"
assert one(req([rep(t=999, w=(1, "x", 1))]))["reason"] == "freshness"
# Freshness boundaries (now=80, ttl=10)
assert one(req([rep(t=70)]))["status"] == "act"
assert one(req([rep(t=69)]))["reason"] == "freshness"
assert one(req([rep(t=80)]))["status"] == "act"
assert one(req([rep(t=81)]))["reason"] == "freshness"
# Distribution failures
bad = [
    dict(levels=("high", "low"), w=(1, 6)),                 # missing level
    dict(levels=("high", "low", "low"), w=(1, 6, 3)),       # duplicate level
    dict(levels=("high", "low", "extreme"), w=(1, 6, 3)),   # unknown level
    dict(levels=("high", "low", "medium", "x"), w=(1, 6, 3, 0)),
    dict(w=(1, 6)),                                         # length mismatch
    dict(w=(1, 6, 3, 4)),
    dict(w=(True, 6, 3)),                                   # bool
    dict(w=(None, 6, 3)),
    dict(w=("1", 6, 3)),
    dict(w=(-0.125, 6, 3)),                                 # negative
    dict(w=(0, 0, 0.0)),                                    # zero sum
]
for b in bad:
    assert one(req([rep(**b)]))["reason"] == "distribution", b
# Zero weight on included level is fine; unnormalized floats fine
d = one(req([rep(w=(0, 0.125, 0))])); assert d == {"id": "a", "status": "act", "action": "leave", "expected_loss": 0.0}, d
d = one(req([rep(w=(10000, 0, 0))])); assert d["action"] == "inspect" and d["expected_loss"] == 2.0, d
# Scaling invariance
assert one(req([rep(w=(2, 12, 6))])) == one(req([rep()]))
# Tie -> lexicographically smaller name regardless of order: all-medium: inspect 2 vs leave 3; make tie
acts = [{"name": "zeta", "losses": [1, 1, 1]}, {"name": "alpha", "losses": [0, 1, 2]}]
d = one(req([rep(w=(0, 0, 1))], actions=acts)); assert d["action"] == "alpha" and d["expected_loss"] == 1.0, d
d = one(req([rep(w=(1, 1, 0))], actions=acts)); assert d["action"] == "alpha" and d["expected_loss"] == 1.0, d
# Policy difference: raising leave's high loss changes action
acts2 = [{"name": "inspect", "losses": [2, 2, 2]}, {"name": "leave", "losses": [0, 3, 5]}]
d = one(req([rep()], actions=acts2)); assert d["action"] == "leave" and abs(d["expected_loss"] - 1.4) < 1e-12, d
# Case order preserved; empty cases
out = solve(req([rep(id="b"), rep()], cases=[{"id": "b", "ttl": 10}, {"id": "a", "ttl": 10}]))
assert [x["id"] for x in out["decisions"]] == ["b", "a"]
assert solve(req([], cases=[])) == {"decisions": []}

# CLI
p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(BASE), capture_output=True, text=True)
assert p.returncode == 0 and p.stdout.endswith("\n") and json.loads(p.stdout) == solve(BASE), p
print("all checks passed")
