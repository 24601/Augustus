import copy
import json
import subprocess
import sys

import solution as S


def cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    assert p.stdout.endswith("\n") and p.stdout.count("\n") == 1
    return json.loads(p.stdout)


req = json.load(open("input.json"))
orig = copy.deepcopy(req)
art = cli(req)
assert art == {"schema": 1, "policy_id": "field-v2", "scenarios": ["heat", "rain", "wind"],
               "modes": [{"name": "canvas", "losses": [3, 2, 9]},
                         {"name": "hybrid", "losses": [4, 4, 4]},
                         {"name": "steel", "losses": [8, 5, 1]}]}, art
a2 = S.compile_policy(req["spec"])
assert a2 == art and req == orig
a2["modes"][0]["losses"][0] = 99
assert req == orig
json.dump(art, open("artifact_public.json", "w"))

D = lambda al, m: cli({"op": "decide", "artifact": art, "allowed": al, "max_regret": m})
assert D(["steel", "canvas", "hybrid"], 3) == {"status": "act", "mode": "hybrid", "worst_regret": 3}
assert D(["steel", "canvas", "hybrid"], 2) == {"status": "defer", "reason": "regret_limit"}
assert D(["canvas", "steel"], 5) == {"status": "act", "mode": "steel", "worst_regret": 5}
assert D(["canvas"], 0) == {"status": "act", "mode": "canvas", "worst_regret": 0}
assert D([], 0) == {"status": "defer", "reason": "no_mode"}
assert D(["canvas", "ghost"], 100) == {"status": "defer", "reason": "unknown_mode"}

# tie-breaks
t = S.compile_policy({"policy_id": "t", "scenarios": ["b", "a"],
                      "modes": [{"name": "y", "losses": [0, 4]}, {"name": "x", "losses": [4, 0]},
                                {"name": "z", "losses": [2, 2]}]})
# best [0,0]: x,y regret 4 maxloss 4; z regret 2
assert S.decide(t, ["x", "y"], 9) == {"status": "act", "mode": "x", "worst_regret": 4}
assert S.decide(t, ["y", "x", "z"], 9)["mode"] == "z"
t2 = S.compile_policy({"policy_id": "t", "scenarios": ["s"],
                       "modes": [{"name": "b", "losses": [1]}, {"name": "a", "losses": [1]}]})
assert S.decide(t2, ["b", "a"], 0) == {"status": "act", "mode": "a", "worst_regret": 0}
# lower max loss breaks regret tie over name
t3 = S.compile_policy({"policy_id": "t", "scenarios": ["p", "q"],
                       "modes": [{"name": "a", "losses": [5, 9]}, {"name": "b", "losses": [9, 5]},
                                 {"name": "c", "losses": [9, 9]}]})
# best [5,5]: a 4 max9, b 4 max9, c 4 max9 -> a
assert S.decide(t3, ["c", "b", "a"], 4)["mode"] == "a"
t4 = S.compile_policy({"policy_id": "t", "scenarios": ["p", "q"],
                       "modes": [{"name": "a", "losses": [10, 6]}, {"name": "b", "losses": [6, 9]}]})
# best [6,6]: a regret 4 max 10, b regret 3 -> b; make equal regrets:
t5 = S.compile_policy({"policy_id": "t", "scenarios": ["p", "q", "r"],
                       "modes": [{"name": "a", "losses": [3, 0, 7]}, {"name": "b", "losses": [0, 3, 6]}]})
# best [0,0,6]: a regret max(3,0,1)=3 max7; b regret 3 max6 -> b
assert S.decide(t5, ["a", "b"], 3)["mode"] == "b"
print("all checks passed")
