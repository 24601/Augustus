import copy
import json
import subprocess
import sys

from solution import solve

LEVELS = ["low", "medium", "high"]
ACTIONS = [{"name": "inspect", "losses": [2, 2, 2]}, {"name": "leave", "losses": [0, 3, 12]}]


def req(replies, cases=None, actions=None, now=80):
    return {"now": now, "model_version": "v4", "levels": LEVELS,
            "actions": actions or ACTIONS,
            "cases": cases or [{"id": "a", "ttl": 10}], "replies": replies}


def rep(**kw):
    r = {"id": "a", "model_version": "v4", "observed_at": 73,
         "levels": ["high", "low", "medium"], "weights": [1, 6, 3]}
    r.update(kw)
    return r


def one(request):
    return solve(request)["decisions"][0]


def reason(request):
    d = one(request)
    assert d["status"] == "defer", d
    return d["reason"]


# Provided example, via CLI.
with open("input.json") as f:
    example = json.load(f)
out = subprocess.run([sys.executable, "solution.py"], input=json.dumps(example),
                     capture_output=True, text=True, check=True).stdout
assert out.endswith("\n") and out.count("\n") == 1
got = json.loads(out)
assert got == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"}]}, got

# Precedence and defer reasons.
assert reason(req([])) == "missing"
assert reason(req([rep(), rep(model_version="old")])) == "duplicate"
assert reason(req([rep(model_version="x", observed_at=999, weights=[None])])) == "version"
assert reason(req([rep(observed_at=81)])) == "freshness"
assert reason(req([rep(observed_at=69)])) == "freshness"
assert one(req([rep(observed_at=70)]))["status"] == "act"  # TTL boundary
assert one(req([rep(observed_at=80)]))["status"] == "act"
assert one(req([rep(id="zzz")]))["reason"] == "missing"  # unknown id ignored
for bad in [
    dict(levels=["high", "low"], weights=[1, 6]),
    dict(levels=["high", "low", "low"], weights=[1, 6, 3]),
    dict(levels=["high", "low", "medium", "extra"], weights=[1, 6, 3, 0]),
    dict(levels=["High", "low", "medium"]),
    dict(weights=[1, 6]),
    dict(weights=[1, 6, 3, 0]),
    dict(weights=[True, 6, 3]),
    dict(weights=[None, 6, 3]),
    dict(weights=["1", 6, 3]),
    dict(weights=[-0.125, 6, 3]),
    dict(weights=[0, 0, 0.0]),
    dict(weights=None),
]:
    assert reason(req([rep(**bad)])) == "distribution", bad

# Normalization, alignment, zero weights, floats.
d = one(req([rep(weights=[0.5, 3.0, 1.5])]))
assert d["action"] == "inspect" and abs(d["expected_loss"] - 2.0) < 1e-12
d = one(req([rep(weights=[0, 8, 0])]))
assert d == {"id": "a", "status": "act", "action": "leave", "expected_loss": 0.0}
# Alignment by name: all mass on "high" listed last.
d = one(req([rep(levels=["low", "medium", "high"], weights=[0, 0, 1])]))
assert d["action"] == "inspect" and d["expected_loss"] == 2.0

# Mean severity would say "medium" (leave=3 > inspect=2 anyway); construct a case
# where the mean level favours one action but the full distribution favours another.
acts = [{"name": "risky", "losses": [0, 0, 100]}, {"name": "safe", "losses": [10, 10, 10]}]
d = one(req([rep(levels=LEVELS, weights=[1, 0, 1])], actions=acts))  # mean = medium
assert d["action"] == "safe" and d["expected_loss"] == 10.0, d

# Ties go to lexicographically smaller name regardless of order.
acts = [{"name": "zeta", "losses": [1, 1, 1]}, {"name": "alpha", "losses": [1, 1, 1]}]
assert one(req([rep()], actions=acts))["action"] == "alpha"

# Non-trivial expected loss accuracy.
d = one(req([rep(weights=[1, 1, 1])]))
assert d["action"] == "inspect"
acts = [{"name": "x", "losses": [1, 2, 4]}]
d = one(req([rep(levels=LEVELS, weights=[1, 1, 1])], actions=acts))
assert abs(d["expected_loss"] - 7 / 3) < 1e-12

# Output order follows cases; request not mutated.
r = req([rep(id="b"), rep()], cases=[{"id": "b", "ttl": 10}, {"id": "a", "ttl": 10}])
snap = copy.deepcopy(r)
assert [x["id"] for x in solve(r)["decisions"]] == ["b", "a"]
assert r == snap
assert solve(req([], cases=[{"id": "a", "ttl": 1}]) | {"cases": []}) == {"decisions": []}
print("all checks passed")
