"""Offline adapter: ordinal severity distributions -> loss-minimizing action or defer."""
import json
import sys
from fractions import Fraction


def _distribution(reply, levels):
    """Return {level: Fraction probability} or None if the evidence is unusable."""
    rlevels = reply.get("levels")
    weights = reply.get("weights")
    if not isinstance(rlevels, list) or not isinstance(weights, list):
        return None
    if len(rlevels) != len(levels) or len(weights) != len(rlevels):
        return None
    if not all(isinstance(x, str) for x in rlevels):
        return None
    if len(set(rlevels)) != len(rlevels) or set(rlevels) != set(levels):
        return None
    masses = []
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            return None
        if w != w or w in (float("inf"), float("-inf")) or w < 0:
            return None
        masses.append(Fraction(w))
    total = sum(masses, Fraction(0))
    if total <= 0:
        return None
    return {lvl: m / total for lvl, m in zip(rlevels, masses)}


def _decide(case, replies, request):
    cid = case["id"]
    matches = [r for r in replies if isinstance(r, dict) and r.get("id") == cid]
    if not matches:
        return {"id": cid, "status": "defer", "reason": "missing"}
    if len(matches) > 1:
        return {"id": cid, "status": "defer", "reason": "duplicate"}
    reply = matches[0]
    if reply.get("model_version") != request["model_version"]:
        return {"id": cid, "status": "defer", "reason": "version"}
    now, obs = request["now"], reply.get("observed_at")
    if (isinstance(obs, bool) or not isinstance(obs, int)
            or obs > now or now - obs > case["ttl"]):
        return {"id": cid, "status": "defer", "reason": "freshness"}
    dist = _distribution(reply, request["levels"])
    if dist is None:
        return {"id": cid, "status": "defer", "reason": "distribution"}
    best = None
    for action in request["actions"]:
        cost = sum((dist[lvl] * loss for lvl, loss in zip(request["levels"], action["losses"])),
                   Fraction(0))
        key = (cost, action["name"])
        if best is None or key < best:
            best = key
    return {"id": cid, "status": "act", "action": best[1], "expected_loss": float(best[0])}


def solve(request: dict) -> dict:
    replies = request.get("replies") or []
    return {"decisions": [_decide(c, replies, request) for c in request.get("cases") or []]}


def main():
    request = json.load(sys.stdin)
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
