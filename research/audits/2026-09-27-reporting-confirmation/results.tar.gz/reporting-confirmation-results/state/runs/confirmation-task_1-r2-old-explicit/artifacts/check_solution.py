"""Hand-calculated checks, including a fresh-process CLI round trip of the artifact."""
import copy
import json
import subprocess
import sys

import solution

HERE_CLI = [sys.executable, "solution.py"]


def cli(request):
    proc = subprocess.run(HERE_CLI, input=json.dumps(request), capture_output=True, text=True)
    assert proc.returncode == 0, proc.stderr
    assert proc.stdout.endswith("\n") and proc.stdout.count("\n") == 1, proc.stdout
    return json.loads(proc.stdout)


with open("input.json") as f:
    req = json.load(f)
orig = copy.deepcopy(req)

art = cli(req)
assert art == {
    "schema": 1, "policy_id": "field-v2", "scenarios": ["heat", "rain", "wind"],
    "modes": [{"name": "canvas", "losses": [3, 2, 9]},
              {"name": "hybrid", "losses": [4, 4, 4]},
              {"name": "steel", "losses": [8, 5, 1]}],
}, art

# In-process: no mutation, no aliasing.
a2 = solution.compile_policy(req["spec"])
assert req == orig and a2 == art
a2["modes"][0]["losses"][0] = 99
assert req == orig
for m in req["spec"]["modes"]:
    assert all(m["losses"] is not x["losses"] for x in a2["modes"])

# Reload artifact (JSON) in a fresh process and decide.
def d(allowed, mr, artifact=art):
    return cli({"op": "decide", "artifact": json.loads(json.dumps(artifact)),
                "allowed": allowed, "max_regret": mr})

assert d(["canvas", "hybrid", "steel"], 3) == {"status": "act", "mode": "hybrid", "worst_regret": 3}
assert d(["steel", "hybrid", "canvas"], 2) == {"status": "defer", "reason": "regret_limit"}
# Subset changes the best-achievable baseline.
assert d(["canvas", "steel"], 5) == {"status": "act", "mode": "steel", "worst_regret": 5}
assert d(["hybrid"], 0) == {"status": "act", "mode": "hybrid", "worst_regret": 0}
assert d([], 0) == {"status": "defer", "reason": "no_mode"}
assert d(["hybrid", "tent"], 100) == {"status": "defer", "reason": "unknown_mode"}
assert d(["tent"], 100) == {"status": "defer", "reason": "unknown_mode"}

# Tie-breaks: equal regret -> lower max loss beats name; then name.
tie = solution.compile_policy({"policy_id": "t", "scenarios": ["s2", "s1", "s3"], "modes": [
    {"name": "p", "losses": [3, 0, 9]}, {"name": "q", "losses": [0, 3, 8]},
    {"name": "b", "losses": [2, 0, 5]}, {"name": "a", "losses": [0, 2, 5]}]})
assert tie["scenarios"] == ["s1", "s2", "s3"]
assert solution.decide(tie, ["p", "q"], 9) == {"status": "act", "mode": "q", "worst_regret": 3}
assert solution.decide(tie, ["b", "a"], 2) == {"status": "act", "mode": "a", "worst_regret": 2}
assert solution.decide(tie, ["b", "a"], 1) == {"status": "defer", "reason": "regret_limit"}
allowed = ["b", "a"]
solution.decide(tie, allowed, 2)
assert allowed == ["b", "a"]

print("all checks passed")
