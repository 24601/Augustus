"""Hand-calculated checks for solution.py, including a fresh-process CLI round trip."""
import copy
import json
import subprocess
import sys

import solution

ok = True


def check(label, got, want):
    global ok
    if got != want:
        ok = False
        print("FAIL", label, "got", got, "want", want)
    else:
        print("ok  ", label)


def cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0 and p.stdout.endswith("\n") and p.stdout.count("\n") == 1, p
    return json.loads(p.stdout)


with open("input.json") as f:
    req = json.load(f)
orig = copy.deepcopy(req)
art = cli(req)
check("input unchanged", req, orig)
check("artifact", art, {
    "schema": 1, "policy_id": "field-v2", "scenarios": ["heat", "rain", "wind"],
    "modes": [{"name": "canvas", "losses": [3, 2, 9]},
              {"name": "hybrid", "losses": [4, 4, 4]},
              {"name": "steel", "losses": [8, 5, 1]}]})
a2 = solution.compile_policy(req["spec"])
a2["modes"][0]["losses"][0] = 99
check("no alias to input", req, orig)

D = lambda allowed, r: cli({"op": "decide", "artifact": art, "allowed": allowed, "max_regret": r})
check("all modes", D(["steel", "canvas", "hybrid"], 3), {"status": "act", "mode": "hybrid", "worst_regret": 3})
check("limit exceeded", D(["steel", "canvas", "hybrid"], 2), {"status": "defer", "reason": "regret_limit"})
check("subset recomputes best", D(["canvas", "steel"], 5), {"status": "act", "mode": "steel", "worst_regret": 5})
check("single mode", D(["canvas"], 0), {"status": "act", "mode": "canvas", "worst_regret": 0})
check("empty", D([], 0), {"status": "defer", "reason": "no_mode"})
check("unknown precedence", D(["canvas", "ghost"], 100), {"status": "defer", "reason": "unknown_mode"})
check("unknown over empty-ish", D(["ghost"], 0), {"status": "defer", "reason": "unknown_mode"})

# Ties: equal worst regret -> lower max loss, then name.
t = solution.compile_policy({"policy_id": "t", "scenarios": ["y", "x"], "modes": [
    {"name": "b", "losses": [0, 2]}, {"name": "a", "losses": [2, 0]}, {"name": "c", "losses": [1, 1]}]})
# x,y order: a=[0,2], b=[2,0], c=[1,1]; best [0,0]; regrets a2 b2 c1
check("tie data", t["modes"], [{"name": "a", "losses": [0, 2]}, {"name": "b", "losses": [2, 0]}, {"name": "c", "losses": [1, 1]}])
check("c wins", solution.decide(t, ["a", "b", "c"], 1), {"status": "act", "mode": "c", "worst_regret": 1})
check("name tie", solution.decide(t, ["b", "a"], 2), {"status": "act", "mode": "a", "worst_regret": 2})
t2 = solution.compile_policy({"policy_id": "t", "scenarios": ["x", "y"], "modes": [
    {"name": "a", "losses": [5, 5]}, {"name": "z", "losses": [3, 3]}]})
# best [3,3]; a regret 2, z 0
check("regret first", solution.decide(t2, ["a", "z"], 0), {"status": "act", "mode": "z", "worst_regret": 0})
t3 = solution.compile_policy({"policy_id": "t", "scenarios": ["x", "y"], "modes": [
    {"name": "a", "losses": [9, 9]}, {"name": "b", "losses": [4, 4]}]})
check("max-loss tie", solution.decide(t3, ["a"], 0), {"status": "act", "mode": "a", "worst_regret": 0})
t4 = solution.compile_policy({"policy_id": "t", "scenarios": ["x", "y"], "modes": [
    {"name": "a", "losses": [0, 6]}, {"name": "b", "losses": [6, 0]}, {"name": "c", "losses": [6, 5]}]})
# best [0,0]; a6 b6 c6; max losses 6,6,6 -> a
check("full tie -> name", solution.decide(t4, ["c", "b", "a"], 6), {"status": "act", "mode": "a", "worst_regret": 6})
t5 = solution.compile_policy({"policy_id": "t", "scenarios": ["x", "y"], "modes": [
    {"name": "a", "losses": [0, 7]}, {"name": "b", "losses": [4, 3]}, {"name": "c", "losses": [5, 3]}]})
# best [0,3]; a4 b4 c5; maxloss a7 b4 -> b
check("max-loss breaks", solution.decide(t5, ["a", "b", "c"], 4), {"status": "act", "mode": "b", "worst_regret": 4})

print("ALL OK" if ok else "FAILURES")
