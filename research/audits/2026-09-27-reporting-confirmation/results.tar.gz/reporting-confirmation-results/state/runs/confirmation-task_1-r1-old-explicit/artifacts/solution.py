"""Minimax-regret policy: compile a reusable artifact, then decide over allowed modes."""
import json
import sys


def compile_policy(spec: dict) -> dict:
    scenarios = list(spec["scenarios"])
    order = sorted(range(len(scenarios)), key=lambda i: scenarios[i])
    modes = sorted(
        (
            {"name": str(m["name"]), "losses": [int(m["losses"][i]) for i in order]}
            for m in spec["modes"]
        ),
        key=lambda m: m["name"],
    )
    return {
        "schema": 1,
        "policy_id": spec["policy_id"],
        "scenarios": [scenarios[i] for i in order],
        "modes": modes,
    }


def decide(artifact: dict, allowed: list, max_regret: int) -> dict:
    table = {m["name"]: list(m["losses"]) for m in artifact["modes"]}
    names = list(allowed)
    if any(n not in table for n in names):
        return {"status": "defer", "reason": "unknown_mode"}
    if not names:
        return {"status": "defer", "reason": "no_mode"}
    n_scen = len(artifact["scenarios"])
    best = [min(table[n][s] for n in names) for s in range(n_scen)]
    candidates = []
    for n in names:
        losses = table[n]
        worst = max((losses[s] - best[s] for s in range(n_scen)), default=0)
        candidates.append((worst, max(losses, default=0), n))
    worst, _, mode = min(candidates)
    if worst > max_regret:
        return {"status": "defer", "reason": "regret_limit"}
    return {"status": "act", "mode": mode, "worst_regret": worst}


def solve(request: dict) -> dict:
    if request["op"] == "compile":
        return compile_policy(request["spec"])
    return decide(request["artifact"], request["allowed"], request["max_regret"])


def main() -> None:
    request = json.loads(sys.stdin.read())
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
