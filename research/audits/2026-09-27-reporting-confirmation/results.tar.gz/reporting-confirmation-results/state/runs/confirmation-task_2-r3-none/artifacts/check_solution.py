import copy
import json
import subprocess
import sys

from solution import solve


def run_cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    assert p.stdout.endswith("\n") and p.stdout.count("\n") == 1
    return json.loads(p.stdout)


with open("input.json") as f:
    base = json.load(f)

out = run_cli(base)
assert out == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"}]}, out


def rep(id, **kw):
    r = {"id": id, "model_version": "ordinal-v4", "observed_at": 75,
         "levels": ["low", "medium", "high"], "weights": [1, 1, 1]}
    r.update(kw)
    return r


def case(ids_ttl, replies, actions=None):
    req = copy.deepcopy(base)
    req["cases"] = [{"id": i, "ttl": t} for i, t in ids_ttl]
    req["replies"] = replies
    if actions is not None:
        req["actions"] = actions
    snap = copy.deepcopy(req)
    res = solve(req)
    assert req == snap, "mutated"
    return res["decisions"]


# duplicate beats version; unknown ids ignored
d = case([("a", 10)], [rep("a"), rep("a", model_version="x"), rep("zz")])
assert d[0]["reason"] == "duplicate", d
assert case([("a", 10)], [rep("a", model_version="v3")])[0]["reason"] == "version"
# version checked before freshness
assert case([("a", 1)], [rep("a", model_version="v3", observed_at=0)])[0]["reason"] == "version"
# freshness boundaries
assert case([("a", 5)], [rep("a", observed_at=75)])[0]["status"] == "act"
assert case([("a", 4)], [rep("a", observed_at=75)])[0]["reason"] == "freshness"
assert case([("a", 4)], [rep("a", observed_at=81)])[0]["reason"] == "freshness"
assert case([("a", 0)], [rep("a", observed_at=80)])[0]["status"] == "act"
# freshness before distribution
assert case([("a", 1)], [rep("a", observed_at=0, weights=[None])])[0]["reason"] == "freshness"
bad = [
    dict(levels=["low", "medium"], weights=[1, 1]),
    dict(levels=["low", "medium", "medium"]),
    dict(levels=["low", "medium", "high", "extra"], weights=[1, 1, 1, 1]),
    dict(levels=["low", "medium", "critical"]),
    dict(weights=[1, 1]),
    dict(weights=[1, 1, 1, 1]),
    dict(weights=[1, True, 1]),
    dict(weights=[1, None, 1]),
    dict(weights=[1, "1", 1]),
    dict(weights=[1, -0.125, 1]),
    dict(weights=[0, 0, 0]),
    dict(weights=[0.0, 0, 0.0]),
]
for kw in bad:
    assert case([("a", 10)], [rep("a", **kw)])[0]["reason"] == "distribution", kw
# zero weights on included levels valid, unnormalized mass, aligned by name
acts = [{"name": "inspect", "losses": [2, 2, 2]}, {"name": "leave", "losses": [0, 3, 12]}]
d = case([("a", 10)], [rep("a", levels=["high", "low", "medium"], weights=[0, 0.5, 0.125])], acts)
# low .8 med .2 -> leave 0.6
assert d[0]["action"] == "leave" and abs(d[0]["expected_loss"] - 0.6) < 1e-12, d
# mean-severity trap: bimodal low/high -> mean is medium, but full dist matters
acts2 = [{"name": "mid", "losses": [5, 0, 5]}, {"name": "ext", "losses": [0, 10, 0]}]
d = case([("a", 10)], [rep("a", weights=[1, 0, 1])], acts2)
assert d[0]["action"] == "ext" and d[0]["expected_loss"] == 0.0, d
# tie -> lexicographically smaller name regardless of order
acts3 = [{"name": "zeta", "losses": [1, 1, 1]}, {"name": "alpha", "losses": [0, 1.5 and 1, 2]}]
d = case([("a", 10)], [rep("a", weights=[1, 1, 1])], acts3)
assert d[0]["action"] == "alpha" and d[0]["expected_loss"] == 1.0, d
# order of decisions follows cases
d = case([("b", 10), ("a", 10)], [rep("a")])
assert [x["id"] for x in d] == ["b", "a"]
assert case([], [rep("a")]) == []
# key shape
d = case([("a", 10)], [rep("a")])
assert set(d[0]) == {"id", "status", "action", "expected_loss"}
print("all checks passed")
