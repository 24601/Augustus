import copy
import json
import subprocess
import sys

from solution import solve

with open("input.json") as f:
    base = json.load(f)

# Example: p = low .6, medium .3, high .1 -> inspect 2.0, leave 2.1.
# (Mean-severity shortcut would pick leave: index 0.5 -> 1.5.)
out = solve(copy.deepcopy(base))
assert out == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"}]}, out

snapshot = copy.deepcopy(base)
solve(base)
assert base == snapshot, "request mutated"


def reply(**kw):
    r = {"id": "a", "model_version": "ordinal-v4", "observed_at": 73,
         "levels": ["high", "low", "medium"], "weights": [1, 6, 3]}
    r.update(kw)
    return r


def run(replies, **over):
    req = copy.deepcopy(base)
    req["replies"] = replies
    req.update(over)
    return solve(req)["decisions"][0]


def reason(replies, **over):
    d = run(replies, **over)
    return d.get("reason", d.get("action"))


assert reason([reply(), reply(model_version="old")]) == "duplicate"
assert reason([reply(), reply(id="zzz")]) == "inspect"  # unknown id ignored
assert reason([reply(model_version="v3")]) == "version"
assert reason([reply(model_version="v3", observed_at=999)]) == "version"
assert reason([reply(observed_at=81)]) == "freshness"
assert reason([reply(observed_at=70)]) == "inspect"  # exactly at TTL
assert reason([reply(observed_at=69)]) == "freshness"
assert reason([reply(observed_at=69, weights=[None])]) == "freshness"
for bad in [
    dict(levels=["high", "low"], weights=[1, 6]),
    dict(levels=["high", "low", "low"]),
    dict(levels=["high", "low", "medium", "extra"], weights=[1, 6, 3, 0]),
    dict(levels=["high", "low", "urgent"]),
    dict(weights=[1, 6]),
    dict(weights=[1, 6, 3, 0]),
    dict(weights=[True, 6, 3]),
    dict(weights=[None, 6, 3]),
    dict(weights=["1", 6, 3]),
    dict(weights=[-0.125, 6, 3]),
    dict(weights=[0, 0, 0]),
    dict(weights=[0.0, 0, 0.0]),
]:
    assert reason([reply(**bad)]) == "distribution", bad

# Zero weight on an included level is fine; unnormalized floats are fine.
d = run([reply(weights=[0, 0.5, 0.5])])
assert d["action"] == "leave" and abs(d["expected_loss"] - 1.5) < 1e-12, d
d = run([reply(weights=[1000, 6000, 3000])])
assert d["action"] == "inspect" and d["expected_loss"] == 2.0, d

# Tie -> lexicographically smaller name regardless of action order.
tie = [{"name": "zeta", "losses": [1, 1, 1]}, {"name": "alpha", "losses": [1, 1, 1]}]
assert run([reply()], actions=tie)["action"] == "alpha"

# Loss policy changes the decision: cheaper "high" penalty makes leave win.
pol = [{"name": "inspect", "losses": [2, 2, 2]}, {"name": "leave", "losses": [0, 3, 5]}]
d = run([reply()], actions=pol)
assert d["action"] == "leave" and abs(d["expected_loss"] - 1.4) < 1e-12, d

# Accuracy with thirds.
d = run([reply(weights=[1, 1, 1])])
assert abs(d["expected_loss"] - 2.0) < 1e-12 and d["action"] == "inspect"
d = run([reply(weights=[1, 1, 1])], actions=pol)
assert abs(d["expected_loss"] - 8 / 3) < 1e-12 or d["action"] == "inspect"

# Empty cases.
assert solve({**base, "cases": []}) == {"decisions": []}

# CLI.
p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(snapshot),
                   capture_output=True, text=True)
assert p.returncode == 0 and p.stdout.endswith("\n") and p.stdout.count("\n") == 1
assert json.loads(p.stdout) == out
print("all checks passed")
