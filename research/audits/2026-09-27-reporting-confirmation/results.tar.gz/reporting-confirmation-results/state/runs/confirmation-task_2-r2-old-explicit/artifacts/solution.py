"""Offline adapter: ordinal severity distribution -> loss-minimizing action or deferral."""
import json
import sys
from fractions import Fraction


def _distribution(reply, levels):
    """Return {level: Fraction probability} or None if the evidence is unusable."""
    r_levels = reply.get("levels")
    weights = reply.get("weights")
    if not isinstance(r_levels, list) or not isinstance(weights, list):
        return None
    if len(r_levels) != len(levels) or len(weights) != len(r_levels):
        return None
    if not all(isinstance(x, str) for x in r_levels) or set(r_levels) != set(levels):
        return None
    if len(set(r_levels)) != len(r_levels):
        return None
    masses = []
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            return None
        w = Fraction(w)
        if w < 0:
            return None
        masses.append(w)
    total = sum(masses)
    if total <= 0:
        return None
    return {lvl: m / total for lvl, m in zip(r_levels, masses)}


def _decide(case, request, by_id):
    cid = case["id"]
    replies = by_id.get(cid, [])
    if not replies:
        return {"id": cid, "status": "defer", "reason": "missing"}
    if len(replies) > 1:
        return {"id": cid, "status": "defer", "reason": "duplicate"}
    reply = replies[0]
    if reply.get("model_version") != request["model_version"]:
        return {"id": cid, "status": "defer", "reason": "version"}
    obs = reply.get("observed_at")
    now = request["now"]
    if (isinstance(obs, bool) or not isinstance(obs, int)
            or obs > now or now - obs > case["ttl"]):
        return {"id": cid, "status": "defer", "reason": "freshness"}
    levels = request["levels"]
    probs = _distribution(reply, levels)
    if probs is None:
        return {"id": cid, "status": "defer", "reason": "distribution"}
    best = None
    for action in request["actions"]:
        cost = sum(probs[lvl] * loss for lvl, loss in zip(levels, action["losses"]))
        key = (cost, action["name"])
        if best is None or key < best:
            best = key
    return {"id": cid, "status": "act", "action": best[1],
            "expected_loss": float(best[0])}


def solve(request: dict) -> dict:
    by_id = {}
    for reply in request.get("replies", []):
        by_id.setdefault(reply.get("id"), []).append(reply)
    return {"decisions": [_decide(c, request, by_id) for c in request["cases"]]}


def main():
    request = json.load(sys.stdin)
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
