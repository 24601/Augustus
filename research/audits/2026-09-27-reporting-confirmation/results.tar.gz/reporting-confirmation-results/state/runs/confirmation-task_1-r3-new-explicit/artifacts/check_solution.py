import copy
import json
import subprocess
import sys

from solution import compile_policy, decide, solve


def cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0 and p.stdout.endswith("\n") and p.stdout.count("\n") == 1, p
    return json.loads(p.stdout)


req = json.load(open("input.json"))
orig = copy.deepcopy(req)
art = cli(req)
assert art == {"schema": 1, "policy_id": "field-v2", "scenarios": ["heat", "rain", "wind"],
               "modes": [{"name": "canvas", "losses": [3, 2, 9]},
                         {"name": "hybrid", "losses": [4, 4, 4]},
                         {"name": "steel", "losses": [8, 5, 1]}]}, art
a2 = solve(req)
assert req == orig and a2 == art
# no aliasing
a2["modes"][0]["losses"][0] = 99
assert req == orig
assert solve(req) == art

# decide via fresh process with reloaded artifact
def d(allowed, lim):
    return cli({"op": "decide", "artifact": art, "allowed": allowed, "max_regret": lim})

assert d(["canvas", "hybrid", "steel"], 3) == {"status": "act", "mode": "hybrid", "worst_regret": 3}
assert d(["steel", "hybrid", "canvas"], 2) == {"status": "defer", "reason": "regret_limit"}
assert d(["canvas", "steel"], 5) == {"status": "act", "mode": "steel", "worst_regret": 5}
assert d(["canvas"], 0) == {"status": "act", "mode": "canvas", "worst_regret": 0}
assert d([], 10) == {"status": "defer", "reason": "no_mode"}
assert d(["canvas", "tarp"], 10) == {"status": "defer", "reason": "unknown_mode"}
assert d(["tarp"], 10) == {"status": "defer", "reason": "unknown_mode"}

# tie-breaks: equal regret -> lower max loss -> name
t = compile_policy({"policy_id": "t", "scenarios": ["b", "a"],
                    "modes": [{"name": "z", "losses": [2, 0]}, {"name": "y", "losses": [0, 2]},
                              {"name": "x", "losses": [0, 2]}]})
assert t["scenarios"] == ["a", "b"] and t["modes"][0] == {"name": "x", "losses": [2, 0]}
assert decide(t, ["z", "y", "x"], 2) == {"status": "act", "mode": "x", "worst_regret": 2}
t2 = compile_policy({"policy_id": "t", "scenarios": ["s", "r"],
                     "modes": [{"name": "a", "losses": [5, 0]}, {"name": "b", "losses": [3, 3]},
                               {"name": "c", "losses": [0, 5]}]})
# regrets: a (0/5 vs best 0,0) -> 5, b -> 3, c -> 5
assert decide(t2, ["a", "c"], 5) == {"status": "act", "mode": "a", "worst_regret": 5}
assert decide(t2, ["a", "b", "c"], 3)["mode"] == "b"
json.dumps(t2)
print("all checks passed")
