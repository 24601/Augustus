"""Reusable minimax-regret policy: compile a loss table, then decide over allowed modes."""
import json
import sys


def compile_policy(spec: dict) -> dict:
    scenarios = list(spec["scenarios"])
    order = sorted(range(len(scenarios)), key=lambda i: scenarios[i])
    modes = sorted(
        (
            {"name": str(m["name"]), "losses": [int(m["losses"][i]) for i in order]}
            for m in spec["modes"]
        ),
        key=lambda m: m["name"],
    )
    return {
        "schema": 1,
        "policy_id": spec["policy_id"],
        "scenarios": [scenarios[i] for i in order],
        "modes": modes,
    }


def decide(artifact: dict, allowed: list, max_regret: int) -> dict:
    table = {m["name"]: list(m["losses"]) for m in artifact["modes"]}
    if any(name not in table for name in allowed):
        return {"status": "defer", "reason": "unknown_mode"}
    if not allowed:
        return {"status": "defer", "reason": "no_mode"}

    n = len(artifact["scenarios"])
    best = [min(table[b][s] for b in allowed) for s in range(n)]
    candidates = []
    for name in allowed:
        losses = table[name]
        worst = max(losses[s] - best[s] for s in range(n))
        candidates.append((worst, max(losses), name))
    worst, _, name = min(candidates)
    if worst > max_regret:
        return {"status": "defer", "reason": "regret_limit"}
    return {"status": "act", "mode": name, "worst_regret": worst}


def solve(request: dict) -> dict:
    if request["op"] == "compile":
        return compile_policy(request["spec"])
    return decide(request["artifact"], request["allowed"], request["max_regret"])


def main() -> None:
    request = json.loads(sys.stdin.read())
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
