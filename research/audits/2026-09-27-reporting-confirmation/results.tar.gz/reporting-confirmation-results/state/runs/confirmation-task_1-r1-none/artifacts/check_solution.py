import copy
import json
import subprocess
import sys


def cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0 and p.stdout.endswith("\n") and p.stdout.count("\n") == 1, p
    return json.loads(p.stdout)


with open("input.json") as f:
    req = json.load(f)
orig = copy.deepcopy(req)
art = cli(req)
assert art == {"schema": 1, "policy_id": "field-v2", "scenarios": ["heat", "rain", "wind"],
               "modes": [{"name": "canvas", "losses": [3, 2, 9]},
                         {"name": "hybrid", "losses": [4, 4, 4]},
                         {"name": "steel", "losses": [8, 5, 1]}]}, art

d = lambda allowed, r: cli({"op": "decide", "artifact": art, "allowed": allowed, "max_regret": r})
assert d(["steel", "hybrid", "canvas"], 3) == {"status": "act", "mode": "hybrid", "worst_regret": 3}
assert d(["steel", "hybrid", "canvas"], 2) == {"status": "defer", "reason": "regret_limit"}
assert d([], 0) == {"status": "defer", "reason": "no_mode"}
assert d(["hybrid", "nope"], 99) == {"status": "defer", "reason": "unknown_mode"}
assert d(["steel"], 0) == {"status": "act", "mode": "steel", "worst_regret": 0}
# canvas vs steel: canvas regrets [0,0,8]=8, steel [5,3,0]=5 -> steel
assert d(["canvas", "steel"], 10) == {"status": "act", "mode": "steel", "worst_regret": 5}

import solution
a = solution.compile_policy(req["spec"])
assert req == orig
assert a["modes"][0]["losses"] is not req["spec"]["modes"][0]["losses"]
# tie-breaks: equal regret -> lower max loss -> name
t = solution.compile_policy({"policy_id": "t", "scenarios": ["x", "y"],
    "modes": [{"name": "b", "losses": [2, 0]}, {"name": "a", "losses": [0, 2]},
              {"name": "c", "losses": [1, 1]}]})
assert solution.decide(t, ["a", "b"], 5) == {"status": "act", "mode": "a", "worst_regret": 2}
assert solution.decide(t, ["b", "c", "a"], 5) == {"status": "act", "mode": "c", "worst_regret": 1}
t2 = solution.compile_policy({"policy_id": "t", "scenarios": ["x", "y"],
    "modes": [{"name": "p", "losses": [5, 5]}, {"name": "q", "losses": [5, 9]},
              {"name": "r", "losses": [9, 5]}]})
assert solution.decide(t2, ["q", "r", "p"], 0) == {"status": "act", "mode": "p", "worst_regret": 0}
print("ok")
