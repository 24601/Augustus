"""Offline adapter: ordinal predictor replies -> loss-minimizing action or defer."""
import json
import sys
from fractions import Fraction


def _defer(case_id, reason):
    return {"id": case_id, "status": "defer", "reason": reason}


def _usable_distribution(reply, levels):
    """Return {level: Fraction mass} normalized, or None if unusable."""
    r_levels = reply.get("levels")
    weights = reply.get("weights")
    if not isinstance(r_levels, list) or not isinstance(weights, list):
        return None
    if len(r_levels) != len(levels) or len(weights) != len(r_levels):
        return None
    if not all(isinstance(x, str) for x in r_levels):
        return None
    if len(set(r_levels)) != len(r_levels) or set(r_levels) != set(levels):
        return None
    masses = []
    for w in weights:
        if isinstance(w, bool) or not isinstance(w, (int, float)):
            return None
        if w != w or w < 0:
            return None
        masses.append(Fraction(w))
    total = sum(masses, Fraction(0))
    if total <= 0:
        return None
    return {lvl: m / total for lvl, m in zip(r_levels, masses)}


def solve(request: dict) -> dict:
    now = request["now"]
    version = request["model_version"]
    levels = list(request["levels"])
    actions = request["actions"]
    by_id = {}
    for reply in request.get("replies", []):
        by_id.setdefault(reply.get("id"), []).append(reply)

    decisions = []
    for case in request["cases"]:
        cid = case["id"]
        found = by_id.get(cid, [])
        if not found:
            decisions.append(_defer(cid, "missing"))
            continue
        if len(found) > 1:
            decisions.append(_defer(cid, "duplicate"))
            continue
        reply = found[0]
        if reply.get("model_version") != version:
            decisions.append(_defer(cid, "version"))
            continue
        obs = reply.get("observed_at")
        if obs > now or now - obs > case["ttl"]:
            decisions.append(_defer(cid, "freshness"))
            continue
        dist = _usable_distribution(reply, levels)
        if dist is None:
            decisions.append(_defer(cid, "distribution"))
            continue
        best = None
        for action in actions:
            cost = sum((dist[lvl] * loss for lvl, loss in zip(levels, action["losses"])),
                       Fraction(0))
            key = (cost, action["name"])
            if best is None or key < best:
                best = key
        decisions.append({"id": cid, "status": "act", "action": best[1],
                          "expected_loss": float(best[0])})
    return {"decisions": decisions}


def main():
    request = json.load(sys.stdin)
    sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
