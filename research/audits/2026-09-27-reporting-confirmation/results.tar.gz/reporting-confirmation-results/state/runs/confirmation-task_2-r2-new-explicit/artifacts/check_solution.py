import copy
import json
import subprocess
import sys

from solution import solve

with open("input.json") as f:
    example = json.load(f)

# Example: a = low .6, medium .3, high .1 -> inspect 2 vs leave 2.1.
snap = copy.deepcopy(example)
out = solve(example)
assert example == snap, "mutated request"
assert out == {"decisions": [
    {"id": "a", "status": "act", "action": "inspect", "expected_loss": 2.0},
    {"id": "b", "status": "defer", "reason": "missing"}]}, out

# CLI
p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(example),
                   capture_output=True, text=True)
assert p.returncode == 0 and p.stdout.endswith("\n") and p.stdout.count("\n") == 1
assert json.loads(p.stdout) == out

base = {"now": 100, "model_version": "v", "levels": ["low", "mid", "high"],
        "actions": [{"name": "zeta", "losses": [0, 0, 0]},
                    {"name": "alpha", "losses": [0, 0, 0]}]}


def one(reply, ttl=10, actions=None, extra=()):
    req = dict(base, cases=[{"id": "c", "ttl": ttl}],
               replies=[dict({"id": "c", "model_version": "v", "observed_at": 95,
                              "levels": ["low", "mid", "high"], "weights": [1, 1, 1]},
                             **reply)] + list(extra))
    if actions:
        req["actions"] = actions
    return solve(req)["decisions"][0]


def reason(d):
    return d.get("reason")

# Tie -> lexicographically smaller name regardless of order.
assert one({})["action"] == "alpha"
# Duplicate even if only one is right version; unknown ids ignored.
assert reason(one({}, extra=[{"id": "c", "model_version": "old", "observed_at": 95,
                              "levels": [], "weights": []}])) == "duplicate"
assert one({}, extra=[{"id": "zzz"}])["status"] == "act"
assert reason(one({"model_version": "w"})) == "version"
# Precedence: version before freshness before distribution.
assert reason(one({"model_version": "w", "observed_at": 999, "weights": []})) == "version"
assert reason(one({"observed_at": 999, "weights": []})) == "freshness"
assert reason(one({"observed_at": 101})) == "freshness"
assert one({"observed_at": 90})["status"] == "act"  # exact TTL boundary
assert one({"observed_at": 100}, ttl=0)["status"] == "act"
assert reason(one({"observed_at": 89})) == "freshness"
bad = [
    {"levels": ["low", "mid"], "weights": [1, 1]},            # missing level
    {"levels": ["low", "mid", "mid"]},                         # repeated level
    {"levels": ["low", "mid", "huge"]},                        # unknown level
    {"levels": ["low", "mid", "high", "x"], "weights": [1, 1, 1, 1]},
    {"weights": [1, 1]},                                       # length mismatch
    {"weights": [1, True, 1]},
    {"weights": [1, None, 1]},
    {"weights": [1, "1", 1]},
    {"weights": [1, -0.125, 1]},
    {"weights": [0, 0, 0]},
    {"weights": [0.0, 0, 0]},
]
for b in bad:
    assert reason(one(b)) == "distribution", b
assert one({"weights": [0, 0, 0.125]})["status"] == "act"  # zeros ok

# Policy: align by name, unnormalized mass, whole distribution not mean.
acts = [{"name": "watch", "losses": [0, 0, 100]},
        {"name": "escalate", "losses": [10, 10, 0]}]
# Mass: high 2, low 6 (mid 0). Mean index 0.5 would look "mid" -> escalate-ish;
# expected loss: watch = 100*0.25 = 25, escalate = 10*0.75 = 7.5.
d = one({"levels": ["high", "mid", "low"], "weights": [2, 0, 6]}, actions=acts)
assert d == {"id": "c", "status": "act", "action": "escalate", "expected_loss": 7.5}, d
d = one({"levels": ["high", "mid", "low"], "weights": [0.25, 0, 9.75]}, actions=acts)
assert d["action"] == "watch" and abs(d["expected_loss"] - 2.5) < 1e-9, d
# Exact tie at fractional masses: 1/3 each -> watch 100/3, esc 20/3.
d = one({"weights": [0.125, 0.125, 0.125]}, actions=acts)
assert d["action"] == "escalate" and abs(d["expected_loss"] - 20 / 3) < 1e-9
# Output keys and ordering over multiple cases.
req = dict(base, cases=[{"id": "y", "ttl": 5}, {"id": "x", "ttl": 5}], replies=[])
assert [x["id"] for x in solve(req)["decisions"]] == ["y", "x"]
assert solve(dict(base, cases=[], replies=[])) == {"decisions": []}
print("all checks passed")
