import copy
import json
import subprocess
import sys

import solution


def cli(req):
    p = subprocess.run([sys.executable, "solution.py"], input=json.dumps(req),
                       capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    assert p.stdout.endswith("\n") and p.stdout.count("\n") == 1
    return json.loads(p.stdout)


with open("input.json") as f:
    req = json.load(f)
orig = copy.deepcopy(req)
art = cli(req)
assert solution.solve(req) == art
assert req == orig
assert art == {"schema": 1, "policy_id": "field-v2", "scenarios": ["heat", "rain", "wind"],
               "modes": [{"name": "canvas", "losses": [3, 2, 9]},
                         {"name": "hybrid", "losses": [4, 4, 4]},
                         {"name": "steel", "losses": [8, 5, 1]}]}, art
a2 = solution.compile_policy(req["spec"])
a2["modes"][0]["losses"][0] = 99
assert req == orig

def d(allowed, lim):
    return cli({"op": "decide", "artifact": art, "allowed": allowed, "max_regret": lim})

assert d(["steel", "canvas", "hybrid"], 3) == {"status": "act", "mode": "hybrid", "worst_regret": 3}
assert d(["steel", "canvas", "hybrid"], 2) == {"status": "defer", "reason": "regret_limit"}
assert d([], 0) == {"status": "defer", "reason": "no_mode"}
assert d(["hybrid", "nope"], 100) == {"status": "defer", "reason": "unknown_mode"}
assert d(["canvas"], 0) == {"status": "act", "mode": "canvas", "worst_regret": 0}
# canvas vs steel: best [3,2,1]; canvas 8, steel 5
assert d(["canvas", "steel"], 5) == {"status": "act", "mode": "steel", "worst_regret": 5}
# ties: equal regret -> lower max loss -> name
t = solution.compile_policy({"policy_id": "t", "scenarios": ["x"],
                             "modes": [{"name": "b", "losses": [1]}, {"name": "a", "losses": [1]}]})
assert solution.decide(t, ["b", "a"], 0) == {"status": "act", "mode": "a", "worst_regret": 0}
t = solution.compile_policy({"policy_id": "t", "scenarios": ["y", "x"],
                             "modes": [{"name": "a", "losses": [5, 0]}, {"name": "b", "losses": [0, 5]},
                                       {"name": "c", "losses": [4, 4]}]})
# best [0,0]; a:5 b:5 c:4 -> c
assert solution.decide(t, ["a", "b", "c"], 9)["mode"] == "c"
print("ok")
