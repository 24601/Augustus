"""Replay frozen grading offline after inference ends; never alter submissions."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'instrument'))
import instrument as harness


def grade_one(solution, task, destination):
    destination.mkdir(parents=True)
    with tempfile.TemporaryDirectory(prefix='confirmation-grade-') as tmp:
        root = Path(tmp).resolve()
        private = root/'private'; private.mkdir()
        shutil.copyfile(ROOT/'packet/private/grade.py',private/'grade.py')
        candidate = root/'candidate'/task; candidate.mkdir(parents=True)
        if solution.is_file(): shutil.copyfile(solution,candidate/'solution.py')
        (root/'home').mkdir();(root/'tmp').mkdir()
        profile = harness.sandbox_profile(root) + (
            '(deny file-write* (subpath '+json.dumps(str(private))+') '
            '(subpath '+json.dumps(str(root/'candidate'))+'))\n')
        (destination/'sandbox.sb').write_text(profile)
        command = ['/usr/bin/sandbox-exec','-p',profile,sys.executable,'-S','-B',
                   str(private/'grade.py'),str(root/'candidate'),'--task',task]
        env = {'PATH':'/usr/bin:/bin','HOME':str(root/'home'),'TMPDIR':str(root/'tmp'),
               'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','LANG':'en_US.UTF-8'}
        harness.dump(destination/'execution.json',{'command':command,'environment':env,'timeoutSeconds':60})
        start=time.monotonic(); timed_out=False
        with (destination/'stdout.json').open('w') as out, (destination/'stderr.txt').open('w') as err:
            process=subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True)
            try: process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                timed_out=True
                os.killpg(process.pid,signal.SIGKILL);process.wait()
            finally:
                try: os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError: pass
        try: report=json.loads((destination/'stdout.json').read_text())
        except json.JSONDecodeError: report=None
        accepted=bool(not timed_out and process.returncode==0 and report
                      and task in report and report[task].get('failed')==0
                      and report[task].get('passed',0)>0)
        receipt={'task':task,'accepted':accepted,'timedOut':timed_out,
                 'exitCode':process.returncode,'durationSeconds':time.monotonic()-start,
                 'solutionSha256':harness.sha(solution) if solution.is_file() else None,
                 'graderSha256':harness.sha(ROOT/'packet/private/grade.py'),'report':report}
        harness.dump(destination/'receipt.json',receipt)
        return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',default='grading')
    args=parser.parse_args()
    output=ROOT/args.output
    assert not output.exists(), 'Keep prior grading; choose a new output directory for replay'
    state=json.loads((ROOT/'state/state.json').read_text())
    assert len(state['records'])==18 and all(r['status']!='running' for r in state['records'])
    # Hash every frozen private file before and after grading. Nothing is edited.
    before={str(p.relative_to(ROOT/'packet/private')):harness.sha(p)
            for p in (ROOT/'packet/private').rglob('*') if p.is_file()}
    output.mkdir()
    references={task:grade_one(ROOT/'packet/private/reference'/task/'solution.py',task,output/'references'/task)
                for task in ['task_1','task_2']}
    assert all(r['accepted'] for r in references.values()), 'Grading environment failed known-good references'
    records=[]
    for record in state['records']:
        solution=ROOT/'state/runs'/record['id']/'artifacts/solution.py'
        if solution.exists():
            manifest=json.loads((solution.parent.parent/'artifact-manifest.json').read_text())
            assert harness.sha(solution)==manifest['files']['solution.py']
        graded=grade_one(solution,record['task'],output/'runs'/record['id'])
        records.append({'id':record['id'],'arm':record['arm'],'repeat':record['repeat'],**graded})
        print(json.dumps({'id':record['id'],'accepted':graded['accepted'],'report':graded['report']}),flush=True)
    after={str(p.relative_to(ROOT/'packet/private')):harness.sha(p)
           for p in (ROOT/'packet/private').rglob('*') if p.is_file()}
    assert before==after
    harness.dump(output/'summary.json',{'graderFilesUnchanged':True,'graderFiles':before,
                                     'references':references,'records':records})


if __name__=='__main__': main()
